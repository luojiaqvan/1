# LLM 提示词工程与工具交互规范

## §1 文档说明

### 1.1 文档定位

本文件是"大模型 + 网络工程配置/运维平台"阶段一的工具层与 LLM 提示词工程规范权威文档。

本文档规定：
- 主模型（单次流式 agentic 调用）的提示词工程规范、输入输出约束、工具调用纪律
- 候选命令生成（通过 `generate_commands` 工具调用）的提示词工程规范、输出结构要求、厂商适配策略
- 工具调用约定、工具选择优先级、工具结果使用规则
- Few-shot 示例的组织与使用规范
- 命令知识库的结构与检索规范
- 幻觉防护分层策略与安全约束

本规范是确保 LLM 与工具层、适配层、知识库层协同工作的核心依据。

### 1.2 与其他文档的边界

| 文档 | 权威职责 | 本文档不做什么 |
|------|----------|----------------|
| ROADMAP.md | 项目范围权威、各模块职责边界、演进路线 | 不重复项目范围描述，不定义功能验收标准 |
| API_SPEC.md | 接口契约权威、请求/响应 Schema、端点定义 | 不重新定义接口字段结构，仅引用相关章节 |
| ARCHITECTURE.md | 组件结构权威、部署架构、设计模式 | 不重复组件职责描述，不定义技术栈选型 |
| TOOLS_SPEC.md（本文档） | LLM 提示词与工具交互权威、幻觉防护、厂商适配策略 | 不定义接口结构，不描述组件架构 |

### 1.3 设计原则

#### 1.3.1 单模型默认模式

阶段一到阶段二默认采用单模型流式 agentic 模式：系统发起**单次流式 agentic 调用**，模型在同一个流式响应中同时输出文本增量与工具调用增量。模型即是 agent，通过 function calling 自主决定何时调用工具（包括 `generate_commands`）、何时输出解释文本，无需外部多次编排调用。

在该模式下：

- 默认主链路仍使用流式 agentic 调用；但若上游 OpenAI 兼容模型仅以非流式方式返回思考内容，后端需将其归一化为与流式一致的前端事件契约
- 模型在单个流式上下文中同时完成意图理解、工具调度、解释回复与候选命令生成
- 候选命令通过 `generate_commands` 工具调用输出，不在文本流中直接嵌入 CLI 命令
- 后端组装校验 tool_call 参数后推送 `approval_required` SSE 事件，前端从 tool_call 内容渲染授权卡片
- 同一模型在同一上下文中通过提示词工程和工具约束保证各阶段职责隔离

#### 1.3.2 双模型串联（演进预留：阶段三）

当需要优化成本、时延或长尾厂商生成效果时，Phase 3 可选引入专用命令生成模型。双模型模式下，主模型负责意图理解与工具调度，专用命令生成模型负责候选命令生成；未启用该能力时，系统必须继续兼容只有一个模型的模式。

#### 1.3.2 工具优先而非自由生成

主模型在需要设备信息、厂商知识、实时状态时，必须通过工具获取，不得基于训练数据"记忆"直接生成。

#### 1.3.3 候选命令无执行权

候选命令通过 `generate_commands` 工具调用输出，不持有任何执行权。所有命令在执行前必须经过用户确认，确认后由意图引擎（IE4 execute_commands）调度统一设备管理程序（DM7 execute_on_device）执行。

#### 1.3.4 可解释性与保守性优先

每条候选命令必须包含生成依据（generation_basis）。低置信度时宁可不生成，高风险命令必须明确标注风险等级（risk_level）。

#### 1.3.5 幻觉防护前置

通过提示词约束、知识库锚定、tool_call 组装校验、输出结构校验、语法校验、人工确认门控共 6 层防护，将幻觉拦截在执行之前。

### 1.4 适用范围

本文档规范适用于阶段一的以下范围：

- **厂商支持**：华为 VRP、H3C Comware
- **协议支持**：SSH、Telnet（通过 netmiko）
- **LLM 访问**：通过 LiteLLM 网关，OpenAI 兼容 API
- **部署模式**：单进程 Python 服务，非微服务架构
- **命令类型**：查询类（query）、巡检类（inspect）、变更类（change）

### 1.5 非本阶段范围

以下内容不在本文档阶段一范围内，标注为演进预留：

- 审批流引擎（演进预留：阶段三）
- RBAC 权限模型（演进预留：阶段三）
- 命令回滚机制（演进预留：阶段二）
- 自动化校验与修复闭环（演进预留：阶段三）
- NETCONF / RESTCONF / gNMI / 控制器 API 支持（演进预留：阶段三，依赖阶段二拓扑基础）
- SDN 控制器接入与拓扑/控制器工具（演进预留：阶段三，依赖阶段二拓扑基础）
- 命令知识库的完整内容（知识库条目存放在 `llm/tools/` 或 `lab/` 目录，本文档仅规定其 Schema 与检索规范）

---

## §2 主模型提示词规范（流式 Agentic 调用）

### 2.1 职责边界

主模型（见 API_SPEC.md §3.1 LG1）在单次流式 agentic 调用中承担以下职责：

1. **理解自然语言输入**：解析用户的运维需求、查询意图、变更目标
2. **选择工具**：根据需求选择合适的工具（parse_intent/search_knowledge/query_device_status/list_devices/generate_commands）
3. **生成结构化意图**：输出供 `llm/intent_engine` 收口的原始意图结果，并在同一上下文中通过 `generate_commands` 工具生成候选命令
4. **歧义识别与澄清**：在设备未指定、厂商不明确、操作类型模糊时主动追问

主模型不得执行以下操作：

- 在文本流中直接输出 CLI 命令（命令必须通过 `generate_commands` 工具调用输出）
- 直接操作设备（这是执行系统的职责）
- 伪造设备 ID 或厂商信息
- 在未调用工具时声称已获取设备信息

### 2.2 系统提示词模板结构

主模型的系统提示词必须包含以下 block：

#### 2.2.1 角色定义

明确模型身份为"网络运维意图理解与调度专家"，负责将自然语言转换为结构化意图并选择工具。

#### 2.2.2 工具交互机制

阶段一模型通过 function calling 调用工具，采用 **tools 参数为主、system prompt 为策略层** 的双通道机制：

- **tools[] 参数**（结构化通道）：承载每个工具的名称、参数 JSON Schema、简短描述。由 toolset 编译产生，直接传给 LLM API 的 `tools` 字段。编译规则见 §3.1.2。
- **System Prompt 策略段**（指导通道）：承载工具选择优先级矩阵（见 §3.2）、调用顺序约束（见 §3.3）、歧义处理规则（见 §2.2.4）、禁止事项（见 §2.4）。本节不重复罗列工具名和参数定义，这些由 tools[] 参数承载。

工具定义面向**逻辑工具**，而不是底层连接协议。每个逻辑工具由 **skill（说明书）+ 可选 mcp（连接/执行封装）** 组合而成；模型看到的是逻辑工具名和其契约，而不是裸 SSH/Telnet/HTTP 会话。

阶段一逻辑工具清单（工具入参/返回结构见 API_SPEC.md §3.7.3 TL1-TL5）：

- `parse_intent`：解析用户意图，输出标准化意图
- `search_knowledge`：搜索命令知识库
- `query_device_status`：获取设备实时状态
- `list_devices`：列出可用设备列表
- `generate_commands`：生成候选命令列表，参数为候选命令结构（见 §4）

#### 2.2.3 工具选择策略

以决策矩阵形式定义什么场景选择什么工具（见 §3.2）。

#### 2.2.4 歧义处理规则

明确在以下情况下必须追问而非猜测：

- 用户未指定目标设备
- 设备厂商或型号不明确
- 操作类型存在歧义（是查询还是变更）
- 目标对象不明确（接口、VLAN、路由等）

#### 2.2.5 输出纪律

规定必须通过流式 function calling 输出，文本增量与工具调用增量在同一个流中交织。命令只能通过 `generate_commands` 工具调用输出，不得在文本流中直接嵌入 CLI 命令。

#### 2.2.6 禁止事项

列出明确的禁止行为（见 §2.4）。

### 2.3 上下文拼装规则

发送给主模型的消息按以下顺序拼装：

1. **System Prompt**：包含角色定义、工具清单、策略规则
2. **设备上下文**（如已指定设备）：注入设备摘要（vendor、model、os_version）
3. **对话历史**：历史消息，包含用户输入与模型的工具调用记录
4. **当前用户消息**：最新的自然语言输入

上下文注入通过 system prompt 的"设备上下文注入点"占位符实现。

### 2.4 输出约束与禁止事项

#### 2.4.1 输出约束

- 默认通过流式 function calling 格式输出；若上游 OpenAI 兼容模型的思考内容仅能在非流式最终响应中返回，后端需在网关层将其归一化后再对前端输出
- 调用工具时必须提供完整参数
- 候选命令必须通过 `generate_commands` 工具调用输出，不得在文本流中直接嵌入 CLI 命令
- 未明确请求时不得输出 CLI 命令

#### 2.4.2 禁止事项

- 禁止在文本流中直接输出 CLI 命令（命令必须通过 `generate_commands` 工具调用）
- 禁止伪造设备 ID、厂商信息
- 禁止在未调用工具时声称已获取设备状态
- 禁止基于训练数据"记忆"直接生成厂商特定命令

### 2.5 澄清与拒答规则

主模型在以下情况必须追问而非猜测：

1. **设备未指定**：用户说"查看接口状态"但未指定设备 → 调用 list_devices 或追问
2. **厂商不明确**：用户说"配置链路聚合"但未说明厂商 → 追问或从设备上下文推断
3. **操作类型模糊**：用户说"处理 VLAN 10"但不清楚是创建、修改还是删除 → 追问
4. **目标对象不明确**：用户说"检查路由"但不清楚是静态路由、OSPF 还是 BGP → 追问

澄清响应应简洁，一次最多提出 2-3 个问题，避免信息过载。

---

## §3 工具调用约定

### 3.1 工具定义模型（skills + MCP）

阶段一开始，模型工具定义采用以下组合：

- **Skill**：充当说明书，描述工具用途、输入输出约束、何时调用、何时拒绝调用
- **MCP**：封装连接、管理执行工具，向逻辑工具提供连接发现与实际调用能力
- **Tool Definition**：面向模型暴露的最终逻辑工具；每项至少绑定一个 skill，按需绑定一个 MCP capability

推荐结构：

```json
{
  "tool_name": "query_device_status",
  "skill_id": "skill.device.query_status",
  "mcp": {
    "mcp_id": "mcp.device.default",
    "capability": "execute_command"
  },
  "exposure": "model_direct"
}
```

职责边界：

- skill 负责告诉模型“这是什么能力、何时可用、如何安全使用”
- mcp 负责“列出连接、选择目标、执行调用、回传结果”
- 需要连接或执行的工具，不应只有 skill 而没有 mcp 绑定
- 不需要外部执行的工具（如 `parse_intent`、`generate_commands`）可以仅由 skill 提供；但其输出进入前端或执行层前仍需由 `llm/intent_engine` 做系统侧收口

MCP 最小能力要求：

1. `list_connections`：列出当前作用域下可用连接/机器摘要
2. `execute_command`：在指定机器上执行命令并回传标准结果

安全约束：

- `execute_command` 虽然是 MCP 必需能力，但默认属于**审批门控能力**
- 候选命令生成阶段，主模型仍不得绕过 `generate_commands → llm/intent_engine IE3 收口 → 用户确认 → DM7` 主链路直接执行命令
- 若后续阶段需要把 `execute_command` 暴露给专用子流程，必须显式标注 `approval_gated` 或 `backend_only`

#### 3.1.1 Provider Schema 结构契约

toolset 经编译后产出上游模型可消费的 `tools[]` 数组，每个元素必须符合以下结构：

```json
{
  "type": "function",
  "function": {
    "name": "<与 tool_definitions[].tool_name 一致>",
    "description": "<由 skill.description 派生，可追加安全约束语句>",
    "parameters": {
      "type": "object",
      "properties": {
        "<field_name>": {
          "type": "<JSON Schema 类型>",
          "description": "<字段用途说明>",
          "enum": ["<枚举值>"]
        }
      },
      "required": ["<必填字段列表>"]
    }
  }
}
```

编译约束：

- `function.name` 必须与 `tool_definitions[].tool_name` 严格一致
- `function.parameters` 必须使用 JSON Schema draft-07
- 每个 property 必须包含 `description` 字段，不得省略
- 枚举值字段必须显式列出 `enum`，不允许 free text 代替
- `function.description` 由 `skill.description` 派生，编译时允许追加简短安全约束语句（如"不得对未确认设备生成变更命令"），但不得改变 skill 的核心语义
- `exposure=backend_only` 的工具不得编入 `tools[]`；`exposure=approval_gated` 的工具编入时必须在 description 中标注审批门控约束
- 各工具的 Provider Schema 实例随 skill 定义文件维护，本节仅规定格式契约

#### 3.1.2 Toolset 编译规则

toolset（skills[] + mcps[] + tool_definitions[]）编译为上游模型可消费的产物，产出两份内容：

**产出 1：provider tools[]**

传入 LLM API 的 `tools` 参数，每个 tool_definition 编译为一个 function 对象，规则见 §3.1.1。

编译映射：

| toolset 字段 | → | provider tools[] 字段 |
|-------------|---|---------------------|
| `tool_definitions[].tool_name` | → | `function.name` |
| `skill.description` + 安全约束追加 | → | `function.description` |
| 工具入参定义（对齐 API_SPEC TL1-TL5） | → | `function.parameters`（JSON Schema） |
| `skill.instruction` | → | 不嵌入 provider tools[]，注入 system prompt 策略段 |
| `exposure=backend_only` | → | 不编入 tools[] |
| `exposure=approval_gated` | → | 编入 tools[]，description 中追加审批门控约束 |

**产出 2：system prompt 策略段**

注入 §2.2.2 system prompt 的工具策略区域，内容来源：

| 策略段内容 | 来源 |
|-----------|------|
| 工具选择优先级矩阵 | §3.2 |
| 调用顺序约束 | §3.3 |
| 各 skill.instruction 中与策略相关的约束 | skills[].instruction |
| 安全与禁止事项 | §3.5 / §2.4 |

**编译触发时机**：每次发起 agentic 调用前，由后端根据当前 toolset 配置执行编译。编译结果不缓存（toolset 配置可能动态变更）。

#### 3.1.3 阶段一 Skill 说明书

阶段一 5 个逻辑工具对应的 skill 说明书内容如下。每个 skill 的 description 和 instruction 用于 Provider Schema 编译（§3.1.2）。

**skill.intent.parse**

| 字段 | 内容 |
|------|------|
| skill_id | `skill.intent.parse` |
| name | `parse_intent` |
| description | 将用户自然语言请求解析为结构化网络运维意图，输出标准化 operation_type、target_type、目标设备、风险等级等字段 |
| instruction | 优先输出标准化意图；不得猜测不存在的设备与厂商信息；若用户请求存在歧义（设备未指定、操作类型不明确），应优先追问而非自行推断；意图中的 operation_type 必须为 query/inspect/change/rollback 之一，不得使用其他值 |

**skill.knowledge.search**

| 字段 | 内容 |
|------|------|
| skill_id | `skill.knowledge.search` |
| name | `search_knowledge` |
| description | 检索厂商文档与命令知识库，返回与查询相关的知识条目，包括命令模式、语法、适用范围等 |
| instruction | 调用 generate_commands 前必须先调用本工具获取知识引用；若检索结果为空，不得伪装为知识库驱动生成成功；query 参数应使用精确的技术术语而非自然语言长句 |

**skill.device.query_status**

| 字段 | 内容 |
|------|------|
| skill_id | `skill.device.query_status` |
| name | `query_device_status` |
| description | 查询指定设备的实时状态信息，包括接口摘要、路由表、ARP 表、系统信息等，仅限只读查询 |
| instruction | 调用前必须确认 device_id 对应的设备存在（通过 list_devices 或已有上下文）；query_type 必须为 interface_summary/route_table/arp_table/system_info 之一；本工具仅用于查询，不授予配置写入能力 |

**skill.connection.list_devices**

| 字段 | 内容 |
|------|------|
| skill_id | `skill.connection.list_devices` |
| name | `list_devices` |
| description | 列出当前用户可用的设备/连接列表，返回设备 ID、名称、厂商、状态等摘要信息 |
| instruction | 当用户未指定目标设备时，优先调用本工具列出可用设备供用户选择；不得在未确认设备存在的情况下直接调用 query_device_status 或 generate_commands；返回结果用于后续工具调用的 device_id 来源 |

**skill.commands.generate**

| 字段 | 内容 |
|------|------|
| skill_id | `skill.commands.generate` |
| name | `generate_commands` |
| description | 根据意图和知识引用生成候选命令列表，供用户确认后执行。本工具仅输出候选命令，不具备执行权 |
| instruction | 正常模式下调用前必须已获取知识引用（search_knowledge 结果）；每条命令必须包含 generation_basis 并可追溯到知识条目或模板来源；低置信度（confidence < 0.5）命令宁可不生成；高风险命令必须在 description 中显式警告；降级模式下 generation_source 必须标记为 template_fallback 并在 validation_notes 中说明降级原因 |

### 3.2 工具选择优先级

| 场景 | 首选工具 | 备选方案 | 不调用工具的后果 |
|------|----------|----------|------------------|
| 解析意图 | parse_intent | 依赖主模型直接输出（不推荐） | 意图可能不标准，前端无法稳定渲染意图卡片 |
| 需要设备实时状态 | query_device_status | 无 | 无法获取准确状态 |
| 需要确认设备是否存在 | query_device_status | list_devices | 可能操作不存在的设备 |
| 查找厂商命令参考 | search_knowledge | 无 | 可能生成不存在的命令 |
| 列出可用设备 | list_devices | 无 | 无法提供设备选择 |
| 生成候选命令 | generate_commands | 无 | 无法输出结构化候选命令 |

### 3.3 单轮与多轮调用约定

所有工具调用均在单次流式 agentic 上下文中完成，模型在同一个流式响应中自主决定调用顺序：

- 允许同一轮多次 tool_calls，但必须遵循依赖顺序
  - 必须先 list_devices 再 query_device_status
  - 可以并行调用 query_device_status（多个设备）和 search_knowledge
  - `generate_commands` 必须在获取充分知识引用后调用
- 文本增量与工具调用增量在同一个流中交织输出
- 工具调用失败时，主模型应向用户解释错误原因，不得基于错误结果继续推理

#### 3.3.1 单次 Agentic 调用边界

| 维度 | 默认值 | 说明 |
|------|--------|------|
| 工具调用次数上限 | 10 次/轮 | 单次 agentic 调用中累计工具调用次数超过此值后，后端不再执行后续 tool_call，向模型回传错误 |
| 单工具重试上限 | 2 次 | 同一工具连续失败 2 次后回传错误，由模型决定换策略或向用户报告 |
| 工具结果截断上限 | 2000 字符 | 单条 tool result 超过此值时截断尾部，追加 `"[输出已截断，共 N 行]"` |
| 截断触发阈值 | 可配置 | 默认值供阶段一使用，后续阶段可通过配置调整 |

#### 3.3.2 多轮对话上下文管理

本规范仅覆盖单次 agentic 调用内的工具交互约束。多轮对话的上下文拼装、历史管理与压缩策略见 ARCHITECTURE.md / API_SPEC.md 相关章节。

### 3.4 工具结果的使用规则

- 后续推理必须严格基于工具返回的数据
- 不得在工具返回为空或错误时"虚构"结果
- 不得在未调用工具的情况下声称"已查询设备状态"

#### 3.4.1 Tool Result 回传格式

工具调用结果以 `role: "tool"` 消息回传模型，content 统一使用以下三态格式：

**正常结果：**

```json
{
  "status": "success",
  "data": "<工具返回的业务数据，对齐各 TL 返回结构>"
}
```

**错误结果：**

```json
{
  "status": "error",
  "error_code": "<标准错误码>",
  "message": "<供模型理解的错误描述，应指导模型下一步行为>"
}
```

**空结果：**

```json
{
  "status": "empty",
  "message": "<说明为什么没有结果>"
}
```

格式约束：

- `status` 只允许 `success / error / empty` 三个值，工具不得私自扩展
- `error.message` 的受众是模型而非人类，措辞应指导模型下一步行为（如"设备连接超时，建议调用 list_devices 检查设备状态"），而非面向人类的 debug 信息
- 工具返回数据超过截断上限（见 §3.3.1）时，在截断后包装为 `status: success` 回传
- 不允许返回 `status: null` 或省略 status

### 3.5 禁止行为列表

- 禁止伪造工具返回值
- 禁止跳过工具直接生成命令
- 禁止在工具调用失败时忽略错误继续执行
- 禁止在未确认设备存在时生成变更命令

### 3.6 知识库调用强制链路

阶段一正常模式下，候选命令生成必须遵循以下知识库驱动链路：

```text
主模型（单次流式 agentic 调用）
  → TL2.search_knowledge（模型自主调用）
  → TL5.generate_commands（模型调用，参数为候选命令）
  → llm/intent_engine.IE3 组装校验并冻结 proposal
  → approval_required SSE 事件
  → 前端从冻结 proposal 渲染授权卡片
```

约束：

- **正常模式下，模型在调用 `generate_commands` 前必须先获取知识引用**。如果未能得到任何知识引用，不得伪装为知识库驱动生成成功。
- `knowledge_refs` 必须来自 KR1 或 KR2 的结构化结果，而不是调用方临时拼接的自由文本。
- 候选命令输出中的 `generation_basis` 必须可回溯到本次 `knowledge_refs` 中的稳定来源标识。
- `generate_commands` 的 tool_call 参数必须包含完整的候选命令结构（见 §4.4），并由 `llm/intent_engine` 在推送 `approval_required` 前完成组装、冻结与校验。

### 3.7 降级路径与模板生成约束

当知识检索不可用、知识结果为空、或当前场景仅存在经过冻结审核的命令模板时，系统可进入降级路径。

阶段一仅允许以下两种生成模式：

| 模式 | 说明 | 允许条件 |
|------|------|----------|
| `knowledge_grounded_model` | 基于 `knowledge_refs` 通过 `generate_commands` 工具调用正常生成候选命令 | KR1/KR2 成功返回可用引用 |
| `template_fallback` | 使用厂商模板/规则降级生成，通过 `generate_commands` 工具调用输出 | 知识检索失败、无匹配知识条目、或仅有冻结模板可用 |

降级路径约束：

- 使用模板降级时，`candidate_commands[].generation_source` 必须标记为 `template_fallback`，不得继续标记为 `model` 或 `knowledge_base`。
- 模板降级时，`generation_basis` 必须明确指向模板来源，而不是伪装成知识条目引用。
- 降级路径必须在 `validation_notes` 或等价字段中写明原因，如"知识检索失败，已回退到厂商模板"。
- 仅当模板已被项目明确冻结和允许时，厂商适配层才可直接生成候选命令；否则应返回空候选并说明原因。

---

## §4 候选命令生成提示词规范（通过 generate_commands 工具调用）

### 4.1 职责边界

候选命令生成环节通过模型在 agentic 调用中调用 `generate_commands` 工具（TL5）完成。该逻辑工具由 `skill.commands.generate` 提供说明书能力，不绑定执行型 MCP。模型在单次流式 agentic 上下文中，根据意图解析与知识检索结果，自主决定调用 `generate_commands` 并传入候选命令作为工具参数。`llm/intent_engine` 在系统侧负责把该输出收口为冻结 proposal。Phase 3 可选切换到专用命令生成模型。

候选命令生成环节承担以下职责：

1. **从结构化意图生成候选命令**：根据主模型输出的标准化意图生成厂商特定的 CLI 命令
2. **提供生成依据**：每条命令必须说明生成来源（知识库条目、厂商文档、经验规则）
3. **标注风险与置信度**：评估命令的风险等级与生成置信度
4. **保守策略**：低置信度时宁可不生成，高风险命令必须明确警告

候选命令生成环节不得执行以下操作：

- 直接连接设备或执行命令
- 越过用户确认触发执行
- 基于训练数据"记忆"生成知识库中不存在的命令

### 4.2 系统提示词模板结构

候选命令生成的提示词作为 agentic 调用的系统提示词的一部分，必须包含以下 block：

#### 4.2.1 角色定义

明确模型身份为"{vendor} {os_family} 命令生成专家"，在 agentic 调用中通过 `generate_commands` 工具将标准化意图转换为候选命令。

#### 4.2.2 输入格式说明

定义标准意图的格式（见 API_SPEC.md §3.2 IE1）。输入来自同一 agentic 上下文中的前序工具调用结果与对话历史。

#### 4.2.3 输出格式要求

候选命令作为 `generate_commands` 工具调用的参数输出（而非独立的 JSON 响应），每条命令包含以下字段：

- description：命令用途说明
- risk_level：风险等级（low / medium / high，对齐 API_SPEC.md 定义）
- is_config：是否为配置命令（true/false）
- generation_basis：生成依据（知识库条目 ID 或来源说明）
- applicability：适用性说明（OS 版本、型号约束）
- expect_pattern：预期输出模式（如适用）
- confidence：置信度（0.0-1.0）

`generate_commands` 工具参数对齐 candidate_commands Schema，后端在收到 tool_call 后对参数进行组装校验，校验通过后推送 `approval_required` SSE 事件。

#### 4.2.4 安全约束

- 不得生成危险命令（如格式化设备、删除核心配置）除非用户明确要求并已标注风险
- 低置信度（< 0.6）命令必须标注"建议人工复核"
- 不得生成知识库中不存在的命令模式

#### 4.2.5 厂商特定指令注入点

预留占位符，由厂商适配层（见 API_SPEC.md §3.6 VA1）注入厂商特定的 CLI 约定。

### 4.3 输入拼装顺序

候选命令生成不再使用独立上下文，而是复用同一 agentic 流式调用的完整上下文。相关上下文按以下方式在系统提示词中注入：

1. **设备上下文**：vendor、model、os_version（通过系统提示词的设备上下文注入点）
2. **厂商适配 prompt**：由 VA1.get_system_prompt() 提供的厂商特定提示词
3. **知识库参考**：通过 `search_knowledge` 工具调用获取，结果在对话历史中可见
4. **约束条件**：用户提供的额外约束（如"不中断业务"）

#### 4.3.1 正常模式与降级模式

- **正常模式**：模型在 agentic 流式调用中先调用 `search_knowledge` 获取知识引用，再调用 `generate_commands` 输出候选命令。知识引用是必需项。
- **降级模式**：仅在 §3.7 定义的条件下允许跳过知识引用；此时模型在调用 `generate_commands` 时必须显式标记 `generation_source=template_fallback`，并说明未使用知识引用的原因。

#### 4.3.2 `knowledge_refs` 输入契约

传给候选命令生成的 `knowledge_refs` 至少应包含以下字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| ref_id | string | 本次引用在上下文中的稳定 ID |
| source_type | string | `knowledge_entry / vendor_doc / sop / command_ref` |
| source_id | string | 知识源稳定标识，如 `entry_id` / `doc_id` |
| title | string | 条目或文档标题 |
| content | string | 注入 prompt 的知识摘要 |
| relevance_score | float | 检索相关度分数 |
| vendor | string or null | 厂商标识 |
| metadata | object or null | 额外元数据，如 target_type、os_version 约束 |

约束：

- `knowledge_refs` 中的每一条都必须能回溯到知识检索引擎的原始结果。
- `generate_commands` 工具调用只能引用 `knowledge_refs` 中出现的知识来源，不得凭空构造新的知识 ID。
- 若同一候选命令由多个知识来源共同支撑，可在 `generation_basis` 中返回主来源并在 `validation_notes` 中附加次级来源。

### 4.4 输出结构约束

候选命令作为 `generate_commands` 工具调用的参数输出，后端在收到 tool_call 后对参数进行组装校验。每个命令对象包含以下字段（详细定义见 API_SPEC.md §3.1 LG3）：

- command：完整的 CLI 命令字符串
- description：命令用途的自然语言说明
- risk_level：风险等级枚举
- is_config：布尔值，标识是否为配置命令
- generation_basis：生成依据，必须指向知识库条目或明确来源
- applicability：适用性说明
- expect_pattern：预期输出模式（可选）
- confidence：浮点数，表示生成置信度

#### 4.4.1 `generation_basis` 引用格式规范

`generation_basis` 不应再是无约束自由文本。阶段一至少应满足以下两种格式之一：

1. **结构化对象格式（推荐）**

```json
{
  "source_type": "knowledge_entry",
  "source_id": "huawei_vrp_interface_display_001",
  "source_title": "华为 VRP 接口查询命令",
  "snippet": "display interface brief"
}
```

2. **字符串兼容格式（仅兼容旧实现）**

```text
knowledge_entry:huawei_vrp_interface_display_001
vendor_doc:huawei-vrp-command-guide-v200r019
template:huawei:interface_query_basic
```

约束：

- 正常模式下，`generation_basis` 必须引用 `knowledge_refs` 中某个稳定 `source_id`。
- 降级模式下，`generation_basis` 必须使用 `template:*` 或等价模板引用格式。
- 禁止使用“基于经验”“根据常见写法”等不可追溯文本作为唯一生成依据。

### 4.5 生成保守策略

- **低置信度时宁可不生成**：当 confidence < 0.5 时，可选择不生成该命令，在响应中说明原因
- **高风险命令必须标注**：risk_level 为 high 时，必须在 description 中显式警告
- **无法确定时给出多个候选**：当存在多个可行方案时，列出 2-3 个候选并说明差异
- **超出能力时拒绝生成**：识别到不支持的操作或超出知识库范围时，返回空候选列表并说明

---

## §5 厂商适配提示词工程规范

### 5.1 VA1.get_system_prompt 的职责

厂商适配层（见 API_SPEC.md §3.6 VA1）的 get_system_prompt() 方法负责为候选命令生成提供：

1. 厂商特定的系统提示词骨架
2. Few-shot 示例（按 operation_type + target_type 组合选择）
3. CLI 模式约定（用户视图、系统视图、子命令层级）
4. 命名惯例与语法约束

### 5.2 通用适配层提示词框架

所有厂商共享以下提示词骨架：

- **安全要求**：禁止生成危险命令（如 reboot、erase），除非用户明确要求
- **输出格式**：必须对齐 API_SPEC.md §3.1 LG3 的响应结构
- **命令纪律**：不得混合视图无关命令，不得在用户视图生成系统视图命令

### 5.3 Huawei（VRP）特定要求

#### 5.3.1 CLI 模式约定

- **用户视图**：以 `<Huawei>` 或 `<设备名>` 提示符标识，适合查看操作
- **系统视图**：通过 `system-view` 进入，以 `[Huawei]` 提示符标识，用于配置
- **子视图**：如接口视图 `[Huawei-GigabitEthernet0/0/1]`、VLAN 视图 `[Huawei-vlan10]`

#### 5.3.2 命名惯例

- 接口命名：`GigabitEthernet0/0/1`、`10GE1/0/1`、`LoopBack0`
- VLAN 命名：`vlan 10`、`vlan batch 10 20 30`
- ACL 命名：`acl number 2000`、`acl name advance-acl advanced`

#### 5.3.3 常见命令模式

- 查看接口：`display interface brief`、`display interface GigabitEthernet0/0/1`
- 查看 VLAN：`display vlan`、`display vlan 10`
- 配置 VLAN：`vlan 10`、`description Sales-Network`
- 配置接口：`interface GigabitEthernet0/0/1`、`port link-type access`、`port default vlan 10`

#### 5.3.4 特定注意事项

- VRP 命令区分大小写
- 某些命令需要先 `undo` 再重新配置
- 批量操作使用 `batch` 关键字（如 `vlan batch 10 to 20`）

### 5.4 H3C（Comware）特定要求

#### 5.4.1 CLI 模式约定

- **用户视图**：以 `<H3C>` 或 `<设备名>` 提示符标识
- **系统视图**：通过 `system-view` 进入，以 `[H3C]` 提示符标识
- **子视图**：接口视图 `[H3C-GigabitEthernet1/0/1]`、VLAN 视图 `[H3C-vlan10]`

#### 5.4.2 命名惯例

- 接口命名：`GigabitEthernet1/0/1`、`Ten-GigabitEthernet1/0/1`、`LoopBack0`
- VLAN 命名：`vlan 10`、`vlan 10 to 20`
- ACL 命名：`acl number 2000`、`acl name advance-acl`

#### 5.4.3 常见命令模式

- 查看接口：`display interface brief`、`display interface GigabitEthernet1/0/1`
- 查看 VLAN：`display vlan`、`display vlan 10`
- 配置 VLAN：`vlan 10`、`name Sales-Network`
- 配置接口：`interface GigabitEthernet1/0/1`、`port link-type access`、`port access vlan 10`

#### 5.4.4 与华为的关键差异

- H3C 使用 `port access vlan` 而非华为的 `port default vlan`
- H3C 的批量 VLAN 配置语法：`vlan 10 to 20` 而非 `vlan batch 10 to 20`
- H3C 的接口 shutdown 命令：`shutdown` 直接在接口视图执行

### 5.5 示例选择与拼装规则

厂商适配层按以下策略选择 Few-shot 示例：

1. **按 operation_type 匹配**：query/inspect/change
2. **按 target_type 匹配**：interface/vlan/route/acl/system
3. **组合优先级**：operation_type + target_type 精确匹配 > 仅 operation_type 匹配 > 通用示例
4. **按示例行为分类匹配**：正例（对应有效操作）、 负例（对应无效操作)、 拒绝示例（对应超出能力的请求）
示例拼装顺序：正例 → 负例 → 拒绝示例 → 注意事项

---

## §6 Few-shot 示例规范

### 6.1 示例结构

每个 Few-shot 示例必须包含以下字段：

- **用户意图**：原始自然语言输入
- **标准化意图摘要**：主模型输出的 IE1 核心字段
- **设备上下文摘要**：vendor、model、os_version
- **预期候选命令**：1-3 条 CLI 命令
- **生成依据**：每条命令的 generation_basis 说明
- **注意事项**：命令的特殊约束或风险提示

### 6.2 示例覆盖要求

每厂商至少覆盖以下内容：

- **操作类型**：query（查询）、inspect（巡检）、change（变更）
- **示例行为分类**：正例（有效操作）、负例（无效操作）、拒绝示例（超出能力的请求，非 operation_type 枚举值）
- **每厂商最少 3 个正例 + 1 个负例**
- **目标类型**：interface、vlan、route、acl、system

### 6.3 负例与反例规则

以下情况必须生成拒绝示例：

1. **不支持的操作**：如"配置 BGP"在阶段一知识库中无相关条目
2. **超范围请求**：如"升级设备操作系统"不在阶段一范围
3. **危险操作无确认**：如"重启设备"必须有明确用户确认

负例应明确说明拒绝原因并建议替代方案（如适用）。

### 6.4 示例质量控制

- **保持简洁**：每个示例不超过 10 行
- **厂商真实**：命令必须是真实可用的，不得虚构
- **不引入虚构命令**：所有命令必须在知识库或官方文档中有据可查

---

## §7 命令知识库结构规范

### 7.1 定位与边界

命令知识库用于辅助候选命令生成进行幻觉防护和生成依据标注。知识库条目的具体内容存放在 `tools/` 或 `lab/` 目录下，本文档仅规定其 Schema 与检索规范。

### 7.2 数据组织层级

知识库按以下层级组织：

```
vendor/
  ├── os_family/
  │   ├── command_entries/
  │   │   ├── entry_001.yaml
  │   │   ├── entry_002.yaml
  │   │   └── ...
```

- vendor：厂商名（huawei、h3c）
- os_family：操作系统系列（vrp、comware）
- command_entries：命令条目文件

#### 7.2.1 YAML 与 JSONL 的使用边界

本规范中的命令知识库条目默认以 **YAML** 为主格式，但这并不排斥在知识抽取、清洗、切块、入库前处理中使用 **JSONL** 作为中间层格式。

推荐原则如下：

- **YAML**：用于人工维护的知识条目、规则文件、少量高价值精选知识
- **JSONL**：用于批量抽取结果、ready 数据集、流水线中间层、增量导入导出

两者的优缺点与适用场景：

| 格式 | 优点 | 缺点 | 适用场景 |
|------|------|------|----------|
| YAML | 可读性强、适合人工编辑、支持层级表达、适合长期维护 | 大规模数据读写成本高、不适合超大文件流式处理、批量校验/统计不如 JSONL 方便 | 命令知识条目、规则配置、schema 模板、人工精选知识 |
| JSONL | 一行一条记录，适合流式处理、批量校验、增量更新、程序生成和向量化导入 | 可读性一般、不适合手工长期维护、注释能力弱 | 文档预处理 ready 产物、日志条目集、批量切块结果、入库前中间层 |

因此：

- **面向模型生成和人工维护的规范化命令知识库**，优先使用 YAML
- **面向大规模文档预处理与知识入库流水线**，允许并推荐使用 JSONL 作为中间层或 ready 产物

### 7.3 命令条目 Schema

每个命令条目必须包含以下字段：

- vendor：厂商名
- os_family：操作系统系列
- command_pattern：命令模式（如 `display interface {interface}`）
- full_syntax：完整语法说明
- mode：命令模式（user_view/system_view/interface_view等）
- intent_types：适用意图类型（query/inspect/change）
- target_types：适用目标类型（interface/vlan/route/acl/system）
- required_parameters：必填参数列表
- optional_parameters：可选参数列表
- forbidden_combinations：禁止的参数组合
- applicability：适用性（OS 版本范围、设备型号约束）
- expected_output_hint：预期输出提示（用于后续校验）
- risk_level：风险等级
- validation_tags：校验标签（如 needs_interface_exists）
- evidence_source：依据来源（官方文档链接、版本说明）
- confidence_floor：置信度下限（低于此值不得生成）

### 7.4 参数约束 Schema

每个参数定义包含：

- parameter_name：参数名
- type：参数类型（string/integer/enum）
- value_range：取值范围
- required：是否必填（true/false）
- default_value：默认值（如适用）

### 7.5 适用性与版本 Schema

- os_version_min：最低支持版本（如 "VRP8.0"）
- os_version_max：最高支持版本（如 "VRP8.5"）
- device_constraints：设备型号约束（如 "仅限 S 系列"）
- deprecated_info：废弃信息（如已废弃，说明替代命令）

### 7.6 检索与引用规则

候选命令生成环节通过以下方式引用知识库条目：

1. **通过 search_knowledge 工具**（TL2）检索相关条目
2. **generation_basis 字段**必须指向具体的知识库条目 ID 或明确的来源说明
3. **低置信度命令**必须标注"未在知识库中找到精确匹配"

---

## §8 幻觉防护与安全约束

### 8.1 分层防护策略

系统采用 6 层防护策略：

1. **提示词内约束**：明确的禁止指令与保守策略声明，包括流式输出纪律与工具调用约束
2. **知识库锚定**：生成的命令必须能在知识库中找到匹配模式
3. **tool_call 组装校验**：后端对 `generate_commands` 工具调用的参数进行组装校验，无效 JSON 静默跳过，不展示授权卡片
4. **输出结构校验**：验证 tool_call 参数是否符合 candidate_commands Schema
5. **语法校验**：命令语法合理性检查
6. **人工确认门控**：任何命令不得绕过用户确认直接执行

### 8.2 提示词内防护

- 明确禁止"基于训练数据记忆"生成命令
- 保守策略声明："无法确定时宁可不生成"
- 不确定时必须声明："此命令未在知识库中找到精确匹配，建议人工复核"
- 流式输出纪律约束：命令只能通过 `generate_commands` 工具调用输出，不得在文本流中直接嵌入 CLI 命令

### 8.3 知识库约束

- 生成的命令必须能在知识库中找到匹配模式
- 低置信度命令（< 0.6）必须标注"建议人工复核"
- 超出知识库范围的命令必须拒绝生成

### 8.4 校验前置条件

命令在执行前必须经过以下校验：

1. **tool_call 参数校验**：`generate_commands` 工具调用的参数是否为有效 JSON，是否对齐 candidate_commands Schema；无效参数静默跳过，不展示授权卡片
2. 结构校验：是否符合 API_SPEC.md §3.1 LG3 的响应格式
3. 语法校验：命令字符串是否符合厂商 CLI 规范
4. 风险校验：risk_level 是否为 high 且未获得明确确认
5. 设备存在性校验：目标设备是否在线且可访问

### 8.5 人工确认前不可跨越的边界

- 任何命令不得绕过用户确认直接执行
- risk_level 为 high 的命令必须显式警告
- 批量操作（如影响多个接口）必须列出完整清单供确认

---

## §9 LLM 错误处理与降级策略

### 9.1 工具调用失败

当主模型收到工具调用错误时：

1. **向用户解释错误原因**：如"设备 192.168.1.1 连接失败"
2. **不继续猜测**：不得基于错误结果继续生成命令
3. **建议替代方案**：如"检查设备连接状态或更换目标设备"

### 9.1.1 流式错误处理

在流式 agentic 调用过程中，需额外处理以下场景：

1. **连接中断**：流式连接意外断开时，后端应发送 `error` 类型的 StreamChunk，标记 `retryable: true`，前端可提示用户重试
2. **chunk 乱序**：基于 `seq` 序号检测乱序 chunk，丢弃 seq 不连续的 chunk，等待重传或超时
3. **tool_call delta 无效**：`tool_call_args_delta` 中的增量片段无法组装为有效 JSON 时，丢弃该 tool_call，不展示对应授权卡片
4. **tool_call 参数组装失败**：`generate_commands` 的 `rawArgs` 解析为无效 JSON 时，静默跳过该 tool_call，记录日志供分析

### 9.2 返回为空或冲突

当工具返回空结果或冲突信息时：

- **空结果**：向用户说明"未找到匹配设备/信息"，建议检查输入
- **冲突信息**：如设备状态与期望不符，向用户说明差异并请求澄清

### 9.3 模型输出非法

当模型输出了不符合 Schema 的内容时：

1. **重试一次**：用更明确的约束重新调用
2. **降级策略**：重试失败时，向用户说明"模型生成异常，请简化需求或人工处理"
3. **记录异常**：将异常输出记录到日志供分析
4. **tool_call 参数非法**：`generate_commands` 工具调用的参数无法解析或不符合 candidate_commands Schema 时，后端静默跳过该 tool_call，不向用户展示授权卡片，记录日志供分析

### 9.4 不支持厂商/能力不足

当识别到超出能力范围时：

1. **明确拒绝**：说明"此操作不在当前支持范围"
2. **说明限制**：列出当前支持的厂商、操作类型
3. **演进预留**：如适用，说明"计划在阶段二支持"

### 9.5 降级与人工接管

以下情况必须停止自动化流程，转为人工处理：

1. 模型连续 3 次生成非法输出
2. 工具调用连续失败且无法自动恢复
3. 用户明确要求的人工介入点（如"无法确定，请人工确认"）

---

## §10 Phase 3 SDN 工具预留

### 10.1 适用前提

以下工具不属于阶段一实现，仅作为 Phase 3 的交互预留；启用前提是 Phase 2 已完成设备分组、站点模型、拓扑关系读取、接口对象独立存储。

### 10.2 预留工具清单

| 工具名 | 用途 | 说明 |
|--------|------|------|
| `query_topology` | 查询统一拓扑视图 | 返回站点、设备、接口、链路、控制域等拓扑上下文 |
| `query_controller_capabilities` | 查询控制器能力与限制 | 返回控制器支持的能力、认证方式、目标范围限制 |
| `generate_controller_plan` | 生成控制器/API 级候选操作计划 | 输出结构化计划，不直接执行控制器写操作 |
| `analyze_topology_impact` | 分析任务影响范围 | 给出目标对象、影响链路、风险摘要、审批建议 |

### 10.3 交互纪律

- 主模型可以查询拓扑和控制器能力，但不得绕过审批链路直接下发控制器写操作。
- 控制器/API 级候选操作计划由意图与执行引擎统一生成（内部可调用模型辅助），而不是由命令生成调用单独自由拼接原始 API 请求。
- 任何涉及控制器/API 写入的计划都必须带有目标范围、影响摘要、生成依据与风险说明。
- SDN 工具的读取能力可先于写能力落地；写能力启用前必须接入 Phase 3 的 RBAC、审批、变更窗口与审计机制。

---

## 附录 A：提示词模板

### A.1 主模型系统提示词模板骨架

```
你是一个网络运维意图理解与调度专家。

## 角色定义
你的职责是：
1. 理解用户的自然语言运维需求
2. 选择合适的工具获取必要信息
3. 在同一个流式响应中同时输出解释文本和工具调用
4. 通过 generate_commands 工具生成候选命令

## 可用工具清单
{tool_definitions}

## 工具说明
- parse_intent：解析用户意图，输出标准化意图
- search_knowledge：搜索命令知识库
- query_device_status：获取设备实时状态
- list_devices：列出可用设备列表
- generate_commands：生成候选命令列表，参数为候选命令结构

## 工具选择策略
{tool_selection_matrix}

## 歧义处理规则
当出现以下情况时，必须向用户追问而非猜测：
- 用户未指定目标设备
- 设备厂商或型号不明确
- 操作类型存在歧义（查询还是变更）
- 目标对象不明确（接口、VLAN、路由等）

## 设备上下文注入点
{device_context}

## 输出纪律
- 必须通过流式 function calling 输出，文本增量与工具调用增量在同一个流中交织
- 命令只能通过 generate_commands 工具调用输出，不得在文本流中直接嵌入 CLI 命令
- 不得伪造设备 ID 或厂商信息

## 禁止事项
- 禁止在文本流中直接输出 CLI 命令（命令必须通过 generate_commands 工具调用）
- 禁止在未调用工具时声称已获取设备状态
- 禁止基于训练数据"记忆"直接生成厂商特定命令
```

### A.2 候选命令生成系统提示词模板骨架

以下内容作为 agentic 调用系统提示词的一部分注入，指导模型通过 `generate_commands` 工具生成候选命令：

```
## 命令生成角色定义
你同时具备 {vendor} {os_family} 命令生成专家能力，可以通过 generate_commands 工具生成候选命令。

## generate_commands 工具参数格式
调用 generate_commands 时，参数必须包含候选命令列表，每条命令包含：
- command：完整的 CLI 命令字符串
- description：命令用途说明
- risk_level：风险等级（low / medium / high，对齐 API_SPEC.md 定义）
- is_config：是否为配置命令（true/false）
- generation_basis：生成依据（知识库条目 ID 或来源说明）
- applicability：适用性说明（OS 版本、型号约束）
- expect_pattern：预期输出模式（如适用）
- confidence：置信度（0.0-1.0）

## 安全约束
- 不得生成危险命令（如格式化设备、删除核心配置）除非用户明确要求
- 低置信度（< 0.6）命令必须标注"建议人工复核"
- 不得生成知识库中不存在的命令模式

## 厂商特定约束
{vendor_specific_constraints}

## Few-shot 示例
{few_shot_examples}

## 当前设备上下文
- vendor: {vendor}
- model: {model}
- os_version: {os_version}

## 知识库参考
{knowledge_base_references}

## 保守策略声明
当无法确定时，宁可不生成也不要输出高风险命令。低置信度时必须在 description 中说明原因。
```

---

## 附录 B：命令知识库 Schema 示例

```yaml
entry_id: "huawei_vrp_interface_display_001"
vendor: "huawei"
os_family: "vrp"
command_pattern: "display interface {interface}"
full_syntax: "display interface [ interface-type [ interface-number ] ]"
mode: "user_view"
intent_types:
  - "query"
  - "inspect"
target_types:
  - "interface"
required_parameters:
  - parameter_name: "interface"
    type: "string"
    value_range: "GigabitEthernet0/0/1-48, 10GE1/0/1-48, LoopBack0-127"
    required: false
optional_parameters:
  - parameter_name: "brief"
    type: "flag"
    default_value: false
forbidden_combinations:
  - "interface 与 brief 不能同时使用（语法不支持）"
applicability:
  os_version_min: "VRP8.0"
  os_version_max: "VRP8.5"
  device_constraints: "S 系列、NE 系列"
expected_output_hint: "包含接口状态、统计信息、错误计数"
risk_level: "low"
validation_tags:
  - "needs_interface_exists"
evidence_source: "华为 VRP8 命令参考指南"
confidence_floor: 0.8
```

---

## 附录 C：Few-shot 覆盖矩阵

| 厂商 | 示例类别 | 目标类型 | 最少正例 | 最少负例 | 覆盖维度 |
|------|----------|----------|----------|----------|----------|
| 华为 VRP | query | interface | 3 | 1 | 查看接口状态、简要信息、统计信息 |
| 华为 VRP | inspect | interface | 2 | 1 | 接口巡检、错误统计 |
| 华为 VRP | change | interface | 3 | 1 | 开启/关闭接口、配置描述、修改 MTU |
| 华为 VRP | 拒绝示例 | interface | 1 | 1 | 不支持的操作（如修改硬件属性） |
| 华为 VRP | query | vlan | 3 | 1 | 查看 VLAN 列表、具体 VLAN、端口归属 |
| 华为 VRP | change | vlan | 3 | 1 | 创建 VLAN、配置描述、批量创建 |
| H3C Comware | query | interface | 3 | 1 | 查看接口状态、简要信息、统计信息 |
| H3C Comware | inspect | interface | 2 | 1 | 接口巡检、错误统计 |
| H3C Comware | change | interface | 3 | 1 | 开启/关闭接口、配置描述、修改 MTU |
| H3C Comware | 拒绝示例 | interface | 1 | 1 | 不支持的操作 |
| H3C Comware | query | vlan | 3 | 1 | 查看 VLAN 列表、具体 VLAN、端口归属 |
| H3C Comware | change | vlan | 3 | 1 | 创建 VLAN、配置描述、批量创建 |

注：上述数量为阶段一最低要求，后续演进可根据需要扩展。
