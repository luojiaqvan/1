# 技术架构文档

## 1. 文档说明

### 1.1 文档定位

本文档是"大模型 + 网络工程配置/运维平台"阶段一技术架构冻结基线。定义组件结构、跨组件交互约束和运行时不变量。

### 1.2 与其他文档的关系

| 文档 | 权威职责 | 与本文档的关系 |
|------|----------|---------------|
| ROADMAP.md | 项目范围、建设路线、功能跟踪 | 范围权威。本文档的结构和约束不超出 ROADMAP 定义的范围 |
| API_SPEC.md | 接口契约、数据模型、SSE 事件 | 接口权威。组件间调用关系、数据格式、状态定义以 API_SPEC 为准，本文档不重新定义 |
| AGENTS.md | 协作规则、文档风格 | 协作权威。本文档遵循 AGENTS.md 的风格与提交规范 |

### 1.3 读者对象

- 后端开发者：实现组件接口、数据流、设计模式
- 前端开发者：理解后端接口、SSE 推送机制
- 架构师：评估设计决策、扩展性、可维护性
- DevOps 工程师：理解组件边界（部署架构见后续文档）

### 1.4 文档范围

**包含：**
- 组件职责与边界
- 核心数据流与交互模式
- 设计模式与约定
- 阶段一可扩展性设计
- 安全性设计
- 阶段一边界与约束

**不包含：**
- 部署架构（容器编排、服务发现、负载均衡等）
- 具体代码实现（类名、方法签名等）
- 运维手册（监控、告警、备份等）

### 1.5 内容分类

本文档内容分为两类：

| 分类 | 含义 | 标识 |
|------|------|------|
| 冻结内容 | 阶段一开发期间不可变更的架构约束 | 无特殊标识（默认为冻结） |
| 演进预留 | 当前阶段不落地，标注了后续方向的预留点 | 标注"（演进预留）" |

冻结内容包括：组件职责与边界（§3）、核心数据流（§4）、设计约束（§7）、运行时约束（§10）。
演进预留内容仅在 §8（可扩展性设计）中出现，且每条预留都标注"（演进预留）"和目标阶段。

---

## 2. 架构总览

### 2.1 架构分层

项目采用分层架构，上层调用下层，同层模块间通过明确接口交互。见 ROADMAP.md §4 总体架构。

```mermaid
graph TD
    User[用户 / 运维工程师] --> WebGUI[Web GUI<br/>Next.js + React + TS]

    WebGUI -->|HTTP/SSE| API[后端 API 服务<br/>FastAPI]

    API -->|进程内调用| LLMGW[大模型网关<br/>LiteLLM 封装]
    API -->|进程内调用| Intent[意图与执行引擎]
    API -->|进程内调用| Device[统一设备管理程序]
    API -->|进程内调用| Audit[审计服务]

    Intent -->|函数调用| LLMGW
    Intent -->|进程内调用| Vendor[厂商适配层]
    Intent -->|进程内调用| Knowledge[知识检索引擎]
    Intent -->|进程内调用| Tools[函数调用与工具层]

    Device -->|netmiko| Sim[模拟器 / 设备<br/>eNSP / HCL]

    LLMGW -.->|外部 HTTP| Model[模型服务<br/>OpenAI 兼容 API]

    API -->|SQL| DB[(SQLite)]

    style User fill:#e1f5ff
    style WebGUI fill:#fff4e1
    style API fill:#ffe1e1
    style LLMGW fill:#e1ffe1
    style Intent fill:#ffe1ff
    style Device fill:#e1ffff
    style DB fill:#f0f0f0
    style Model fill:#f5f5f5
```

### 2.2 阶段一架构特性

**进程内单服务架构**

- 所有内部服务（大模型网关、意图引擎、设备管理程序、审计服务）为 Python 进程内模块
- 内部服务间通过函数调用交互，而非 HTTP/gRPC
- API_SPEC.md 中定义的内部服务接口（LG1-IE5、DM1-DM7、KR1-KR2、AU1-AU3、VA1-VA5）为模块级接口契约
- 阶段一不拆微服务

**约束：**
- 水平扩展需复制整个服务
- 单进程内存限制（阶段一数据量可控）
- 语言栈统一为 Python（前端独立部署）

### 2.3 调用方式标注

| 调用方式 | 示例 | 说明 |
|---------|------|------|
| HTTP | 前端 → 后端 API | 跨语言、跨进程调用 |
| SSE | 后端 → 前端 | 服务端推送实时事件 |
| 进程内函数调用 | 后端 API → 意图引擎 | 同一 Python 进程内的模块调用 |
| 外部 HTTP | 大模型网关 → 模型服务 | 调用外部 OpenAI 兼容 API |
| netmiko | 设备管理程序 → 设备 | SSH/Telnet 连接 |

---

## 3. 组件职责与边界

### 3.1 组件职责表

| 组件名 | 核心职责 | 对外接口（API_SPEC 编号） | 依赖组件 | 不负责事项 |
|--------|----------|---------------------------|----------|------------|
| 后端 API 服务 | 为前端提供 RESTful/SSE 接口，用户认证，数据持久化，SSE 推送 | §2 全部前端 API | 大模型网关、意图引擎、设备管理程序、审计服务、SQLite | 意图标准化与候选命令收口由意图引擎负责；设备执行由设备管理程序负责 |
| 大模型网关 | 兼容 OpenAI API，路由不同模型，限流、日志、流式输出 | 统一流式 Agentic 调用接口 | 模型服务（外部） | 不包含意图解析和命令生成逻辑 |
| 意图与执行引擎 | 标准化意图，候选命令组装/冻结/校验，输出前端可消费的意图卡片与授权 proposal | IE1、IE3 | 大模型网关、厂商适配层、知识检索引擎、工具层、设备管理程序、审计服务 | 不直接持有设备连接，不直接操作终端会话，不负责执行编排与结果回收 |
| 厂商适配层 | 根据结构化意图生成厂商特定候选命令，语法校验，输出解析 | VA1-VA5 | 知识检索引擎 | 不直接调用设备，不持有执行权 |
| 统一设备管理程序 | 设备清单 CRUD，凭据加密，连接管理，命令执行，结果归一化 | DM1-DM7 | netmiko、SQLite | 不生成命令，不校验意图 |
| 知识检索引擎 | 检索厂商文档、SOP、历史案例、命令参考 | KR1-KR2 | SQLite、外部知识源 | 不生成命令，不执行设备操作 |
| 审计服务 | 记录审计事件，查询审计日志，任务审计链路 | AU1-AU3 | SQLite | 不处理业务逻辑 |
| 函数调用与工具层 | 以 skills + MCP 组合向主模型暴露结构化工具能力（含 TL5 generate_commands），并统一收口连接发现、执行封装与设备操作 | TL1-TL5、MCP-C1、MCP-C2 | 意图引擎、设备管理程序 | 不直接调用大模型 |

### 3.2 组件依赖关系

```mermaid
graph TD
    API[后端 API 服务] --> LLMGW[大模型网关]
    API --> Intent[意图与执行引擎]
    API --> Device[统一设备管理程序]
    API --> Audit[审计服务]
    API --> DB[(SQLite)]

    Intent --> LLMGW
    Intent --> Vendor[厂商适配层]
    Intent --> Knowledge[知识检索引擎]
    Intent --> Tools[函数调用与工具层]
    Intent --> Device
    Intent --> Audit

    Vendor --> Knowledge

    Tools --> Device

    Device --> DB
    Knowledge --> DB
    Audit --> DB

    LLMGW --> Model[模型服务<br/>外部]
    Device --> Sim[设备<br/>netmiko]

    style API fill:#ffe1e1
    style LLMGW fill:#e1ffe1
    style Intent fill:#ffe1ff
    style Device fill:#e1ffff
    style DB fill:#f0f0f0
    style Model fill:#f5f5f5
```

**依赖方向说明：**
- 上层调用下层：后端 API 调用所有内部服务
- 同层协作：意图引擎产出冻结 proposal，设备管理程序消费已确认 proposal 执行命令
- 无循环依赖：厂商适配层被意图引擎调用，不反向调用意图引擎

### 3.3 用户级模型配置职责边界

用户级模型配置仍然以数据库为最终来源。每用户可保存多套模型配置（如"生产 GPT-4o"、"本地 Ollama"），同时只有一套处于激活状态（`is_active = 1`）。阶段一的职责边界应明确如下：

- **后端 API 服务负责配置来源管理**：
  - 从 `user_model_configs` 表读取当前用户的**激活配置**（`is_active = 1` 的行）
  - 完成解密、优先级合并（数据库用户激活配置 > 环境变量 > 代码默认值）
  - 后端为每次 agentic 调用传入用户激活配置的运行时对象
  - 配置切换为原子操作：在同一事务中将旧激活配置的 `is_active` 置 0、新配置置 1
  - 以进程内参数形式将配置对象传给大模型网关

- **大模型网关负责配置消费与执行安全**：
  - 接收后端传入的网关配置对象，而不是直接访问数据库
  - 校验 `model`、`api_base`、`api_key`、`timeout_seconds` 等字段是否合法
  - 将模型标识归一化为 LiteLLM 可执行格式（如需要 provider 前缀时补全）
  - 将配置对象与本次请求参数合并后转换为 LiteLLM 调用参数

- **大模型网关不负责**：
  - 直接查询 `user_model_configs` 表
  - 直接解密数据库中的模型 API Key
  - 决定当前用户最终使用哪一套模型配置

---

## 4. 核心数据流

### 4.1 用户消息处理全流程

从用户发送消息到 SSE 推送完成的完整时序，对齐 API_SPEC.md §4.5 事件时序。

```mermaid
sequenceDiagram
    participant U as 用户浏览器
    participant API as 后端 API 服务
    participant LLM as 大模型网关
    participant Intent as 意图与执行引擎
    participant DB as SQLite
    participant SSE as SSE 推送

    U->>API: POST /api/v1/conversations/{id}/messages
    API->>DB: 保存 user 消息
    API-->>U: 202 Accepted (message_id, task_id)

    par 单次 Agentic 调用
        API->>LLM: Agentic 调用（正文/思考内容 + 工具调用）
        loop 流式输出
            LLM-->>API: text_delta / reasoning_delta / tool_call_* chunks
            API->>SSE: stream_text 事件（文本增量）
            API->>SSE: stream_reasoning 事件（思考内容增量，如有）
        end
        LLM-->>Intent: tool_call_complete（parse_intent / generate_commands）
        Intent->>Intent: IE1 标准化意图
        Intent->>Intent: IE3 组装校验候选命令 proposal
        Intent->>DB: 更新任务状态为 running
        API->>SSE: run_started 事件
        API->>SSE: intent_parsed 事件
        API->>SSE: approval_required 事件（冻结的候选命令）
    end

    U->>API: POST /api/v1/tasks/{id}/confirm
    API->>Device: 基于已确认 proposal 调用 DM7 执行命令
    ...（执行阶段不变）
```

### 4.2 设备操作任务流程

意图解析到命令执行的核心流程。阶段一中，`llm/intent_engine` 仅负责意图标准化与候选命令 proposal 的系统侧收口；实际执行由执行层在消费已确认 proposal 后调用设备管理程序完成。

```mermaid
sequenceDiagram
    participant User as 用户
    participant API as 后端 API
    participant LLM as 大模型网关
    participant Intent as 意图与执行引擎
    participant Device as 设备管理程序
    participant Dev as 设备

    User->>API: 自然语言请求
    API->>LLM: 单次 Agentic 调用
    LLM-->>API: 正文流/完整响应 + 思考内容 + tool_calls（parse_intent + generate_commands）
    API->>Intent: IE1 标准化意图
    API-->>User: 正文消息 + 折叠思考区 + 意图卡片

    Intent->>Intent: IE3 组装校验 generate_commands tool_call
    Intent-->>API: approval_required
    API-->>User: 展示授权卡片（从已冻结 proposal 渲染）

    User->>API: 确认执行
    API->>Device: 消费已确认 proposal 调用 DM7

    par 多设备并行
        Device->>Dev: netmiko 执行命令
        Dev-->>Device: 原始输出
    end

    Device->>API: execution_completed
    API->>LLM: 流式生成结果总结
    LLM-->>API: 结果总结文本
    API-->>User: 展示结果卡片 + 模型总结
```

#### 4.2.1 知识库驱动候选命令生成约束

阶段一正常模式下，候选命令生成必须经过知识检索引擎，且在进入前端展示与执行层前必须经过 `llm/intent_engine` 的 IE3 收口，流程如下：

```text
主模型（单次流式 agentic 调用）
  → KR1.search / KR2.get_device_context
  → 组装 knowledge_refs
  → VA1.get_system_prompt 提供厂商约束
  → 模型在同一流式调用中通过 generate_commands 工具提交候选命令
  → IE3.assemble_and_validate_candidates
  → 推送 approval_required 事件
```

约束：

- **知识检索结果、模型生成结果与厂商约束必须在 IE3 收口后才能进入前端与执行层**。调用方不得跳过该收口步骤直接渲染授权卡片或直接执行命令。
- **厂商适配层负责提供厂商约束、few-shot、模板和语法校验，不负责在正常模式下直接替代主模型的候选命令生成主路径。**
- **后端负责把原始 tool_call 提交给 `llm/intent_engine` 进行组装和校验。仅当 JSON 有效且通过结构校验后，才推送 approval_required 事件。无效 tool_call 不推送。**
- **模板生成仅能作为降级路径存在**；若知识检索失败或无匹配条目，候选命令生成阶段必须显式将本次生成标记为 `template_fallback`。
- `generation_basis` 必须能够回溯到 `knowledge_refs` 或冻结模板来源，以支撑审计、问题回放与幻觉防护。

### 4.3 SSE 推送机制

SSE 连接建立、事件分发、断线重连流程。

```mermaid
sequenceDiagram
    participant Client as 前端
    participant API as 后端 API
    participant SSE as SSE 管理器
    participant EventBus as 事件总线

    Client->>API: GET /api/v1/sse (Bearer Token)
    API->>API: 校验 token
    API->>SSE: 创建 SSE 连接
    SSE-->>Client: sse_connected 事件

    loop 心跳
        SSE-->>Client: sse_heartbeat 事件 (每 30s)
    end

    par 任务执行推送
        Intent->>EventBus: 发布事件
        EventBus->>SSE: 订阅事件
        SSE-->>Client: task/intent/command/execution 事件
    end

    Client-->>SSE: 连接断开

    Client->>API: 重连 (Last-Event-ID)
    API->>SSE: 恢复连接
    SSE-->>Client: sse_connected 事件
```

#### 4.3.1 思考内容归一化约束

为兼容 OpenAI 兼容端口下不同模型对 reasoning / thinking 内容的返回差异，后端必须在网关层完成归一化：

- **流式上游**：若模型以增量方式返回思考内容，网关将其转换为内部 `reasoning_delta` chunk，并通过 SSE 推送 `stream_reasoning`
- **非流式上游**：若模型仅在最终响应中返回完整思考内容，网关在收到完整响应后一次性发布 `stream_reasoning`，随后立即发布 `stream_reasoning_end`
- **无思考内容上游**：不生成 `reasoning` 相关 chunk/Event，前端不渲染思考折叠区

前端只依赖统一的 SSE / 消息对象契约，不直接感知上游模型到底是流式还是非流式返回思考内容。

#### 4.3.2 前端展示约束

- assistant 消息正文与思考内容分区展示
- 思考内容默认折叠，用户手动展开后可查看完整思考内容
- 正文区域不得混入思考内容，避免把模型内部推理与面向用户的最终答复混排
- 历史消息回放时，若消息带有 `reasoning` / `reasoning_content`，仍按默认折叠规则展示

### 4.4 设备连接管理

设备 CRUD + 凭据加密 + test-connection 流程。

```mermaid
sequenceDiagram
    participant User as 用户
    participant API as 后端 API
    participant Device as 设备管理程序
    participant Crypto as 加密模块
    participant DB as SQLite
    participant Dev as 设备

    User->>API: POST /api/v1/devices (明文凭据)
    API->>Crypto: 加密用户名、密码
    Crypto-->>API: 加密后凭据
    API->>Device: DM1 register_device
    Device->>DB: 保存设备信息（加密凭据）
    DB-->>API: device_id
    API-->>User: 201 Created

    User->>API: POST /api/v1/devices/{id}/test-connection
    API->>Device: DM6 test_connection
    Device->>Crypto: 解密凭据
    Crypto-->>Device: 明文凭据
    Device->>Dev: netmiko 连接
    Dev-->>Device: 设备信息
    Device-->>API: 连接结果
    API-->>User: success, latency_ms, device_info

    User->>API: GET /api/v1/devices
    API->>DB: 查询设备列表（不含凭据）
    DB-->>API: 设备列表
    API-->>User: 设备列表
```

---

## 5. 技术选型决策与约束

### 5.1 选型决策表

| 选型 | 选型理由 | 带来的约束 | 已知风险 | 替代方案（未选原因） |
|------|----------|------------|----------|---------------------|
| Python + FastAPI | 异步高性能、类型安全、自动 API 文档、生态成熟 | 团队需熟悉 Python async/await | async/await 学习曲线 | Flask（同步性能低）、Django（重） |
| SQLite | 零部署、单文件、ACID 事务、嵌入式、适合阶段一单机开发 | 不支持并发写入、不适合多进程部署 | 并发写入性能有限（后续阶段可迁移到 PostgreSQL） | PostgreSQL（需独立部署）、MySQL（JSON 支持弱）、MongoDB（事务弱） |
| netmiko | 多厂商支持、成熟稳定、社区活跃 | 仅支持 SSH/Telnet，不支持 NETCONF | 部分新厂商设备支持不完善 | Paramiko（底层、需自己封装）、NAPALM（支持设备少） |
| LiteLLM | OpenAI 兼容、多模型路由、限流日志 | 需锁定版本，防止被投毒 | 版本更新可能引入不兼容 | 从零实现（工作量大）、LangChain（过重） |
| Next.js + React + TypeScript | SSR、类型安全、生态成熟、开发体验好 | 构建复杂度、学习曲线 | 版本升级频繁 | Vue（团队不熟）、Svelte（生态小） |
| JWT 认证 | 无状态、跨语言、标准成熟 | 阶段一采用 token 黑名单支持主动登出 | Token 泄露风险 | Session（需状态存储）、OAuth 2.0（过重） |
| bcrypt 密码哈希 | 抗彩虹表、自适应难度 | 计算慢（但可接受） | GPU 加速破解风险 | PBKDF2（较弱）、scrypt（库支持少） |

### 5.2 LiteLLM 版本锁定约束

根据 ROADMAP.md §5.3 的安全要求：

**必须锁定 LiteLLM 依赖版本：**
- 在 `requirements.txt` 或 `pyproject.toml` 中锁定完整版本号（如 `litellm==1.x.x`）
- 使用 `pip install --require-hashes` 验证包完整性
- 从官方源安装，定期检查版本变更日志与社区安全通告
- 定期更新到受支持的安全版本，但不自动升级

**原因：**
- LiteLLM 是网络依赖包，存在供应链攻击风险
- 锁定版本可防止恶意版本被自动拉取
- 哈希验证可确保包完整性

### 5.3 阶段一不包含的选型

| 技术领域 | 阶段一策略 | 后续阶段考虑 |
|---------|-----------|-------------|
| 消息队列 | 不使用，进程内调用 | Phase 3 拆微服务时引入 RabbitMQ/Kafka |
| 缓存 | 不使用，直接查数据库 | Phase 2 引入 Redis 缓存设备状态 |
| 容器编排 | 不使用，本地部署 | Phase 3 引入 Kubernetes |
| 服务网格 | 不使用 | Phase 3 微服务化后考虑 |
| 配置中心 | 不使用，环境变量 + 数据库 | Phase 3 多环境时引入 |

---

## 6. 目录结构设计

### 6.1 高层目录职责

| 目录 | 职责 | 对应组件 |
|------|------|----------|
| backend/api/ | RESTful/SSE 路由、认证中间件、请求校验 | 后端 API 服务 |
| backend/device_manager/ | 设备 CRUD、凭据加密、连接管理、命令执行 | 统一设备管理程序 |
| backend/audit_service/ | 审计日志记录与查询 | 审计服务 |
| backend/db/ | 数据库模型、会话管理、数据访问层 | 数据库 |
| backend/sse/ | SSE 连接管理、事件总线 | SSE 推送 |
| llm/llm_gateway/ | LiteLLM 封装、模型路由、流式输出 | 大模型网关 |
| llm/intent_engine/ | 意图解析、命令生成、执行编排 | 意图与执行引擎 |
| llm/intent_engine/vendor/ | 厂商适配器（华为/H3C） | 厂商适配层 |
| llm/knowledge_service/ | 知识检索、命令参考 | 知识检索引擎 |
| llm/tools/ | 工具定义与处理 | 函数调用与工具层 |
| frontend/web-console/ | Next.js 前端应用 | Web GUI |
| docs/ | 项目文档 | — |
| lab/ | 模拟器拓扑与配置 | — |

### 6.2 命名约定

具体命名约定见各模块 README。架构层约束：

- Python 模块/函数：小写下划线
- Python 类：大驼峰
- API 路由：小写连字符
- 数据库表：小写下划线
- React 组件：大驼峰 + `.tsx`

---

## 7. 设计模式与约定

### 7.1 错误处理模式

**分层错误处理：**

| 层级 | 错误类型 | 处理方式 | 传播方式 |
|------|----------|----------|----------|
| 设备层 | 连接失败、超时、命令语法错误 | DeviceError，记录日志，返回结构化错误 | 抛出到意图引擎 |
| 意图引擎 | 意图解析失败、命令生成失败 | IntentError，记录审计日志 | 抛出到 API 层 |
| API 层 | 认证失败、参数错误、服务异常 | HTTPException，统一错误响应（API_SPEC §1.2.1） | 返回前端 |

**错误传播约定：**
- 设备层错误不影响其他设备执行（多设备并行）
- 意图引擎错误记录到 `tasks.error_message`，任务状态置为 `failed`
- API 层错误统一通过 `middleware/error_handler.py` 转换为 HTTP 错误响应

### 7.2 审计日志记录模式

**必须记录的审计节点：**

审计事件集合以 API_SPEC.md §3.5 AU1 为唯一权威（共 14 个事件类型）。

**额外记录约定：**
- 所有事件通过 `audit_service.log_event()` 记录
- 事件记录在任务开始前和完成后，不可遗漏
- 审计日志只 INSERT，不 UPDATE/DELETE（见 API_SPEC.md §5.1）
- 敏感信息（明文凭据、明文 API Key）不记录到审计日志

### 7.3 异步任务编排模式

**任务状态机：**

对齐 API_SPEC.md §5.1 tasks 表状态机。

```
running → pending_approval → executing → completed
                           → rejected
                executing → failed
```

**状态转换规则：**

| 当前状态 | 允许的下一状态 | 触发条件 |
|---------|---------------|----------|
| running | pending_approval | 后端完成 tool_call 组装校验 |
| running | failed | Agentic 调用失败 |
| pending_approval | executing | 用户确认 |
| pending_approval | rejected | 用户拒绝 |
| executing | completed | 所有命令执行成功 |
| executing | failed | 任一命令执行失败 |

**状态边界约束：**
- 上表定义的是**对外任务主状态机**，同时约束数据库 `tasks.status`、前端任务状态展示和 SSE 主状态事件。
- 意图解析、知识检索、命令生成、结果总结等实现细节，属于**内部子阶段**，不得直接扩展 `tasks.status` 枚举。
- 如需暴露内部细粒度过程，应通过新增 `substage` 字段、审计事件或内部 trace 实现，而不是复用主状态字段。

**异步执行模式：**
- 用户确认后，`IE4.execute_commands` 立即返回，任务进入 `executing` 状态
- 实际执行在后台异步进行，通过 SSE 推送进度
- 多设备并行执行，单设备串行执行命令
- 执行结果实时写入 `tasks.execution_results`，前端轮询或通过 SSE 获取

### 7.4 配置管理模式

**配置优先级（高到低）：**

1. 数据库用户激活配置（`user_model_configs.is_active = 1`）
2. 环境变量（.env）

**配置加载约定：**
- 数据库连接等基础配置仅从环境变量加载（SQLite 数据库文件路径等）
- 每用户可保存多套模型配置，运行时只读取当前激活配置
- 若用户无激活配置，则退回环境变量默认模型配置
- JWT 配置和加密密钥仅从环境变量加载
- 配置切换由后端 API 服务负责，网关只消费已选定的运行时配置对象

**敏感配置管理：**
- `jwt_secret_key`、`credential_encryption_key` 仅从环境变量加载
- 各模型配置的 API Key 加密存储在数据库（`user_model_configs` 表）
- .env 文件不提交到仓库（加入 .gitignore）

### 7.5 凭据加密与解密模式

**加密边界：**

| 阶段 | 位置 | 形式 | 说明 |
|------|------|------|------|
| 前端输入 | 用户浏览器 | 明文 | HTTPS 传输 |
| 后端接收 | API 层 | 明文 | 仅在内存中短暂存在 |
| 存储前 | 加密模块 | 加密 | 使用 Fernet 对称加密 |
| 数据库 | devices/user_model_configs 表 | 加密（BLOB） | 永远不解密到日志 |
| 使用时 | 设备管理程序 | 解密 | 仅在内存中解密，不落盘 |
| 传输到设备 | netmiko | 明文 | SSH/Telnet 加密通道 |

**加密/解密约定：**
- 使用 Fernet 对称加密（基于 AES-128-CBC）
- 加密仅在存储前进行，解密仅在设备连接时在内存中进行
- 使用后立即清除内存中的明文
- 加密模块独立封装，供设备管理程序调用

**密钥管理：**
- 加密密钥从环境变量 `CREDENTIAL_ENCRYPTION_KEY` 加载
- 密钥为 32 字节 URL-safe base64 编码（Fernet 要求）
- 生产环境密钥通过安全管理工具（如 Vault）管理
- 禁止将密钥硬编码到代码中

### 7.6 SSE 事件推送模式

**事件推送约束：**
- 后端通过事件总线分发 SSE 事件，各组件发布事件到总线，SSE 管理器订阅并推送到前端
- 事件格式严格遵循 API_SPEC.md §4 SSE 事件类型定义
- 事件推送与业务逻辑解耦：业务组件只负责发布事件，不关心推送实现

**客户端消费约束：**
- SSE 连接使用 GET /api/v1/sse（见 API_SPEC.md §2.5）
- 认证 token 通过 URL query parameter 传入（浏览器原生 EventSource 不支持自定义 headers，因此阶段一使用 `GET /api/v1/sse?token=<jwt>` 方式）
- 断线后使用 Last-Event-ID 自动重连
- 每个用户维持一个 SSE 连接

---

## 8. 可扩展性设计

### 8.1 新厂商适配扩展方式

**需要实现的接口（VA1-VA5）：**

| 接口 | 职责 | 必须实现 |
|------|------|----------|
| VA1.get_system_prompt | 厂商特定系统提示词 + few-shot 示例 | 是 |
| VA2.get_command_templates | 命令模板（可选，阶段一可用模型生成） | 否 |
| VA3.validate_command_syntax | 厂商特定语法校验 | 是 |
| VA4.parse_output | 解析设备回显为结构化数据 | 是 |
| VA5.get_supported_operations | 支持的操作列表 | 是 |

**新增厂商步骤：**
1. 在 `llm/intent_engine/vendor/` 下创建新厂商文件（如 `cisco.py`）
2. 继承 `VendorAdapter` 基类
3. 实现 VA1-VA5 接口
4. 在 `devices` 表中添加新 vendor 枚举值
5. 在 `llm/knowledge_service/data/` 下添加对应命令参考文件

### 8.2 新工具注册方式

**扩展约束：**
- 面向模型暴露的逻辑工具由 **skill + 可选 mcp binding + provider schema** 组合而成，见 API_SPEC.md §3.7
- 网关内部仍可编译为 OpenAI function calling 格式，但该 provider-specific 格式不再作为长期权威来源
- 新增工具至少需要同步更新：skill 定义（如 `llm/tools/skills.py`）、逻辑工具定义（如 `llm/tools/tool_definitions.py`）、工具处理器（`llm/tools/handlers.py`）
- 若该工具需要连接发现或命令执行，还必须更新 MCP 注册/绑定定义（如 `llm/tools/mcp_registry.py`）

**最小 MCP 能力要求：**
- `list_connections`：列出当前作用域下可用连接/机器摘要
- `execute_command`：在指定机器/连接上执行命令并返回结果

**安全约束：**
- `execute_command` 虽属于 MCP 基础能力，但默认不得在候选命令生成阶段直接暴露给主模型
- 阶段一默认仍通过 IE4 → DM7 完成审批后的执行

### 8.3 新协议扩展方式

**阶段一协议：** SSH、Telnet（通过 netmiko）

**后续扩展（演进预留）：** NETCONF、RESTCONF、gNMI

**扩展约束：**
- 在 `device_manager/` 下创建新协议模块
- 实现 DM7 `execute_on_device` 接口
- 在 `devices` 表中添加新 protocol 枚举值

### 8.4 后续阶段扩展点标注

**Phase 2：模拟器内受控执行（演进预留）**

需要在现有接口上新增：

| 组件 | 新增接口 | 说明 |
|------|----------|------|
| 意图引擎 | `generate_candidate_config` | 生成候选配置（非命令） |
| 意图引擎 | `run_simulation` | 模拟器内验证 |
| 设备管理程序 | `capture_config_snapshot` | 捕获配置快照 |
| 意图引擎 | `post_check` | 执行后状态比对 |
| 意图引擎 | `rollback` | 回滚到执行前状态 |

**Phase 3：策略与安全增强（演进预留）**

需要新增组件：

| 组件 | 职责 |
|------|------|
| 策略服务 | RBAC、审批流、变更窗口、命令/工具/控制器 API 白名单 |
| 审批引擎 | 审批单创建、审批、驳回 |

**架构预留：**
- 阶段一所有组件通过接口契约交互，方便后续拆分为微服务
- 审计日志包含 `event_type`，方便后续添加策略检查点
- 任务状态机严格遵循 API_SPEC.md §5.1 定义，阶段一不引入额外状态

### 8.5 Phase 3 SDN 能力（演进预留）

**前置依赖：**

- Phase 2 已完成设备分组、站点模型、拓扑关系读取、接口对象独立存储
- `device_manager/` 已具备协议扩展能力，可承接 NETCONF / RESTCONF / gNMI / 控制器 API

**需要新增组件：**

| 组件 | 职责 |
|------|------|
| SDN 控制器接入层 | 统一封装控制器连接、能力发现、拓扑同步、控制器/API 调用 |
| 拓扑服务 | 基于站点、设备、接口、链路与控制域形成统一拓扑视图，提供影响范围分析 |
| 前端拓扑可视化组件（Web GUI 子组件） | 渲染统一拓扑图，展示控制器状态、任务影响范围、审批关联信息 |

**集成边界：**

- Web GUI 不直接访问控制器，仍通过后端 API 获取拓扑、控制器状态与候选操作计划。
- 前端拓扑可视化是 Phase 3 的必需能力，不是可选增强；其数据只来源于后端 API 聚合结果。
- 主模型不直接调用控制器写接口；若 Phase 3 启用专用命令生成模型，该模型同样不得直接调用控制器写接口。控制器/API 级写操作统一由意图与执行引擎编排，经策略服务与审批引擎门控后执行。
- 统一设备管理程序继续负责底层协议、凭据、连接与结果归一化；SDN 控制器接入层在其协议扩展与拓扑基础之上工作。
- 审计服务需记录控制器读取、控制器写入、拓扑同步、审批结果等事件，但阶段一事件集合不因此改变。

**前端显示约束：**

- 前端拓扑页面至少展示节点、链路、节点状态、控制域归属、最近同步时间。
- 前端拓扑页面应支持按站点、控制器、任务、审批状态进行筛选。
- 前端拓扑页面应支持对任务影响范围进行高亮，但不直接承载控制器写操作的执行逻辑。

**建议数据流（演进预留）：**

1. 用户提交涉及拓扑或控制器的请求。
2. 后端 API 调用意图与执行引擎生成控制器/API 级候选操作计划。
3. 意图与执行引擎调用拓扑服务补充影响范围，再调用策略服务检查权限、变更窗口、目标范围与白名单。
4. 通过审批后，由 SDN 控制器接入层执行计划，并将结果写入审计与 SSE 事件流。

**约束：**

- Phase 3 的 SDN 能力是对现有架构的增量扩展，不改变阶段一单进程、接口契约驱动的基本架构。
- 新增控制器/API 级状态不得破坏阶段一任务主状态机；如需细化，仅作为 Phase 3 的子状态扩展。

---

## 9. 安全性设计

### 9.1 认证架构

**JWT 流程：**

```mermaid
sequenceDiagram
    participant Client as 前端
    participant API as 后端 API
    participant DB as SQLite
    participant JWT as JWT 服务

    Client->>API: POST /api/v1/auth/login (username, password)
    API->>DB: 查询用户
    DB-->>API: 用户记录（password_hash）
    API->>API: bcrypt.verify(password, password_hash)
    API->>JWT: 生成 JWT token (user_id, exp)
    JWT-->>API: token
    API-->>Client: {token, expires_at, user}

    Client->>API: GET /api/v1/devices (Authorization: Bearer token)
    API->>JWT: 验证 token
    JWT-->>API: user_id
    API->>DB: SELECT * FROM devices WHERE user_id = ?
    DB-->>API: 设备列表
    API-->>Client: 设备列表
```

**JWT 约定：**
- 算法：HS256
- Payload：`{"user_id": "uuid", "exp": timestamp}`
- 过期时间：24 小时（可配置）
- 存储：前端安全存储
- 撤销：支持通过 POST /api/v1/auth/logout 主动登出（见 API_SPEC.md §2.1）
- 登出后 token 失效，服务端通过 token 黑名单或数据库标记实现

### 9.2 凭据加密方案

**加密算法：** Fernet（对称加密，基于 AES-128-CBC）

**密钥管理：**
- 密钥长度：32 字节（URL-safe base64 编码）
- 密钥来源：环境变量 `CREDENTIAL_ENCRYPTION_KEY`
- 密钥轮换：阶段一不支持，后续通过密钥版本管理

**加密/解密边界：** 见 §7.5 凭据加密与解密模式

### 9.3 用户数据隔离

**查询强制带 user_id：**
- 所有查询必须带 `user_id` 过滤
- 外键约束：`devices.user_id → users.id`
- 软删除：`conversations.deleted_at` 隐藏已删除会话
- 不信任前端传参，始终在后端强制过滤

### 9.4 SSE 连接安全

**认证：**
- 建立 SSE 连接时校验 Bearer Token
- Token 无效时返回 401，前端关闭连接

**重连校验：**
- 断线重连需重新带 Token
- 支持 `Last-Event-ID` 恢复（阶段一可选）

**连接隔离：**
- 每个用户独立的 SSE 连接
- 事件通过 `user_id` 路由到对应连接

### 9.5 API Key 安全存储

**加密存储：**
- 模型 API Key 使用 Fernet 加密存储在 `user_model_configs` 表
- 返回前端时仅返回 `api_key_set: bool`，不返回本体

**传输安全：**
- 前端 HTTPS 传输 API Key（阶段一明文传输，依赖 HTTPS）
- 后端接收后立即加密，不记录到日志

---

## 10. 阶段一边界与约束

### 10.1 阶段一不包含的功能

| 功能领域 | 阶段一策略 | 原因 |
|---------|-----------|------|
| RBAC 权限控制 | 不做，所有登录用户权限相同 | 阶段一单用户场景 |
| 审批流 | 不做，所有操作直接执行 | 用户确认即为审批 |
| 自动回滚 | 不做，失败仅记录 | Phase 2 引入 |
| 任务取消 | 不做，任务创建后必须完成 | 简化状态机 |
| 命令白名单 | 不做，依赖用户确认 | Phase 3 引入 |

### 10.2 性能与并发约束

| 约束项 | 值 | 说明 |
|--------|---|------|
| 单命令超时 | 30 秒 | netmiko 默认超时 |
| 单任务超时 | 5 分钟 | 从 `running` 到 `completed` |
| 单设备并发 | 1 条命令串行 | 防止设备状态混乱 |
| 多设备并发 | 无限制 | 可并行执行多个设备 |
| SSE 连接数 | 每用户 1 个 | 前端单连接 |
| JWT 过期时间 | 24 小时 | 可配置 |
| 分页大小 | 默认 20，最大 100 | 防止大数据量查询 |

### 10.3 数据约束

| 约束项 | 值 | 说明 |
|--------|---|------|
| 会话历史保留 | 永久（软删除） | 不自动清理 |
| 审计日志保留 | 永久 | 阶段一不归档 |
| 设备凭据 | 加密存储，永不明文落库 | 安全约束 |
| API Key | 加密存储，永不明文落库 | 安全约束 |
| 系统消息 | 不返回前端 | system 消息仅内部使用 |

### 10.4 与 ROADMAP 对齐

本架构设计的范围与 ROADMAP.md §7 Phase 1 完全对齐。任何超出 Phase 1 范围的功能不在本文档中定义。

阶段一完成后，进入 Phase 2（模拟器内受控执行）和 Phase 3（策略与安全增强），架构逐步演进。

---

## 附录：关键引用索引

| 引用 | 文档位置 | 说明 |
|------|----------|------|
| 总体架构 | ROADMAP.md §4 | 分层架构定义 |
| 模块定义 | ROADMAP.md §5 | 各模块职责与边界 |
| 技术选型 | ROADMAP.md §12 | Python、SQLite、netmiko、LiteLLM |
| 前端 API | API_SPEC.md §2 | RESTful/SSE 接口定义 |
| 内部服务 API | API_SPEC.md §3 | LG1-IE5、DM1-DM7、KR1-KR2、AU1-AU3、VA1-VA5 |
| SSE 事件 | API_SPEC.md §4 | 事件类型与时序 |
| 数据模型 | API_SPEC.md §5 | 表结构与关系 |
| 安全要求 | API_SPEC.md §6 | 凭据加密、用户隔离 |
| 协作规则 | AGENTS.md | 文档风格、提交规范 |
