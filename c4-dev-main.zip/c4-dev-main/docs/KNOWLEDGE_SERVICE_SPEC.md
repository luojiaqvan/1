# 知识检索引擎设计文档

## 1. 文档说明

### 1.1 文档定位

本文档是"大模型 + 网络工程配置/运维平台"阶段一知识检索引擎的权威设计与开发指导文档。

本文档规定：
- 知识检索引擎的职责边界与模块定位
- 技术选型决策与依赖约束
- 知识数据组织结构与人机协作流程
- 向量化索引与检索机制
- 对外接口契约（对齐 API_SPEC.md §3.4 KR1/KR2）
- 开发实施路线与验收标准

### 1.2 与其他文档的关系

| 文档 | 权威职责 | 本文档与它的关系 |
|------|----------|-----------------|
| ROADMAP.md | 项目范围、功能边界、知识检索引擎定位 | 范围权威。本文档不超出 ROADMAP §5.5 定义的知识检索引擎职责 |
| API_SPEC.md | 接口契约权威（KR1/KR2、TL2、IE2） | 接口权威。本文档的接口签名和返回结构严格对齐 API_SPEC §3.4 |
| ARCHITECTURE.md | 组件结构、依赖关系、调用方式 | 架构权威。本文档的模块位置和调用方式遵循 ARCHITECTURE §3/§6 |
| TOOLS_SPEC.md | 命令知识库 Schema、幻觉防护策略 | Schema 权威。本文档的数据结构严格遵循 TOOLS_SPEC §7 |
| DATABASE.md | SQLite 表结构定义 | 独立。知识库数据不存储在 SQLite，见 §3.1 |
| AGENTS.md | 协作规则、文档风格 | 协作权威。本文档遵循 AGENTS.md 的风格与提交规范 |

### 1.3 读者对象

- 后端开发者：实现知识检索引擎模块
- 知识工程师：整理和编写知识条目
- 架构师：评估知识库方案与扩展性
- 测试工程师：编写知识检索相关测试用例

### 1.4 内容分类

| 分类 | 含义 | 标识 |
|------|------|------|
| 冻结内容 | 阶段一开发期间不可变更的设计约束 | 无特殊标识（默认为冻结） |
| 演进预留 | 当前阶段不落地，标注了后续方向 | 标注"（演进预留）" |

---

## 2. 模块定位与职责边界

### 2.1 模块定位

知识检索引擎（`llm/knowledge_service/`）是平台的**知识基础设施层**，为意图引擎和主模型提供厂商命令参考、厂商文档、操作 SOP 等结构化和非结构化知识的检索服务。

在 ARCHITECTURE.md 定义的分层架构中，知识检索引擎位于：

```
意图与执行引擎
    ├── 意图解析（调用主模型 + 工具层）
    ├── 候选命令生成（流式 agentic 调用中通过 generate_commands 工具完成 + 厂商适配层）
    │       ↑
    │   知识检索引擎 ←── 本文档定义的模块
    │       ↑
    └── 工具层（search_knowledge 工具）
            ↑
    主模型（通过 function calling 调用工具）
```

### 2.2 核心职责

| 职责 | 说明 |
|------|------|
| 知识数据管理 | 提供知识数据的组织结构、加载管道、增量更新机制 |
| 向量化索引 | 将知识数据自动转为向量并持久化存储 |
| 语义检索 | 根据自然语言查询检索相关知识条目（KR1） |
| 设备上下文检索 | 根据设备厂商、版本、操作类型获取命令参考（KR2） |
| 幻觉防护锚定 | 为候选命令生成调用提供可引用的知识条目，支撑 generation_basis 字段 |

### 2.3 不负责事项

| 不负责 | 实际负责方 |
|--------|-----------|
| 生成 CLI 命令 | 主模型通过 `generate_commands` 工具在流式 agentic 回复中生成 + 厂商适配层（ARCHITECTURE §3.1、§3.6 VA） |
| 执行设备操作 | 统一设备管理程序（ARCHITECTURE §3.3） |
| 意图解析与任务编排 | 意图与执行引擎（ARCHITECTURE §3.2） |
| 用户数据存储 | 后端 API 服务 + SQLite（DATABASE.md） |
| 审计日志 | 审计服务（ARCHITECTURE §3.5） |

---

## 3. 技术选型

### 3.1 核心决策：知识数据与用户数据分离

**原则：知识库数据独立于 SQLite 用户数据库。**

| 数据类型 | 存储方案 | 理由 |
|---------|---------|------|
| 用户数据（设备、会话、任务、审计） | SQLite | 结构化关系数据，ACID 事务，用户隔离，零部署 |
| 知识库数据（命令条目、厂商文档、SOP） | Chroma 向量库（嵌入式） | 向量检索专用，独立于用户数据，无需用户隔离 |

**分离收益：**
- 知识库更新不影响用户数据库
- 知识库数据量增长不占用用户数据库资源
- 知识库可独立备份、迁移、重建
- 符合 ARCHITECTURE.md 中 Knowledge 依赖 DB 的设计，但此处 DB 指 Chroma 而非 SQLite

### 3.2 选型决策表

| 选型 | 选型理由 | 带来的约束 | 已知风险 | 替代方案（未选原因） |
|------|----------|-----------|----------|---------------------|
| LlamaIndex | Python 原生 RAG 框架，丰富的数据加载器，支持多种向量存储后端，社区活跃（48k+ ⭐，截至 2026-04） | 需锁定版本，v0.10 起用 Settings 替代 ServiceContext | 版本升级可能引入不兼容 | LangChain（过重，与 LiteLLM 职责重叠）、自研（工作量大） |
| Chroma（嵌入式模式） | 进程内运行，无需部署独立服务，数据持久化为本地文件，API 极简（4 个核心函数），线程安全（单进程内多线程可安全读写） | 单机存储，不支持分布式；不支持多进程同时写入同一 path | 大规模数据时性能下降；>10M 向量后性能退化 | Milvus（需独立部署服务）、Qdrant（P99 12ms 性能最优，阶段二迁移目标）、PGVector（需 PostgreSQL） |
| OpenAI Embedding（通过 LiteLLM 网关） | 复用现有 LiteLLM 网关，无需额外 embedding 服务；text-embedding-3-small 1536 维，性价比优 | 依赖 LiteLLM 网关可用性；每次检索需网络调用 Embedding | Embedding 模型变更需全量重建索引 | 见 §5.5 Embedding 模型选型 |

### 3.3 依赖清单

```
# requirements.txt 新增（建议锁定版本）
llama-index-core>=0.12,<0.15
llama-index-vector-stores-chroma>=0.4,<0.5
chromadb>=1.5,<2.0
pyyaml>=6.0
```

**新增依赖共 4 个包。** 其中 `llama-index-core` 是核心框架（v0.10 起使用 `Settings` 替代已废弃的 `ServiceContext`），`llama-index-vector-stores-chroma` 是 Chroma 适配层，`chromadb` 是向量数据库（v1.5.x PersistentClient 线程安全），`pyyaml` 用于解析 YAML 知识条目（可能已作为间接依赖存在）。

**Embedding 相关依赖按选型方案追加：**

| Embedding 方案 | 追加依赖 | 说明 |
|---------------|---------|------|
| OpenAI Embedding（通过 LiteLLM） | `llama-index-embeddings-openai` | 默认方案，通过 LiteLLM 网关调用 |
| BGE 本地模型 | `llama-index-embeddings-huggingface`、`sentence-transformers` | 离线/本地化方案，需下载模型文件 |

### 3.4 版本锁定约束

遵循 AGENTS.md §5.4 依赖管理规则和 ARCHITECTURE.md §5.2 安全要求：
- LlamaIndex 和 Chroma 必须锁定主版本号
- 从官方源安装，定期检查版本变更日志
- 不自动升级大版本

---

## 4. 知识数据组织

### 4.1 数据目录结构

```
llm/knowledge_service/
├── data/                                  ← 知识数据根目录（版本管理）
│   ├── commands/                          ← 命令知识条目
│   │   ├── huawei/
│   │   │   └── vrp/
│   │   │       ├── interface_query.yaml       接口查询类命令
│   │   │       ├── interface_change.yaml      接口变更类命令
│   │   │       ├── vlan_query.yaml            VLAN 查询类命令
│   │   │       ├── vlan_change.yaml           VLAN 变更类命令
│   │   │       └── ...
│   │   └── h3c/
│   │       └── comware/
│   │           ├── interface_query.yaml
│   │           ├── interface_change.yaml
│   │           └── ...
│   ├── docs/                              ← 厂商文档（Markdown）
│   │   ├── huawei/
│   │   │   └── vrp_overview.md
│   │   └── h3c/
│   │       └── comware_overview.md
│   └── sop/                               ← 操作 SOP
│       ├── vlan_change_sop.md
│       └── interface_inspect_sop.md
├── chroma_db/                             ← Chroma 向量库持久化目录（.gitignore）
├── __init__.py
├── config.py                              ← 配置管理
├── loader.py                              ← 自定义数据加载器（YAML/Markdown）
├── indexer.py                             ← 索引构建与增量更新
├── retriever.py                           ← 检索接口（KR1/KR2）
└── models.py                              ← Pydantic 数据模型
```

### 4.2 知识数据分类

| 数据类型 | 文件格式 | 目录 | 检索方式 | 分块策略 |
|---------|---------|------|---------|---------|
| 命令条目 | `.yaml` | `data/commands/` | 向量语义 + 元数据精确过滤 | **整条不分块**（保留完整上下文） |
| 厂商文档 | `.md` | `data/docs/` | 向量语义 + 元数据过滤 | 按标题分块（chunk_size=512） |
| 操作 SOP | `.md` | `data/sop/` | 向量语义 | 按标题分块（chunk_size=512） |

### 4.3 命令知识条目 Schema

严格对齐 TOOLS_SPEC.md §7 的命令知识库 Schema。每个 YAML 文件可包含单条或多条命令条目。

**单条条目文件示例（`data/commands/huawei/vrp/interface_query.yaml`）：**

```yaml
entry_id: "huawei_vrp_interface_display_001"
vendor: "huawei"
os_family: "vrp"
command_pattern: "display interface {interface}"
full_syntax: "display interface [ interface-type [ interface-number ] ]"
description: "查看指定接口或所有接口的详细状态信息，包括物理状态、协议状态、速率、双工模式等"
mode: "user_view"
intent_types:
  - "query"
  - "inspect"
target_types:
  - "interface"
required_parameters: []
optional_parameters:
  - parameter_name: "interface"
    type: "string"
    value_range: "GigabitEthernet0/0/1-48, 10GE1/0/1-48, LoopBack0-127"
    required: false
forbidden_combinations: []
applicability:
  os_version_min: "VRP V200R019"
  os_version_max: null
  device_constraints: "S 系列、CE 系列、NE 系列"
expected_output_hint: "包含接口状态（up/down）、速率、双工模式、入出方向统计"
risk_level: "low"
validation_tags:
  - "needs_interface_exists"
evidence_source: "华为 VRP 命令参考指南 V200R019"
confidence_floor: 0.8
examples:
  - intent: "查看所有接口的简要状态"
    command: "display interface brief"
    context: "在用户视图下执行，显示所有接口的一行摘要"
  - intent: "查看 GE0/0/1 接口的详细信息"
    command: "display interface GigabitEthernet0/0/1"
    context: "在用户视图下执行，显示指定接口的完整状态"
  - intent: "查看接口物理状态和统计信息"
    command: "display interface brief | include up"
    context: "使用管道过滤，仅显示状态为 up 的接口"
```

**多条条目文件示例（`data/commands/huawei/vrp/vlan_query.yaml`）：**

```yaml
# 一个 YAML 文件可包含多条命令条目（使用列表格式）
- entry_id: "huawei_vrp_vlan_display_001"
  vendor: "huawei"
  os_family: "vrp"
  command_pattern: "display vlan"
  full_syntax: "display vlan [ vlan-id [ to vlan-id ] ]"
  description: "查看 VLAN 信息列表，包括 VLAN ID、名称、类型、接口归属"
  mode: "user_view"
  intent_types: ["query"]
  target_types: ["vlan"]
  required_parameters: []
  optional_parameters:
    - parameter_name: "vlan-id"
      type: "integer"
      value_range: "1-4094"
      required: false
  forbidden_combinations: []
  applicability:
    os_version_min: "VRP V200R019"
    os_version_max: null
    device_constraints: null
  expected_output_hint: "VLAN 编号、名称、状态、包含的接口列表"
  risk_level: "low"
  validation_tags: []
  evidence_source: "华为 VRP 命令参考指南 V200R019"
  confidence_floor: 0.8
  examples:
    - intent: "查看所有 VLAN"
      command: "display vlan"
      context: "显示所有 VLAN 的汇总信息"

- entry_id: "huawei_vrp_vlan_display_002"
  vendor: "huawei"
  os_family: "vrp"
  command_pattern: "display vlan {vlan-id}"
  full_syntax: "display vlan vlan-id"
  description: "查看指定 VLAN 的详细信息，包括接口归属和描述"
  mode: "user_view"
  intent_types: ["query"]
  target_types: ["vlan"]
  required_parameters:
    - parameter_name: "vlan-id"
      type: "integer"
      value_range: "1-4094"
      required: true
  optional_parameters: []
  forbidden_combinations: []
  applicability:
    os_version_min: "VRP V200R019"
    os_version_max: null
    device_constraints: null
  expected_output_hint: "指定 VLAN 的详细信息"
  risk_level: "low"
  validation_tags: ["needs_vlan_exists"]
  evidence_source: "华为 VRP 命令参考指南 V200R019"
  confidence_floor: 0.85
  examples:
    - intent: "查看 VLAN 10 的详细信息"
      command: "display vlan 10"
      context: "显示 VLAN 10 的接口归属和描述"
```

### 4.4 人机协作流程（数据收集与入库）

知识数据的收集和入库流程设计为**最小人工介入**：

```
┌──────────────────────────────────────────────────────────┐
│  知识工程师操作（人工）                                    │
│                                                           │
│  1. 参考厂商官方文档，按 §4.3 Schema 编写 YAML 文件        │
│  2. 将文件放到 data/commands/{vendor}/{os_family}/ 下      │
│  3. （可选）将厂商文档放到 data/docs/{vendor}/ 下           │
│  4. 提交代码                                              │
└───────────────────────┬──────────────────────────────────┘
                        │ 系统启动时 或 调用重建接口
                        ▼
┌──────────────────────────────────────────────────────────┐
│  系统自动处理（无需人工）                                   │
│                                                           │
│  1. 扫描 data/ 目录下所有 .yaml / .md 文件                │
│  2. YAML 文件：逐条解析为独立 Document                     │
│     - 提取元数据：vendor、os_family、intent_types 等       │
│     - 构建可搜索文本：description + command_pattern + examples │
│     - 保持整条条目完整，不拆分                              │
│  3. Markdown 文件：按标题自动分块                           │
│     - 从文件路径提取 vendor 等元数据                        │
│  4. 调用 Embedding 模型（通过 LiteLLM 网关）生成向量        │
│  5. 写入 Chroma 向量库持久化                                │
└──────────────────────────────────────────────────────────┘
```

**人工操作清单：**

| 步骤 | 操作 | 说明 |
|------|------|------|
| 1 | 编写 YAML | 按 §4.3 Schema 编写，可参考已有文件 |
| 2 | 保存到目录 | 放到 `data/commands/{vendor}/{os_family}/` 下 |
| 3 | 提交代码 | 正常 git add + commit |
| 4 | 重建索引 | 重启服务自动触发，或调用管理接口 |

无需手动操作数据库、无需手动生成向量、无需手动编写索引脚本。

### 4.5 厂商文档和 SOP 的格式要求

**Markdown 文档要求：**

```markdown
---
vendor: huawei
os_family: vrp
source_type: vendor_doc
---

# 华为 VRP 接口管理概述

## 接口类型

华为 VRP 支持以下接口类型...

## 接口配置模式

进入接口视图的命令格式为...
```

- 文件头部**必须**包含 YAML front matter，标注 `vendor`、`os_family`、`source_type`
- `source_type` 取值：`vendor_doc`（厂商文档）、`sop`（操作 SOP）
- 文档按 `#` 和 `##` 标题自动分块

---

## 5. 索引与检索机制

### 5.1 向量化索引流程

```
data/ 目录
    │
    ├── .yaml 文件 ──→ YAMLCommandLoader ──→ 逐条解析 ──→ Document 对象
    │                                                      │
    ├── .md 文件 ────→ MarkdownLoader ─────→ 按标题分块 ──→ Document 对象
    │                                                      │
    └──────────────────────────────────────────────────────┘
                                    │
                                    ▼
                        Embedding 模型（通过 LiteLLM 网关）
                                    │
                                    ▼
                        Chroma 向量库（本地持久化）
                        chroma_db/
                          ├── chroma.sqlite3
                          └── ...
```

### 5.2 YAML 命令条目的 Document 构造

每条 YAML 命令条目转为**一个完整的 LlamaIndex Document**，不做分块。

**可搜索文本构造规则：**

```
字段组合 → Document.text
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[command_pattern]
描述：{description}
完整语法：{full_syntax}
命令模式：{mode}
示例：
  - 意图：{example_1.intent} → 命令：{example_1.command}
  - 意图：{example_2.intent} → 命令：{example_2.command}
```

**元数据构造规则（用于精确过滤）：**

```python
Document.metadata = {
    "entry_id": entry["entry_id"],           # 知识条目唯一 ID
    "source_type": "command_ref",            # 固定为 command_ref
    "vendor": entry["vendor"],               # huawei / h3c
    "os_family": entry["os_family"],         # vrp / comware
    "intent_types": entry["intent_types"],   # ["query", "inspect"]
    "target_types": entry["target_types"],   # ["interface", "vlan"]
    "risk_level": entry["risk_level"],       # low / medium / high
    "mode": entry["mode"],                   # user_view / system_view / ...
}
```

**设计理由：命令条目是结构化短文本，信息密度高，拆分会丢失上下文。整条索引保证检索结果包含完整命令信息，避免分块导致的语义不完整。**

### 5.3 Markdown 文档的分块规则

```python
# 使用 LlamaIndex 的 MarkdownNodeParser
from llama_index.core.node_parser import MarkdownNodeParser

parser = MarkdownNodeParser()
# 自动按 # 和 ## 标题分块
# 每个 chunk 保留标题层级作为上下文
# chunk_size 默认不限制（按标题切分，保持语义完整性）
```

### 5.4 检索策略

#### 5.4.1 双路检索

知识检索引擎采用**向量语义检索 + 元数据精确过滤**的双路检索策略：

```
用户查询："查看华为交换机接口状态"
        │
        ├── 元数据过滤（精确匹配）
        │   vendor = "huawei"
        │   source_type = "command_ref"
        │
        └── 向量相似度（语义匹配）
            query embedding vs. 所有满足元数据条件的 Document embedding
            返回 top_k 个最相似的条目
```

**不采用纯向量检索的原因：**
- 厂商标识（huawei/h3c）是精确匹配需求，不能靠语义相似度
- 操作类型（query/change）必须精确过滤
- 纯向量检索可能跨厂商返回 H3C 的命令给华为设备

#### 5.4.2 检索参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `similarity_top_k` | 5 | 返回的相似度最高的条目数 |
| `similarity_cutoff` | 0.5 | 相似度低于此值的条目不返回（演进预留，阶段一可选实现） |

### 5.5 Embedding 模型配置

#### 5.5.1 Embedding 调用链路

知识检索引擎中 Embedding 的调用发生在两个阶段：

```
阶段一：索引构建（离线）
  data/ 文件 → YAMLCommandReader / MarkdownReader → Document 对象
      │
      ▼
  LlamaIndex VectorStoreIndex.from_documents()
      │
      ▼  内部调用 Settings.embed_model.get_text_embedding_batch()
  Embedding 模型（通过 LiteLLM 网关 或 本地模型）
      │
      ▼
  Chroma 写入向量

阶段二：查询检索（在线）
  用户查询 query
      │
      ▼  LlamaIndex retriever.retrieve()
  Settings.embed_model.get_text_embedding(query)
      │
      ▼
  Chroma 向量相似度搜索
      │
      ▼
  返回 top_k 结果 + 元数据过滤
```

**关键约束：索引构建和查询检索必须使用同一个 Embedding 模型。** 模型变更时必须全量重建索引。

#### 5.5.2 LlamaIndex Settings 全局配置

LlamaIndex v0.10 起废弃 `ServiceContext`，使用全局 `Settings` 对象管理模型配置。知识检索引擎在初始化时配置 `Settings`：

```python
from llama_index.core import Settings

# 禁用 LLM（知识检索引擎只做检索，不做生成）
Settings.llm = None

# Embedding 模型在 initialize() 中根据配置设置
# 详见下方 5.5.3 / 5.5.4
```

**约束：** `Settings` 是进程级全局配置。由于本项目采用进程内单服务架构（ARCHITECTURE §2.2），全局 `Settings` 在同一进程中生效，不存在多进程配置不一致的问题。

#### 5.5.3 方案 A：OpenAI Embedding（通过 LiteLLM 网关，阶段一默认）

```python
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings

# 通过 LiteLLM 网关调用 OpenAI Embedding
Settings.embed_model = OpenAIEmbedding(
    model="text-embedding-3-small",
    api_base=api_base_url,    # LiteLLM 网关地址（从环境变量读取）
    api_key=api_key,           # 通过环境变量注入
    dimensions=1536,           # 输出维度
    embed_batch_size=32,       # 批量嵌入大小（减少 API 调用次数）
)
```

**调用路径：**

```
LlamaIndex Settings.embed_model
    → OpenAIEmbedding.get_text_embedding_batch()
    → HTTP POST → LiteLLM 网关 → 上游 Embedding API
    → 返回向量列表
```

**优势：**
- 复用已有 LiteLLM 网关，零新增基础设施
- `text-embedding-3-small`（1536 维）：通用性强，中英文能力均衡
- API 调用模式，不占本地 GPU/CPU

**风险与缓解：**
- 依赖 LiteLLM 网关可用性 → 网关应有降级和重试机制
- 每次检索需要网络调用 → 阶段一数据量小，延迟可接受（< 500ms）
- Embedding 服务商限流 → 控制批量大小 `embed_batch_size=32`

#### 5.5.4 方案 B：BGE 本地模型（本地化 / 离线方案）

当需要离线运行或降低 API 成本时，可切换为本地 Embedding 模型：

```python
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings

Settings.embed_model = HuggingFaceEmbedding(
    model_name="BAAI/bge-m3",       # 多语言首选
    device="cpu",                     # 或 "cuda"（需 GPU）
    embed_batch_size=32,
)
```

**可选模型对比：**

| 模型 | 维度 | 上下文长度 | 适用场景 | 模型体积 |
|------|------|-----------|---------|---------|
| `text-embedding-3-small` | 1536 | 8191 | 通用，中英文均衡，API 调用 | 云端（无需本地存储） |
| `BAAI/bge-m3` | 1024 | 8192 | 中英混合多语言，支持 dense+sparse 混合检索 | ~2.2 GB |
| `BAAI/bge-large-zh-v1.5` | 1024 | 512 | 中文为主场景，MTEB 中文排行榜前列 | ~1.3 GB |
| `BAAI/bge-base-zh-v1.5` | 768 | 512 | 中文场景，资源受限环境 | ~0.4 GB |

**模型选择建议：**

```
能否保证 LiteLLM 网关持续可用？
├── 是 → 方案 A（text-embedding-3-small），阶段一推荐
└── 否 / 需要离线 / 需要降低成本
    └── 知识内容语言构成？
        ├── 中英混合（命令为英文、描述为中文）→ BAAI/bge-m3
        └── 纯中文 → BAAI/bge-large-zh-v1.5
```

**方案切换方式：** 仅修改 `Settings.embed_model` 赋值，不改动其他代码。切换后**必须**全量重建索引（因向量维度和语义空间不同）。

#### 5.5.5 Embedding 模型变更与索引重建

| 触发条件 | 必须操作 | 影响范围 |
|---------|---------|---------|
| 切换 Embedding 模型（方案 A → B 或反向） | 全量重建索引 | `rebuild_index()` |
| 更换模型维度（如 1536 → 1024） | 全量重建索引 | `rebuild_index()` |
| 同模型更新知识数据 | 增量更新即可 | `build_index()` 自动追加 |
| 调整 `embed_batch_size` | 无需重建 | 仅影响构建速度 |

**重建操作：** 设置 `KNOWLEDGE_REBUILD_ON_START=true` 后重启服务，或调用管理接口触发 `rebuild_index()`。

---

## 6. 模块内部设计

### 6.1 文件职责

| 文件 | 职责 | 对外暴露 |
|------|------|---------|
| `config.py` | 读取环境变量，配置 Chroma 路径、Embedding 模型、索引参数 | `get_settings()` |
| `loader.py` | 自定义 LlamaIndex Reader，解析 YAML 命令条目和 Markdown 文档 | `YAMLCommandReader`、`MarkdownReader` |
| `models.py` | Pydantic 数据模型，对齐 TOOLS_SPEC §7 Schema | `CommandEntry`、`SearchResult` 等 |
| `indexer.py` | 索引构建、增量更新、索引管理 | `build_index()`、`rebuild_index()` |
| `retriever.py` | 检索接口实现，对齐 API_SPEC KR1/KR2 | `search()`、`get_device_context()` |
| `__init__.py` | 模块初始化，暴露公共接口 | `KnowledgeService` 类 |

### 6.2 模块初始化与生命周期

对齐 ARCHITECTURE.md §2.2 的进程内单服务架构，知识检索引擎在 FastAPI 应用启动时初始化：

```python
# llm/knowledge_service/__init__.py 核心逻辑

import chromadb
from llama_index.core import VectorStoreIndex, Settings
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import StorageContext

class KnowledgeService:
    """知识检索引擎的顶层门面类"""

    def __init__(self):
        self.settings = get_settings()          # config.py
        self.index: VectorStoreIndex = None     # LlamaIndex 索引
        self.chroma_client = None               # Chroma 客户端

    def initialize(self):
        """应用启动时调用：初始化 Chroma、配置 Settings、加载/构建索引"""
        # 1. 配置 LlamaIndex 全局 Settings
        self._configure_settings()

        # 2. 初始化 Chroma 持久化客户端
        self.chroma_client = chromadb.PersistentClient(
            path=self.settings.chroma_persist_dir
        )

        # 3. 加载已有索引或从 data/ 目录构建新索引
        self.index = self._load_or_build_index()

    def _configure_settings(self):
        """配置 LlamaIndex 全局 Settings（Embedding 模型 + 禁用 LLM）"""
        from llama_index.core import Settings as LlamaSettings

        # 知识检索引擎不做生成，禁用 LLM
        LlamaSettings.llm = None

        # 按配置选择 Embedding 方案
        if self.settings.embedding_provider == "openai":
            from llama_index.embeddings.openai import OpenAIEmbedding
            LlamaSettings.embed_model = OpenAIEmbedding(
                model=self.settings.embedding_model,
                api_base=self.settings.llm_gateway_url,
                api_key=self.settings.llm_gateway_api_key,
                embed_batch_size=32,
            )
        elif self.settings.embedding_provider == "local":
            from llama_index.embeddings.huggingface import HuggingFaceEmbedding
            LlamaSettings.embed_model = HuggingFaceEmbedding(
                model_name=self.settings.embedding_model,
                device=self.settings.embedding_device,
                embed_batch_size=32,
            )

    def _load_or_build_index(self):
        """加载已有索引或从 data/ 目录构建新索引"""
        from llama_index.vector_stores.chroma import ChromaVectorStore
        from llama_index.core import StorageContext

        chroma_collection = self.chroma_client.get_or_create_collection(
            name="knowledge",
            metadata={"hnsw:space": "cosine"},
        )
        vector_store = ChromaVectorStore(chroma_collection=chroma_collection)

        if chroma_collection.count() > 0 and not self.settings.rebuild_on_start:
            # 已有数据：直接加载索引（无需重新嵌入）
            return VectorStoreIndex.from_vector_store(vector_store)
        else:
            # 无数据或强制重建：从 data/ 目录全量构建
            return self._build_index(vector_store)

    def _build_index(self, vector_store):
        """全量构建索引"""
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        docs = self._load_all_documents()
        return VectorStoreIndex.from_documents(
            docs,
            storage_context=storage_context,
            show_progress=True,
        )

    # 对齐 API_SPEC §3.4 KR1
    def search(self, query, vendor=None, source_type=None, top_k=5):
        """语义检索 + 元数据过滤"""
        ...

    # 对齐 API_SPEC §3.4 KR2
    def get_device_context(self, vendor, device_type, os_version=None,
                           intent_type=None, target_type=None):
        """获取设备相关的命令参考"""
        ...
```

**Chroma 线程安全约束（FastAPI 集成）：**

| 约束项 | 说明 |
|--------|------|
| 线程安全 | `PersistentClient` 在单进程内多线程可安全读写，适合 FastAPI 的 async + sync 混合模式 |
| 进程安全 | **不支持**多进程同时写入同一 `path`。阶段一为单进程架构，无此问题 |
| 单例模式 | `KnowledgeService` 应在 FastAPI 应用中作为单例使用，避免重复初始化 |
| 异步兼容 | Chroma 操作为同步 IO。在 FastAPI async handler 中调用时应使用 `run_in_executor` 避免阻塞事件循环 |

**FastAPI 集成（lifespan 模式）：**

```python
# 在 FastAPI 应用的 lifespan 中初始化

from llm.knowledge_service import KnowledgeService
from functools import lru_cache

@lru_cache()
def get_knowledge_service() -> KnowledgeService:
    """知识检索引擎单例"""
    return KnowledgeService()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 启动时
    service = get_knowledge_service()
    service.initialize()
    app.state.knowledge_service = service
    yield
    # 关闭时（Chroma PersistentClient 自动持久化，无需额外操作）
```

### 6.3 自定义 YAML 加载器

```python
# llm/knowledge_service/loader.py 核心设计

from llama_index.core.readers.base import BaseReader
from llama_index.core import Document

class YAMLCommandReader(BaseReader):
    """
    自定义 LlamaIndex Reader：解析 YAML 命令知识条目

    输入：data/commands/ 目录路径
    输出：每个 YAML 条目 → 一个 LlamaIndex Document
    """

    def load_data(self, path, extra_info=None):
        """
        递归扫描 path 下所有 .yaml/.yml 文件，
        每个条目解析为一个 Document（整条，不分块）
        """
        documents = []
        for yaml_file in Path(path).rglob("*.yaml"):
            entries = yaml.safe_load(yaml_file.read_text(encoding="utf-8"))
            if not isinstance(entries, list):
                entries = [entries]
            for entry in entries:
                doc = self._entry_to_document(entry, yaml_file)
                documents.append(doc)
        return documents

    def _entry_to_document(self, entry, source_file):
        """将 YAML 条目转为 Document，构造 text 和 metadata"""
        text = self._build_searchable_text(entry)
        metadata = self._build_metadata(entry, source_file)
        return Document(text=text, metadata=metadata, id_=entry["entry_id"])

    def _build_searchable_text(self, entry):
        """构造用于向量化的可搜索文本"""
        parts = [
            entry.get("command_pattern", ""),
            f"描述：{entry.get('description', '')}",
            f"语法：{entry.get('full_syntax', '')}",
            f"模式：{entry.get('mode', '')}",
        ]
        for ex in entry.get("examples", []):
            parts.append(f"示例 - 意图：{ex['intent']} 命令：{ex['command']}")
        return "\n".join(parts)

    def _build_metadata(self, entry, source_file):
        """构造元数据（用于精确过滤）"""
        return {
            "entry_id": entry["entry_id"],
            "source_type": "command_ref",
            "vendor": entry["vendor"],
            "os_family": entry["os_family"],
            "intent_types": ",".join(entry.get("intent_types", [])),
            "target_types": ",".join(entry.get("target_types", [])),
            "risk_level": entry.get("risk_level", "unknown"),
            "mode": entry.get("mode", ""),
        }
```

### 6.4 检索接口实现

#### KR1. search

对齐 API_SPEC.md §3.4 KR1。

```python
# llm/knowledge_service/retriever.py

from llama_index.core.vector_stores import MetadataFilters, MetadataFilter

def search(
    query: str,
    vendor: str | None = None,
    source_type: str | None = None,
    top_k: int = 5,
) -> list[SearchResult]:
    """
    KR1: 语义检索 + 元数据过滤

    入参对齐 API_SPEC §3.4 KR1:
      - query: 检索查询（自然语言）
      - vendor: 按厂商过滤（huawei / h3c）
      - source_type: 按来源过滤（command_ref / vendor_doc / sop）
      - top_k: 返回数量

    返回对齐 API_SPEC §3.4 KR1:
      - results[].content: 检索到的文本片段
      - results[].source: 来源标识
      - results[].source_type: 来源类型
      - results[].vendor: 厂商
      - results[].relevance_score: 相关度分数
    """
    # 构建元数据过滤条件
    filters = []
    if vendor:
        filters.append(MetadataFilter(key="vendor", value=vendor))
    if source_type:
        filters.append(MetadataFilter(key="source_type", value=source_type))

    # 创建检索器
    retriever = index.as_retriever(
        similarity_top_k=top_k,
        filters=MetadataFilters(filters=filters) if filters else None,
    )

    # 执行检索
    nodes = retriever.retrieve(query)

    # 转换为 API_SPEC 定义的返回格式
    return [
        SearchResult(
            content=node.text,
            source=node.metadata.get("entry_id", node.metadata.get("file_path", "")),
            source_type=node.metadata.get("source_type", "unknown"),
            vendor=node.metadata.get("vendor", ""),
            relevance_score=node.score,
        )
        for node in nodes
    ]
```

#### KR2. get_device_context

对齐 API_SPEC.md §3.4 KR2。

```python
def get_device_context(
    vendor: str,
    device_type: str,
    os_version: str | None = None,
    intent_type: str | None = None,
    target_type: str | None = None,
) -> DeviceContext:
    """
    KR2: 获取设备相关的命令参考和上下文知识

    入参对齐 API_SPEC §3.4 KR2:
      - vendor: 厂商
      - device_type: 设备类型（netmiko device_type）
      - os_version: 系统版本
      - intent_type: 意图类型
      - target_type: 目标类型

    返回对齐 API_SPEC §3.4 KR2:
      - command_references[].command_pattern
      - command_references[].description
      - command_references[].syntax
      - command_references[].usage_notes
      - capability_constraints
      - common_patterns
    """
    # 构建过滤条件：厂商 + 可选的操作类型和目标类型
    filters = [MetadataFilter(key="vendor", value=vendor)]
    if intent_type:
        filters.append(MetadataFilter(key="intent_types", value=intent_type))
    if target_type:
        filters.append(MetadataFilter(key="target_types", value=target_type))

    retriever = index.as_retriever(
        similarity_top_k=20,  # 设备上下文需要更全面的知识
        filters=MetadataFilters(filters=filters),
    )

    nodes = retriever.retrieve(f"{vendor} {device_type} {intent_type or ''} {target_type or ''} commands")

    # 组装返回结构
    command_references = []
    for node in nodes:
        if node.metadata.get("source_type") == "command_ref":
            command_references.append(CommandReference(
                command_pattern=node.metadata.get("command_pattern", ""),
                description=node.text.split("\n")[0] if node.text else "",
                syntax=node.metadata.get("full_syntax", ""),
                usage_notes=[],
            ))

    return DeviceContext(
        command_references=command_references,
        capability_constraints=[],
        common_patterns=[],
    )
```

### 6.5 索引构建与更新

```python
# llm/knowledge_service/indexer.py

def build_index(knowledge_service: KnowledgeService) -> int:
    """
    全量构建索引：扫描 data/ 目录，加载所有文档，写入 Chroma

    返回：索引的文档数量
    """
    from llm.knowledge_service.loader import YAMLCommandReader

    # 1. 加载 YAML 命令条目
    yaml_reader = YAMLCommandReader()
    command_docs = yaml_reader.load_data("llm/knowledge_service/data/commands")

    # 2. 加载 Markdown 文档
    md_docs = load_markdown_docs("llm/knowledge_service/data/docs")
    sop_docs = load_markdown_docs("llm/knowledge_service/data/sop")

    all_docs = command_docs + md_docs + sop_docs

    # 3. 构建 LlamaIndex 索引
    from llama_index.core import VectorStoreIndex, StorageContext
    from llama_index.vector_stores.chroma import ChromaVectorStore

    chroma_collection = knowledge_service.chroma_client.get_or_create_collection(
        name="knowledge",
        metadata={"hnsw:space": "cosine"},
    )
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    index = VectorStoreIndex.from_documents(
        all_docs,
        storage_context=storage_context,
        show_progress=True,
    )

    knowledge_service.index = index
    return len(all_docs)


def rebuild_index(knowledge_service: KnowledgeService) -> int:
    """
    重建索引：删除现有集合，重新全量构建

    使用场景：知识数据大量变更、Embedding 模型变更
    """
    # 删除旧集合
    try:
        knowledge_service.chroma_client.delete_collection("knowledge")
    except Exception:
        pass  # 集合不存在时忽略

    # 重新构建
    return build_index(knowledge_service)
```

---

## 7. 与其他模块的集成

### 7.1 调用方一：工具层（TL2 search_knowledge）

主模型通过 function calling 调用 `search_knowledge` 工具，工具层转发到知识检索引擎。

对齐 API_SPEC.md §3.7 TL2：

```python
# llm/tools/handlers.py 中的 search_knowledge 处理

def handle_search_knowledge(arguments: dict) -> dict:
    """TL2 工具处理器"""
    results = knowledge_service.search(
        query=arguments["query"],
        vendor=arguments.get("vendor"),
        source_type=arguments.get("source_type"),
        top_k=arguments.get("top_k", 5),
    )
    return {
        "results": [r.model_dump() for r in results]
    }
```

### 7.2 调用方二：意图引擎（IE2 命令生成）

意图引擎在生成候选命令时，先从知识检索引擎获取命令参考，注入到候选命令生成的上下文中。阶段一到阶段二在同一流式 agentic 调用中完成：主模型通过 `generate_commands` 工具在流式回复中直接生成候选命令，后端从 tool_call 内容中提取并校验后推送 `approval_required` 事件。

对齐 ARCHITECTURE.md §4.2 设备操作任务流程：

```python
# llm/intent_engine/ 中的调用

def generate_candidate_commands(intent, device_contexts):
    # 获取知识参考
    knowledge_refs = []
    for ctx in device_contexts:
        device_ctx = knowledge_service.get_device_context(
            vendor=ctx["vendor"],
            device_type=ctx["device_type"],
            os_version=ctx.get("os_version"),
            intent_type=intent["operation_type"],
            target_type=intent["target_type"],
        )
        knowledge_refs.append(device_ctx)

    # 将知识参考注入 generate_commands 工具调用上下文
    # 对齐 TOOLS_SPEC §4.3 输入拼装顺序
    prompt = build_generation_prompt(intent, device_contexts, knowledge_refs)

    # 主模型在流式 agentic 回复中通过 generate_commands 工具生成候选命令（阶段一到阶段二）
    commands = llm_gateway.stream_agentic_completion(model="main_model", messages=prompt)
    return commands
```

#### 7.2.1 IE2 消费知识检索结果的标准流程

阶段一正常模式下，IE2 消费知识检索结果必须遵循以下流程：

1. 接收标准化意图 `intent` 与设备上下文 `device_contexts`
2. 对每个目标设备调用 KR2 `get_device_context()` 获取设备相关命令参考与约束
3. 按需调用 KR1 `search()` 补充厂商文档、SOP 或命令条目摘要
4. 将 KR1/KR2 结果归一化组装为 `knowledge_refs`
5. 将 `knowledge_refs` 注入 `generate_commands` 工具调用上下文，参与候选命令生成
6. 在 `generate_commands` 工具输出中使用 `generation_basis` 回指本次 `knowledge_refs` 中的稳定来源标识

约束：

- **正常模式下，IE2 不得跳过 KR1/KR2 直接调用 `generate_commands` 工具。**
- `knowledge_refs` 必须来源于知识检索引擎的结构化结果，而不是由调用方临时拼接自由文本。
- 若 KR1/KR2 无法提供可用引用，IE2 必须显式进入 `template_fallback` 等降级模式，或返回空候选并说明原因。

#### 7.2.2 `knowledge_refs` 归一化要求

IE2 传给 `generate_commands` 工具的 `knowledge_refs` 至少应归一化为以下字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| ref_id | string | 本次引用的稳定 ID |
| source_type | string | `knowledge_entry / vendor_doc / sop / command_ref` |
| source_id | string | 知识源稳定标识，如 `entry_id` / `doc_id` |
| title | string | 条目或文档标题 |
| content | string | 注入 prompt 的文本摘要 |
| relevance_score | float | 检索相关度 |
| vendor | string or null | 厂商标识 |
| metadata | object or null | 附加元数据 |

该结构既服务于 `generate_commands` 工具调用拼装，也服务于审计与问题回放。

### 7.3 调用方三：厂商适配层（VA1 系统提示词）

厂商适配层可从知识检索引擎获取 few-shot 示例，注入到 `generate_commands` 工具调用的系统提示词中。

对齐 TOOLS_SPEC §5.5 示例选择与拼装规则：

```python
# llm/intent_engine/vendor/ 中的调用

def get_few_shot_examples(vendor, os_family, operation_type, target_type):
    """从知识库检索匹配的示例，注入到厂商适配 prompt"""
    results = knowledge_service.search(
        query=f"{operation_type} {target_type}",
        vendor=vendor,
        source_type="command_ref",
        top_k=5,
    )
    # 从检索结果中提取 examples 字段
    examples = []
    for r in results:
        # 解析 content 中的示例部分
        ...
    return examples
```

### 7.4 检索引用追溯与审计要求

知识检索结果必须支持从候选命令反向追溯到知识源。阶段一要求如下：

- KR1/KR2 返回的每条结果都必须带稳定 `source_id`，不得只返回不可追溯的自由文本片段。
- IE2 组装出的 `knowledge_refs` 必须完整保留 `source_type + source_id`。
- `generate_commands` 工具输出中的 `generation_basis` 必须引用 `knowledge_refs` 中的稳定来源，或在降级模式下引用冻结模板来源。
- 审计服务在记录 `knowledge_retrieved`、`commands_generated` 等事件时，应能关联本次使用的 `knowledge_refs` 标识，以支持后续回放与问题定位。

推荐最小伪代码：

```python
knowledge_refs = build_knowledge_refs(kr1_results, kr2_results)
prompt = build_generation_prompt(intent, device_contexts, knowledge_refs)
candidate_commands = llm_gateway.chat_completion(...)

for cmd in candidate_commands:
    assert cmd.generation_basis references one of knowledge_refs.source_id
```

---

## 8. 配置管理

### 8.1 环境变量

| 环境变量 | 类型 | 默认值 | 说明 |
|---------|------|--------|------|
| `KNOWLEDGE_DATA_DIR` | string | `llm/knowledge_service/data` | 知识数据目录 |
| `KNOWLEDGE_CHROMA_DIR` | string | `llm/knowledge_service/chroma_db` | Chroma 持久化目录 |
| `KNOWLEDGE_EMBEDDING_MODEL` | string | `text-embedding-3-small` | Embedding 模型标识 |
| `KNOWLEDGE_TOP_K` | int | `5` | 默认检索返回数量 |
| `KNOWLEDGE_REBUILD_ON_START` | bool | `false` | 启动时是否强制重建索引 |

### 8.2 .gitignore

```
# 知识库 Chroma 持久化数据（由系统自动生成，不提交）
llm/knowledge_service/chroma_db/
```

### 8.3 .env.example

```bash
# 知识检索引擎配置
KNOWLEDGE_DATA_DIR=llm/knowledge_service/data
KNOWLEDGE_CHROMA_DIR=llm/knowledge_service/chroma_db
KNOWLEDGE_EMBEDDING_MODEL=text-embedding-3-small
KNOWLEDGE_TOP_K=5
KNOWLEDGE_REBUILD_ON_START=false
```

---

## 9. 开发实施路线

### 9.1 实施步骤

| 步骤 | 内容 | 依赖 | 预计工作量 | 产出 |
|------|------|------|-----------|------|
| 1 | 搭建模块骨架：`__init__.py`、`config.py`、`models.py` | 无 | 0.5 天 | 模块结构、配置读取、数据模型 |
| 2 | 实现 `loader.py`：YAML 命令条目加载器 | 步骤 1 | 1 天 | YAMLCommandReader，单元测试通过 |
| 3 | 编写初始知识数据：华为 VRP 接口/VLAN 命令条目 | 无（可与步骤 2 并行） | 1 天 | 2-3 个 YAML 文件 |
| 4 | 实现 `indexer.py`：索引构建与持久化 | 步骤 2、3 | 1 天 | 全量构建索引，Chroma 持久化验证 |
| 5 | 实现 `retriever.py`：KR1/KR2 检索接口 | 步骤 4 | 1 天 | 语义检索 + 元数据过滤验证 |
| 6 | 集成到 FastAPI 生命周期 | 步骤 5 | 0.5 天 | 应用启动自动加载索引 |
| 7 | 与工具层集成：TL2 search_knowledge | 步骤 6 | 0.5 天 | 主模型可通过工具调用检索知识 |
| 8 | 与意图引擎集成：IE2 命令生成 | 步骤 7 | 0.5 天 | 生成模型可获取知识参考 |

**总预计工作量：5-6 天**

### 9.2 验收标准

| 验收项 | 标准 |
|--------|------|
| 知识条目加载 | YAML 文件放到 data/ 目录后，重启服务可自动加载 |
| 向量索引构建 | 扫描 data/ 目录构建索引，写入 chroma_db/ 持久化 |
| 语义检索 | KR1 接口可返回与查询语义相关的知识条目 |
| 元数据过滤 | KR1 接口可按 vendor、source_type 精确过滤 |
| 设备上下文 | KR2 接口可返回指定厂商的命令参考列表 |
| 幻觉防护 | 检索结果包含 entry_id，可用于 generation_basis 字段 |
| 持久化 | 重启服务后索引从 chroma_db/ 加载，无需重新构建 |
| 增量更新 | 新增 YAML 文件后，调用重建接口可更新索引 |

### 9.3 测试要求

| 测试类型 | 覆盖范围 |
|---------|---------|
| 单元测试 | YAMLCommandReader 解析、元数据构造、检索过滤逻辑 |
| 集成测试 | 端到端：YAML → 索引构建 → 检索 → 结果验证 |
| 回归测试 | 已有 YAML 条目更新后，检索结果正确性不变 |

---

## 10. 阶段一边界与约束

### 10.1 阶段一不包含

| 功能 | 策略 | 后续阶段 |
|------|------|---------|
| 增量实时更新（监听文件变化自动重建） | 新增文件后手动触发重建或重启服务 | Phase 2：文件监听 + 增量更新 |
| 混合检索（向量 + BM25 关键词） | 阶段一仅向量检索 + 元数据过滤 | Phase 2：引入 BM25 混合检索 |
| 重排序（Reranker） | 阶段一依赖向量相似度排序 | Phase 2：引入 Cross-Encoder 重排序 |
| 知识图谱 | 阶段一不构建知识图谱 | Phase 3：评估 GraphRAG 补充 |
| 多语言知识 | 阶段一仅中文知识条目 | 按需扩展 |
| 知识管理 UI | 阶段一无前端管理界面 | Phase 3 |

### 10.2 数据量预估

| 数据类型 | 阶段一预估规模 | Chroma 可承载 |
|---------|--------------|--------------|
| 命令条目 | 50-100 条 | ✅ 轻松（Chroma 可承载百万级） |
| 厂商文档 | 5-10 篇 Markdown | ✅ |
| SOP | 3-5 篇 | ✅ |

### 10.3 性能约束

| 指标 | 目标值 | 说明 |
|------|--------|------|
| 索引构建时间 | < 30 秒 | 100 条命令条目 + 10 篇文档 |
| 单次检索延迟 | < 500ms | 含 Embedding 调用（通过网络） |
| 索引加载时间 | < 5 秒 | 从 chroma_db/ 加载已有索引 |
| 内存占用 | < 200MB | Chroma 嵌入式模式 |

---

## 11. 演进路径

### 11.1 Phase 2 增强（演进预留）

| 增强项 | 变更范围 |
|--------|---------|
| 文件监听自动重建 | 新增 watcher 模块，监听 data/ 目录变化 |
| BM25 混合检索 | retriever.py 增加关键词检索路径，结果融合 |
| Cross-Encoder 重排序 | 新增 reranker 模块，对检索结果二次排序 |
| 更多厂商知识 | 扩展 data/commands/ 目录，新增 Cisco/Juniper 条目 |
| Chroma Server 模式 | 数据量大时从嵌入式切换到独立服务，改一行配置 |

### 11.2 Phase 3 增强（演进预留）

| 增强项 | 变更范围 |
|--------|---------|
| 知识图谱 | 评估 Microsoft GraphRAG 或 Neo4j，作为向量检索的补充 |
| 知识管理 UI | 前端增加知识库管理页面 |
| 知识条目版本管理 | 条目变更历史追踪 |
| 多语言支持 | 知识条目支持中英文 |

---

## 附录 A：LlamaIndex + Chroma 集成关键代码

> 以下代码对齐 LlamaIndex v0.12+ API（使用 `Settings` 替代已废弃的 `ServiceContext`）。

### A.1 Chroma 持久化客户端初始化

```python
import chromadb
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.core import VectorStoreIndex, StorageContext, Settings

def init_chroma(persist_dir: str, collection_name: str = "knowledge"):
    """初始化 Chroma 持久化客户端和 LlamaIndex 向量存储"""
    # Chroma 嵌入式持久化客户端（线程安全，单进程模式）
    chroma_client = chromadb.PersistentClient(path=persist_dir)

    # 获取或创建集合（使用余弦相似度）
    chroma_collection = chroma_client.get_or_create_collection(
        name=collection_name,
        metadata={"hnsw:space": "cosine"},
    )

    # LlamaIndex 向量存储适配
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)
    storage_context = StorageContext.from_defaults(vector_store=vector_store)

    return chroma_client, vector_store, storage_context
```

### A.2 Embedding 模型配置

#### A.2.1 方案 A：OpenAI Embedding（通过 LiteLLM 网关，默认）

```python
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings

def configure_openai_embedding(api_base: str, model: str = "text-embedding-3-small"):
    """配置 OpenAI Embedding 模型，通过 LiteLLM 网关调用"""
    Settings.embed_model = OpenAIEmbedding(
        model=model,
        api_base=api_base,
        embed_batch_size=32,
    )
```

#### A.2.2 方案 B：BGE 本地模型

```python
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.core import Settings

def configure_local_embedding(model_name: str = "BAAI/bge-m3", device: str = "cpu"):
    """配置本地 BGE Embedding 模型"""
    Settings.embed_model = HuggingFaceEmbedding(
        model_name=model_name,
        device=device,
        embed_batch_size=32,
    )
```

### A.3 元数据过滤检索

```python
from llama_index.core.vector_stores import MetadataFilters, MetadataFilter

def filtered_retrieve(index, query: str, vendor: str = None, top_k: int = 5):
    """带元数据过滤的向量检索"""
    filters = []
    if vendor:
        filters.append(MetadataFilter(key="vendor", value=vendor))

    retriever = index.as_retriever(
        similarity_top_k=top_k,
        filters=MetadataFilters(filters=filters) if filters else None,
    )

    return retriever.retrieve(query)
```

### A.4 从已有 Chroma 集合加载索引

```python
def load_existing_index(vector_store):
    """从已有 Chroma 集合加载 LlamaIndex 索引（不重新嵌入）"""
    return VectorStoreIndex.from_vector_store(vector_store)
```

### A.5 完整初始化流程

```python
import chromadb
from llama_index.core import VectorStoreIndex, StorageContext, Settings
from llama_index.vector_stores.chroma import ChromaVectorStore
from llama_index.embeddings.openai import OpenAIEmbedding

def initialize_knowledge_service(
    chroma_path: str,
    embedding_api_base: str,
    embedding_model: str = "text-embedding-3-small",
    rebuild: bool = False,
):
    """完整的知识检索引擎初始化流程"""

    # 1. 配置全局 Settings（禁用 LLM，设置 Embedding）
    Settings.llm = None
    Settings.embed_model = OpenAIEmbedding(
        model=embedding_model,
        api_base=embedding_api_base,
        embed_batch_size=32,
    )

    # 2. 初始化 Chroma
    chroma_client = chromadb.PersistentClient(path=chroma_path)
    chroma_collection = chroma_client.get_or_create_collection(
        name="knowledge",
        metadata={"hnsw:space": "cosine"},
    )
    vector_store = ChromaVectorStore(chroma_collection=chroma_collection)

    # 3. 加载或构建索引
    if chroma_collection.count() > 0 and not rebuild:
        # 已有数据：直接加载（无需重新嵌入）
        index = VectorStoreIndex.from_vector_store(vector_store)
    else:
        # 全量构建：从 data/ 目录加载文档 → 嵌入 → 写入 Chroma
        storage_context = StorageContext.from_defaults(vector_store=vector_store)
        from llm.knowledge_service.loader import YAMLCommandReader
        docs = YAMLCommandReader().load_data("llm/knowledge_service/data/commands")
        index = VectorStoreIndex.from_documents(
            docs, storage_context=storage_context, show_progress=True
        )

    return index
```

---

## 附录 B：参考来源

- [LlamaIndex 官方文档 - Settings 配置](https://docs.llamaindex.ai/en/stable/module_guides/supporting_modules/service_context_migration/) — ServiceContext 迁移到 Settings 的说明
- [LlamaIndex 官方文档 - Chroma 集成](https://docs.llamaindex.ai/en/stable/examples/vector_stores/chroma_metadata_filter/) — Chroma 元数据过滤检索
- [LlamaIndex 官方文档 - 自定义 Reader](https://docs.llamaindex.ai/en/stable/module_guides/loading/documents_and_nodes/usage_documents/) — BaseReader 接口
- [Chroma 官方文档 - PersistentClient](https://docs.trychroma.com/docs/overview/introduction) — 嵌入式持久化客户端
- [Chroma Cookbook - 系统约束](https://cookbook.chromadb.dev/core/system_constraints/) — 线程安全与进程安全说明
- [Chroma Cookbook - 存储布局](https://cookbook.chromadb.dev/core/storage-layout/) — 数据目录结构与备份策略
- [BAAI/bge-m3 模型](https://huggingface.co/BAAI/bge-m3) — 多语言 Embedding 模型（100+ 语言，8192 token 上下文）
- [BAAI/bge-large-zh-v1.5 模型](https://huggingface.co/BAAI/bge-large-zh-v1.5) — 中文优化 Embedding 模型
- [CiscoDevNet/Local-RAG-AI-Assistant](https://github.com/CiscoDevNet/Local-RAG-AI-Assistant) - Cisco 官方网络运维 RAG 生产实现
- [Weaviate Chunking Strategies](https://weaviate.io/blog/chunking-strategies-for-rag) - RAG 分块策略最佳实践
