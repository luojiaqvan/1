# 阶段一 API 接口规范

## 1. 文档说明

本文档定义"大模型 + 网络工程配置/运维平台"阶段一的全部 API 接口。

### 1.1 适用范围

仅覆盖阶段一（自然语言到指令执行），不包含审批、RBAC、回滚等后续阶段能力。

### 1.2 通用约定

- 前端 API 前缀：`/api/v1`
- 认证方式：`Authorization: Bearer <JWT_TOKEN>`
- 时间格式：ISO 8601（UTC）
- 字符编码：UTF-8
- 分页参数：`page`（从 1 开始）、`page_size`（默认 20）
- 内部服务间通信为 Python 进程内模块调用（阶段一不拆微服务），但按独立接口契约定义

#### 1.2.1 统一错误响应

所有前端 API 错误响应使用统一格式：

```json
{
  "code": "ERROR_CODE",
  "message": "人类可读的错误描述",
  "details": null
}
```

| HTTP 状态码 | code | 说明 |
|---|---|---|
| 400 | bad_request | 请求参数错误 |
| 401 | unauthorized | 未认证或 token 无效 |
| 403 | forbidden | 无权限访问 |
| 404 | not_found | 资源不存在 |
| 409 | conflict | 资源冲突（如重复创建） |
| 422 | validation_error | 请求体验证失败 |
| 500 | internal_error | 服务器内部错误 |

### 1.3 核心调用链路

```
用户消息 → 后端 API → 大模型网关(单次流式 agentic 调用, stream=True)
       → 模型通过 function calling 自主调用工具(parse_intent / search_knowledge / query_device_status / generate_commands)
       → llm/intent_engine 标准化意图并组装/校验候选命令 proposal
       → 推送 intent_parsed / approval_required SSE 事件
       → 前端渲染意图卡片与授权卡片 → 用户确认 → 执行层消费已确认 proposal → 设备管理程序 → 设备
```

---

## 2. 前端 API

### 2.1 认证

#### POST `/api/v1/auth/login`

用户名密码登录。

**请求：**

```json
{
  "username": "string",
  "password": "string"
}
```

**响应 200：**

```json
{
  "token": "string",
  "expires_at": "2026-01-01T00:00:00Z",
  "user": {
    "id": "uuid",
    "username": "string"
  }
}
```

**响应 401：**

```json
{
  "code": "unauthorized",
  "message": "用户名或密码错误",
  "details": null
}
```

#### POST `/api/v1/auth/logout`

登出，销毁 token。

**请求头：** `Authorization: Bearer <token>`

**响应 200：**

```json
{ "message": "ok" }
```

#### GET `/api/v1/auth/me`

校验 token 有效性，返回当前用户信息。

**请求头：** `Authorization: Bearer <token>`

**响应 200：**

```json
{
  "id": "uuid",
  "username": "string",
  "created_at": "2026-01-01T00:00:00Z"
}
```

**响应 401：**

```json
{
  "code": "unauthorized",
  "message": "未认证或 token 已过期",
  "details": null
}
```

---

### 2.2 对话与任务

#### GET `/api/v1/conversations`

获取当前用户的会话列表。

**查询参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| page | int | 1 | 页码 |
| page_size | int | 20 | 每页数量 |

**响应 200：**

```json
{
  "items": [
    {
      "id": "uuid",
      "title": "string",
      "created_at": "2026-01-01T00:00:00Z",
      "updated_at": "2026-01-01T00:00:00Z",
      "message_count": 10
    }
  ],
  "total": 100,
  "page": 1,
  "page_size": 20
}
```

#### POST `/api/v1/conversations`

创建新会话。

**请求：**

```json
{
  "title": "string or null"
}
```

**响应 201：**

```json
{
  "id": "uuid",
  "title": "string",
  "created_at": "2026-01-01T00:00:00Z"
}
```

#### GET `/api/v1/conversations/{id}`

获取会话详情，含消息历史。

**查询参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| message_limit | int | 50 | 返回最近 N 条消息 |
| before | string | null | 游标分页，加载更早的消息（消息 ID） |

**响应 200：**

```json
{
  "id": "uuid",
  "title": "string",
  "created_at": "2026-01-01T00:00:00Z",
  "updated_at": "2026-01-01T00:00:00Z",
  "messages": [
    {
      "id": "uuid",
      "role": "user | assistant",
      "content": "string",
      "reasoning": {
        "content": "string",
        "collapsed_by_default": true
      },
      "content_type": "text | intent_card | command_card | result_card",
      "metadata": "object or null",
      "created_at": "2026-01-01T00:00:00Z"
    }
  ],
  "has_more": false
}
```

> system 角色的消息用于存储 LLM 系统提示词和工具调用上下文，不通过此接口返回给前端。前端仅可见 user 和 assistant 消息。`reasoning` 仅在 assistant 消息且模型实际返回思考内容时出现；前端默认折叠展示。

#### DELETE `/api/v1/conversations/{id}`

软删除会话。会话及关联消息、任务在前端不再可见，数据保留在数据库中。

**响应 200：**

```json
{ "message": "ok" }
```

> 关联的消息和任务不物理删除，但通过软删除过滤后前端无法访问。

#### POST `/api/v1/conversations/{id}/messages` ⭐ 核心

发送用户消息，触发整条 LLM 流水线。发送后立即返回，后续状态通过 SSE 推送。

**请求：**

```json
{
  "content": "查看 CoreSwitch01 的接口状态",
  "context": {
    "device_ids": ["uuid"]
  }
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| content | string | 是 | 用户自然语言输入 |
| context.device_ids | string[] | 否 | 用户指定的目标设备 ID 列表 |

**响应 202：**

```json
{
  "message_id": "uuid",
  "task_id": "uuid or null"
}
```

> `task_id` 仅在触发了设备操作任务时有值。后续通过 SSE 推送流式内容和状态变更。

#### GET `/api/v1/tasks/{task_id}`

获取任务详情，包含状态、意图、候选命令、执行结果和模型结果总结。

**响应 200：**

```json
{
  "id": "uuid",
  "conversation_id": "uuid",
  "status": "running | pending_approval | executing | completed | failed | rejected",
  "intent": {
    "operation_type": "query | inspect | change | rollback",
    "target_type": "device | interface | vlan | bgp | ...",
    "target_devices": [
      {
        "device_id": "uuid",
        "device_name": "string",
        "vendor": "string",
        "model": "string or null"
      }
    ],
    "scope": "single | multi",
    "risk_level": "low | medium | high",
    "description": "查看 CoreSwitch01 的接口状态",
    "constraints": [],
    "pre_checks": ["检查设备连通性", "确认接口存在"],
    "expected_result": "接口状态信息列表",
    "rollback_plan": null
  },
  "candidate_commands": [
    {
      "device_id": "uuid",
      "device_name": "string",
      "commands": [
        {
          "command": "display interface brief",
          "description": "查看接口简要信息",
          "risk_level": "low",
          "is_config": false,
          "generation_basis": {
            "source_type": "knowledge_entry",
            "source_id": "huawei_vrp_interface_display_001",
            "source_title": "华为 VRP 接口查询命令",
            "snippet": "display interface brief"
          },
          "applicability": "适用于 VRP V200R019 及以上版本",
          "expect_pattern": "接口名\\s+状态",
          "confidence": 0.95
        }
      ],
      "generation_source": "knowledge_grounded_model",
      "confidence": 0.92,
      "validation_notes": []
    }
  ],
  "execution_results": [
    {
      "device_id": "uuid",
      "device_name": "string",
      "status": "success | partial | failed",
      "outputs": [
        {
          "command": "display interface brief",
          "output": "设备回显原文...",
          "parsed_output": {
            "schema_version": "1.0",
            "command_type": "interface_summary",
            "parse_status": "success",
            "format": "table",
            "summary": "共解析到 24 个接口，22 个 up，2 个 down",
            "data": {
              "interfaces": [
                {
                  "name": "GigabitEthernet0/0/1",
                  "status": "up",
                  "protocol_status": "up",
                  "speed": "1000M",
                  "description": null
                }
              ]
            },
            "warnings": []
          },
          "exit_code": 0
        }
      ],
      "error": null
    }
  ],
  "result_summary": {
    "source": "model",
    "status": "ready",
    "content": "CoreSwitch01 接口状态已返回。共 24 个接口，其中 22 个正常 up，2 个 down，未发现执行异常。",
    "generated_at": "2026-01-01T00:00:05Z"
  },
  "created_at": "2026-01-01T00:00:00Z",
  "updated_at": "2026-01-01T00:00:00Z"
}
```

> operation_type 对齐 ROADMAP 定义：query | inspect | change | rollback。阶段一 generate_change 与 execute_change 合并为 change 流程，由任务状态区分阶段。
>
> rollback_plan 为阶段一保留字段，不启用自动回滚。查询类操作 rollback_plan 为 null。
>
> `result_summary` 为执行完成后的模型总结结果。阶段一要求：凡进入执行链路并产生 `execution_results`，后端都必须基于执行结果再次调用主模型的结果总结能力，生成面向用户的自然语言总结，并作为 assistant 消息写入会话历史；前端除展示 `result_card` 外，还应展示该总结文本。

#### POST `/api/v1/tasks/{task_id}/confirm`

用户确认执行候选命令。需携带 `proposal_id` 以关联对应的授权卡片。

**请求：**

```json
{
  "proposal_id": "uuid",
  "comment": "string or null"
}
```

**响应 200：**

```json
{
  "task_id": "uuid",
  "status": "executing"
}
```

> 后续通过 SSE 推送执行进度。

#### POST `/api/v1/tasks/{task_id}/reject`

用户拒绝候选命令。

**请求：**

```json
{
  "reason": "string or null"
}
```

**响应 200：**

```json
{
  "task_id": "uuid",
  "status": "rejected"
}
```

#### PUT `/api/v1/tasks/{task_id}/commands`

用户编辑候选命令后提交。编辑后仍需确认。

**请求：**

```json
{
  "candidate_commands": [
    {
      "device_id": "uuid",
      "commands": [
        {
          "command": "display interface brief",
          "description": "查看接口简要信息",
          "risk_level": "low",
          "is_config": false,
          "generation_basis": {
            "source_type": "knowledge_entry",
            "source_id": "huawei_vrp_interface_display_001",
            "source_title": "华为 VRP 接口查询命令",
            "snippet": "display interface brief"
          },
          "applicability": "适用于 VRP V200R019 及以上版本",
          "expect_pattern": "接口名\\s+状态",
          "confidence": 0.95
        }
      ]
    }
  ]
}
```

**响应 200：**

```json
{
  "task_id": "uuid",
  "status": "pending_approval",
  "candidate_commands": [
    {
      "device_id": "uuid",
      "device_name": "string",
      "commands": [
        {
          "command": "display interface brief",
          "description": "查看接口简要信息",
          "risk_level": "low",
          "is_config": false,
          "generation_basis": {
            "source_type": "knowledge_entry",
            "source_id": "huawei_vrp_interface_display_001",
            "source_title": "华为 VRP 接口查询命令",
            "snippet": "display interface brief"
          },
          "applicability": "适用于 VRP V200R019 及以上版本",
          "expect_pattern": "接口名\\s+状态",
          "confidence": 0.95
        }
      ],
      "generation_source": "knowledge_grounded_model",
      "confidence": 0.92,
      "validation_notes": []
    }
  ]
}
```

---

### 2.3 设备连接管理

#### GET `/api/v1/devices`

获取当前用户的设备列表。

**查询参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| page | int | 1 | 页码 |
| page_size | int | 50 | 每页数量 |
| vendor | string | null | 按厂商过滤（huawei / h3c） |
| status | string | null | 按状态过滤（online / offline / unknown） |

**响应 200：**

```json
{
  "items": [
    {
      "id": "uuid",
      "name": "CoreSwitch01",
      "host": "192.168.1.1",
      "port": 22,
      "protocol": "ssh",
      "vendor": "huawei",
      "device_type": "huawei",
      "status": "online",
      "last_connected_at": "2026-01-01T00:00:00Z",
      "created_at": "2026-01-01T00:00:00Z",
      "updated_at": "2026-01-01T00:00:00Z"
    }
  ],
  "total": 10,
  "page": 1,
  "page_size": 50
}
```

#### POST `/api/v1/devices`

添加设备连接。凭据明文传入，后端加密存储。

**请求：**

```json
{
  "name": "CoreSwitch01",
  "host": "192.168.1.1",
  "port": 22,
  "protocol": "ssh",
  "vendor": "huawei",
  "device_type": "huawei",
  "username": "admin",
  "password": "明文密码",
  "description": "核心交换机"
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | 是 | 设备名称/别名 |
| host | string | 是 | IP 或主机名 |
| port | int | 否 | ssh 默认 22，telnet 默认 23；未传时按 protocol 自动填充 |
| protocol | string | 是 | ssh / telnet |
| vendor | string | 是 | huawei / h3c |
| device_type | string | 是 | netmiko device_type（如 huawei / hp_comware） |
| username | string | 是 | 设备登录用户名 |
| password | string | 是 | 设备登录密码（明文传入，后端加密存储） |
| description | string | 否 | 设备描述 |

**vendor 与 device_type 映射关系：**

| vendor | device_type | 说明 |
|--------|-------------|------|
| huawei | huawei | 华为 VRP 设备 |
| h3c | hp_comware | H3C Comware 设备 |

> device_type 使用 netmiko 标准设备类型标识。后续新增厂商时补充映射。

**响应 201：**

```json
{
  "id": "uuid",
  "name": "CoreSwitch01",
  "host": "192.168.1.1",
  "port": 22,
  "protocol": "ssh",
  "vendor": "huawei",
  "device_type": "huawei",
  "status": "unknown",
  "created_at": "2026-01-01T00:00:00Z"
}
```

> 响应中不返回凭据。

#### GET `/api/v1/devices/{id}`

获取设备详情。

**响应 200：**

```json
{
  "id": "uuid",
  "name": "CoreSwitch01",
  "host": "192.168.1.1",
  "port": 22,
  "protocol": "ssh",
  "vendor": "huawei",
  "device_type": "huawei",
  "model": "S5735-L24T4X",
  "os_version": "VRP V200R021C00",
  "status": "online",
  "last_connected_at": "2026-01-01T00:00:00Z",
  "description": "核心交换机",
  "created_at": "2026-01-01T00:00:00Z",
  "updated_at": "2026-01-01T00:00:00Z"
}
```

> 不返回凭据。model 和 os_version 可通过 test-connection 自动发现获取。

#### PUT `/api/v1/devices/{id}`

更新设备信息。不传的字段不更新。

**请求：**

```json
{
  "name": "string or null",
  "host": "string or null",
  "port": 22,
  "protocol": "string or null",
  "vendor": "string or null",
  "device_type": "string or null",
  "username": "string or null",
  "password": "string or null",
  "description": "string or null"
}
```

**响应 200：** 同 GET 设备详情。

#### DELETE `/api/v1/devices/{id}`

删除设备。同时断开活跃连接，清除加密凭据。

**响应 200：**

```json
{ "message": "ok" }
```

#### POST `/api/v1/devices/{id}/test-connection`

测试设备连通性。

**响应 200：**

```json
{
  "success": true,
  "latency_ms": 45,
  "device_info": {
    "vendor": "Huawei",
    "model": "S5735-L24T4X",
    "os_version": "VRP V200R021C00"
  },
  "error": null
}
```

---

### 2.4 设置

#### GET `/api/v1/settings/model-configs`

获取当前用户的所有模型配置列表。

**响应 200：**

```json
{
  "configs": [
    {
      "id": "uuid",
      "name": "生产 GPT-4o",
      "is_active": true,
      "main_model": "gpt-4o",
      "main_model_base_url": "string or null",
      "main_model_api_key_set": true,
      "created_at": "2025-01-01T00:00:00Z",
      "updated_at": "2025-01-01T00:00:00Z"
    }
  ]
}
```

> API Key 不返回本体，仅返回是否已设置。`is_active` 为 `true` 的配置为当前激活配置，列表中至多一项。

#### POST `/api/v1/settings/model-configs`

新增一套模型配置。

**请求：**

```json
{
  "name": "生产 GPT-4o",
  "main_model": "string or null",
  "main_model_base_url": "string or null",
  "main_model_api_key": "string or null"
}
```

> `name` 在同一用户下必须唯一。

**响应 201：** 同单条配置对象（含 `id`、`is_active` 等）。

**错误 409：** 配置名称已存在。

#### PUT `/api/v1/settings/model-configs/{id}`

更新指定模型配置。不传的字段不更新。`name` 不可改为与该用户其他配置重复的名称。

**请求：**

```json
{
  "name": "string or null",
  "main_model": "string or null",
  "main_model_base_url": "string or null",
  "main_model_api_key": "string or null"
}
```

**响应 200：** 同单条配置对象。

**错误 404：** 配置不存在或不属于当前用户。

#### DELETE `/api/v1/settings/model-configs/{id}`

删除指定模型配置。

- 如果删除的是当前激活配置且该用户还有其他配置，后端自动激活按 `updated_at` 最近的一套配置
- 如果删除的是该用户的唯一一套配置，删除后该用户无激活配置，对话调用将退回使用环境变量默认值

**响应 204：** 无内容。

**错误 404：** 配置不存在或不属于当前用户。

#### POST `/api/v1/settings/model-configs/{id}/activate`

将指定配置设为当前激活配置。后端在同一事务中将旧激活配置的 `is_active` 置 `false`，目标配置置 `true`。

**响应 200：** 同单条配置对象（`is_active` 已为 `true`）。

**错误 404：** 配置不存在或不属于当前用户。

#### GET `/api/v1/settings/models/available`

获取可用模型列表。

**响应 200：**

```json
{
  "models": [
    {
      "id": "gpt-4o",
      "name": "GPT-4o",
      "provider": "openai",
      "supports_function_calling": true,
      "supports_streaming": true
    }
  ]
}
```

---

### 2.5 SSE 实时推送

#### GET `/api/v1/sse`

建立 SSE 长连接，接收所有实时事件。

**请求头：**

- `Authorization: Bearer <token>`
- `Accept: text/event-stream`

**连接说明：**

- 前端在用户登录后立即建立连接
- 连接断开后自动重连（带 `Last-Event-ID`）
- 每个用户一个 SSE 连接

**事件格式：**

```
event: <event_type>
data: <json_payload>
id: <event_id>
```

---

### 2.6 审计日志

#### GET `/api/v1/tasks/{task_id}/audit-trail`

获取单个任务的完整审计链路，用于任务回放和排查。

**路径参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| task_id | string | 任务 ID |

**请求头：**

- `Authorization: Bearer <token>`

**响应 200：**

```json
{
  "task_id": "uuid",
  "events": [
    {
      "audit_id": "uuid",
      "event_type": "message_received",
      "event_data": {
        "content": "查看 CoreSwitch01 接口状态"
      },
      "timestamp": "2026-01-01T00:00:00Z"
    },
    {
      "audit_id": "uuid",
      "event_type": "intent_parsed",
      "event_data": {
        "operation_type": "query",
        "target_devices": ["uuid"]
      },
      "timestamp": "2026-01-01T00:00:01Z"
    }
  ]
}
```

> 对应内部接口 AU2.get_task_audit_trail。

#### GET `/api/v1/audit-logs`

按条件分页查询审计日志。

**请求头：**

- `Authorization: Bearer <token>`

**查询参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| task_id | string | 否 | 按任务过滤 |
| conversation_id | string | 否 | 按会话过滤 |
| event_type | string | 否 | 按事件类型过滤（见 AU1 审计事件类型表） |
| start_time | string | 否 | 起始时间（ISO 8601） |
| end_time | string | 否 | 结束时间（ISO 8601） |
| page | int | 否 | 页码，默认 1 |
| page_size | int | 否 | 每页条数，默认 20，最大 100 |

**响应 200：**

```json
{
  "items": [
    {
      "audit_id": "uuid",
      "task_id": "uuid",
      "conversation_id": "uuid",
      "event_type": "command_executed",
      "event_data": {
        "device_id": "uuid",
        "command": "display interface brief",
        "exit_code": 0
      },
      "timestamp": "2026-01-01T00:00:05Z"
    }
  ],
  "total": 42,
  "page": 1,
  "page_size": 20
}
```

> 对应内部接口 AU3.query_logs。

---

## 3. 内部服务 API

以下为后端 API 服务作为编排层调用各内部服务的接口定义。阶段一为进程内模块调用，但按独立接口契约设计。

### 3.1 大模型网关

基于 LiteLLM 封装，对外暴露 OpenAI 兼容接口。

#### 3.1.1 后端传给网关的配置对象

用户级模型配置的**来源**在后端 API 服务，网关只消费后端传入的运行时配置对象。后端应先完成数据库读取、解密与优先级合并，再按当前调用场景把选定配置传给网关。

统一配置对象建议命名为 `model_config`，适用于所有网关调用：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| model | string | 是 | 当前调用实际使用的模型标识，必须是 LiteLLM 可识别格式；如走 OpenAI 兼容端点，应传 `openai/<model>` 形式 |
| api_base | string or null | 否 | 当前模型调用使用的上游 OpenAI 兼容端点 |
| api_key | string or null | 否 | 当前模型调用使用的已解密运行时密钥；如上游要求占位 key，也由后端传入 |
| timeout_seconds | float or null | 否 | 当前调用默认超时时间，网关可被单次请求参数覆盖 |
| extra_headers | object or null | 否 | 需要透传给上游的额外请求头，阶段一默认可为空 |

**边界约束：**

- 后端负责决定本次调用传入哪一套模型配置；后端从 `user_model_configs` 表中读取当前用户的激活配置（`is_active = 1`）作为运行时配置
- 网关不得直接读取 `user_model_configs` 表
- 网关必须校验并归一化 `model_config`，但不负责配置来源管理
- 请求级动态参数（如 `messages`、`toolset`、`response_format`、`temperature`、`max_tokens`）不属于 `model_config`

#### 3.1.2 后端传给网关的工具配置对象

阶段一开始，主模型的工具定义不再建议由调用方直接拼接成裸 `tools[]` 数组；**权威输入应为 `toolset`**，由 `skills + mcp + tool_definitions` 组合描述，再由网关/工具层编译为上游模型可消费的 provider tools。

编译规则与 Provider Schema 格式契约见 TOOLS_SPEC.md §3.1.1 与 §3.1.2。API_SPEC 本节仅定义 toolset 数据结构。

```json
{
  "toolset_id": "phase1-default-toolset",
  "skills": [
    {
      "skill_id": "skill.intent.parse",
      "name": "parse_intent",
      "description": "将自然语言请求解析为结构化网络运维意图",
      "instruction": "优先输出标准化意图，不得猜测不存在的设备与厂商信息",
      "input_schema_ref": "TL1",
      "output_schema_ref": "IE1",
      "enabled": true
    }
  ],
  "mcps": [
    {
      "mcp_id": "mcp.device.default",
      "server_name": "device-manager-mcp",
      "transport": "inproc",
      "capabilities": ["list_connections", "execute_command"],
      "enabled": true
    }
  ],
  "tool_definitions": [
    {
      "tool_name": "list_devices",
      "skill_id": "skill.connection.list_devices",
      "mcp_id": "mcp.device.default",
      "mcp_capability": "list_connections",
      "exposure": "model_direct",
      "provider_schema": "TL4"
    },
    {
      "tool_name": "query_device_status",
      "skill_id": "skill.device.query_status",
      "mcp_id": "mcp.device.default",
      "mcp_capability": "execute_command",
      "exposure": "model_direct",
      "provider_schema": "TL3"
    },
    {
      "tool_name": "generate_commands",
      "skill_id": "skill.commands.generate",
      "mcp_id": null,
      "mcp_capability": null,
      "exposure": "model_direct",
      "provider_schema": "TL5"
    }
  ]
}
```

`toolset` 字段定义：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| toolset_id | string | 是 | 本次调用使用的工具集标识 |
| skills[] | object[] | 是 | 技能说明书集合；描述模型如何理解、何时调用、输入输出契约引用 |
| mcps[] | object[] | 否 | MCP 连接与执行封装集合；定义服务器、传输、能力与调用约束 |
| tool_definitions[] | object[] | 是 | 面向模型暴露的逻辑工具定义；每项由 skill + 可选 mcp capability 组合而成 |

`skills[]` 最小字段：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| skill_id | string | 是 | 技能稳定标识 |
| name | string | 是 | 技能名称，通常与逻辑工具名对齐 |
| description | string | 是 | 供模型理解的能力说明 |
| instruction | string | 是 | 技能执行说明书/约束 |
| input_schema_ref | string | 否 | 输入契约引用，如 `TL1` |
| output_schema_ref | string | 否 | 输出契约引用，如 `IE1` / `KR1` |
| enabled | bool | 是 | 是否启用 |

`mcps[]` 最小字段：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| mcp_id | string | 是 | MCP 绑定稳定标识 |
| server_name | string | 是 | MCP 服务名称 |
| transport | string | 是 | `inproc / stdio / sse / streamable_http` |
| capabilities | string[] | 是 | 当前 MCP 暴露的能力列表 |
| connection_scope | string | 否 | 连接范围（如 `user / workspace / global`） |
| timeout_seconds | float | 否 | 该 MCP 默认超时时间 |
| enabled | bool | 是 | 是否启用 |

`tool_definitions[]` 最小字段：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| tool_name | string | 是 | 逻辑工具名，对外暴露给模型 |
| skill_id | string | 是 | 该工具绑定的 skill |
| mcp_id | string or null | 否 | 该工具依赖的 MCP 绑定 |
| mcp_capability | string or null | 否 | 该工具使用的 MCP 能力，如 `list_connections` |
| exposure | string | 是 | 暴露策略：`model_direct / approval_gated / backend_only` |
| provider_schema | string | 是 | 编译后的 provider schema 引用，如 `TL4`。Provider Schema 的格式契约与编译规则见 TOOLS_SPEC.md §3.1.1 与 §3.1.2 |

**MCP 最小能力要求：**

| capability | 说明 | 默认暴露策略 |
|-----------|------|----------------|
| `list_connections` | 列出当前用户或当前作用域下可用连接/机器摘要 | `model_direct` |
| `execute_command` | 在指定机器/连接上执行命令并返回标准结果 | `approval_gated` |

> 安全约束：`execute_command` 是 MCP 必须具备的后端能力，但**默认不得在候选命令生成阶段直接暴露给主模型**。阶段一默认仍由 IE4 + DM7 在用户授权后执行，避免模型绕过审批直接获得执行权。

#### 3.1.3 主模型 — 流式 Agentic 调用

单次流式调用中同时完成意图解析、工具调用与候选命令生成。模型通过 function calling 自主决定何时调用工具（TL1-TL5），文本回复与工具调用在同一流中交织输出。

```python
llm_gateway.chat_completion_stream(
    model_config={...},
    messages=[
        {"role": "system", "content": "网络运维 agent 系统提示词..."},
        {"role": "user", "content": "用户自然语言"}
    ],
    toolset={
        "skills": [...],
        "mcps": [...],
        "tool_definitions": [...]
    },
    stream=True,
    user_id="uuid"
)
# 返回 AsyncGenerator[StreamChunk, None]
```

> 网关在内部将 `toolset` 编译为上游模型兼容的 `tools[]`；调用方不应直接手写 provider-specific tools 作为长期契约。

**统一 Chunk 结构（内部流）：**

```json
// 文本增量
{ "type": "text_delta", "seq": 0, "delta": "我来帮您查看..." }

// 思考内容增量
{ "type": "reasoning_delta", "seq": 1, "delta": "先确认目标设备和接口范围..." }

// 工具调用开始
{ "type": "tool_call_start", "seq": 5, "toolCallId": "call_abc", "name": "query_device_status" }

// 工具调用参数增量
{ "type": "tool_call_args_delta", "seq": 6, "toolCallId": "call_abc", "argsDelta": "{\"device_" }

// 工具调用完成（后端已组装并校验）
{ "type": "tool_call_complete", "seq": 10, "toolCallId": "call_abc", "name": "generate_commands", "rawArgs": "...", "parsedArgs": {...}, "valid": true }

// 状态变化
{ "type": "state", "seq": 11, "state": "pending_approval" }

// 错误
{ "type": "error", "seq": 12, "code": "TIMEOUT", "message": "模型响应超时", "retryable": true }
```

| 字段 | 类型 | 说明 |
|------|------|------|
| type | string | chunk 类型：text_delta / reasoning_delta / tool_call_start / tool_call_args_delta / tool_call_complete / state / error |
| seq | int | 全局递增序号，用于前端保序拼接 |
| delta | string | 文本或思考内容增量（type=text_delta / reasoning_delta 时） |
| toolCallId | string | 工具调用唯一标识（tool_call 相关类型时） |
| name | string | 工具名称（tool_call_start / tool_call_complete 时） |
| argsDelta | string | 参数 JSON 增量片段（type=tool_call_args_delta 时） |
| rawArgs | string | 完整参数 JSON 原文（type=tool_call_complete 时） |
| parsedArgs | object | 后端解析后的参数对象（type=tool_call_complete 时） |
| valid | bool | 参数 JSON 是否有效（type=tool_call_complete 时） |
| state | string | 任务状态变化（type=state 时） |
| code | string | 错误码（type=error 时） |
| message | string | 错误描述（type=error 时） |
| retryable | bool | 是否可重试（type=error 时） |

**约束：**

- 阶段一主链路默认仍以流式 agentic 调用为主；但对上游 OpenAI 兼容模型返回的非流式思考内容，后端必须归一化为统一事件契约，前端不得因为上游是否流式而分叉两套展示逻辑
- 模型通过 function calling 自主决定何时调用工具，可能多次调用不同工具
- `generate_commands`（TL5）工具的调用参数即为候选命令，后端组装校验后推送 `approval_required` 事件
- `toolset.tool_definitions[].exposure=approval_gated` 或 `backend_only` 的能力，不得在候选命令生成阶段直接下发给主模型
- 多个 `tool_call` 时，前端分别授权；参数 JSON 无效的 `tool_call` 不展示授权
- 文本回复、思考内容与工具调用可能在同一流中交织输出，前端应分别展示正文与思考区域
- 若模型未返回思考内容，则不推送 `stream_reasoning` 事件，也不在消息对象中写入 `reasoning`

---

### 3.2 意图引擎（阶段一最小职责）

#### IE1. parse_intent

将主模型 function call 返回的原始意图标准化。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| raw_intent | object | 主模型返回的原始意图 JSON |
| context.user_id | string | 用户 ID |
| context.conversation_id | string | 会话 ID |
| context.device_ids | string[] | 涉及的设备 |
| context.available_devices | object[] | 用户可用的设备信息 |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| intent.operation_type | string | query / inspect / change / rollback |
| intent.target_type | string | device / interface / vlan / bgp ... |
| intent.target_devices | object[] | 目标设备列表 |
| intent.scope | string | single / multi |
| intent.risk_level | string | low / medium / high |
| intent.description | string | 意图自然语言描述 |
| intent.constraints | string[] | 约束条件 |
| intent.pre_checks | string[] | 前置检查项 |
| intent.expected_result | string | 预期结果描述 |
| intent.rollback_plan | string or null | 回滚方式（阶段一保留字段，查询类为 null） |
| requires_confirmation | bool | 是否需要人工确认（阶段一始终 true） |

> operation_type 对齐 ROADMAP 定义。阶段一 generate_change 与 execute_change 合并为 change。前端渲染的 `intent_card` 必须以 IE1 输出为准，而不是直接消费模型原始 tool_call。

#### IE3. assemble_and_validate_candidates

将 `generate_commands` 的原始 tool_call、设备上下文与知识引用收口为冻结的候选命令 proposal，并执行阶段一基础校验。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| intent | object | IE1 返回的标准化意图 |
| raw_tool_call | object | `generate_commands` 的原始参数对象 |
| knowledge_refs | object[] | 本次候选命令生成使用的知识引用 |
| device_contexts | object[] | 设备上下文 |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| proposal_id | string | 冻结后的候选命令 proposal 标识 |
| candidate_commands | object[] | 组装后的候选命令列表 |
| valid | bool | 是否通过校验 |
| warnings | string[] | 警告信息 |
| errors | string[] | 错误信息 |
| risk_assessment.overall_risk | string | low / medium / high |
| risk_assessment.high_risk_commands[].device_id | string | 设备 ID |
| risk_assessment.high_risk_commands[].command | string | 高风险命令 |
| risk_assessment.high_risk_commands[].reason | string | 判定原因 |

**补充约束：**

- `generation_source=knowledge_grounded_model` 时，`generation_basis` 必须引用本次 `knowledge_refs` 中的稳定 `source_id`。
- `generation_source=template_fallback` 时，`generation_basis` 必须指向模板来源，不得伪装成知识条目引用。
- 进入降级模式时，`validation_notes` 必须包含降级原因，例如“知识检索为空，已回退到冻结模板”。
- 若既无可用知识引用，也无允许使用的冻结模板，应返回空 `candidate_commands`，并在 `validation_notes` 中说明原因。
- 前端展示与后端执行都必须基于 IE3 返回的冻结 proposal，而不是模型原始 tool_call。

> 阶段一中，知识检索与候选命令生成在主模型的单次 agentic 调用中完成；`llm/intent_engine` 不承担候选命令生成本身，也不承担执行编排与任务结果查询职责。

---

### 3.3 统一设备管理程序

#### DM1. register_device

注册设备，凭据加密存储。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| user_id | string | 用户 ID |
| name | string | 设备名称 |
| host | string | IP 或主机名 |
| port | int | 端口 |
| protocol | string | ssh / telnet |
| vendor | string | huawei / h3c |
| device_type | string | netmiko device_type |
| username | string | 设备登录用户名 |
| password | string | 设备登录密码（明文传入，内部加密存储） |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| device_id | string | 注册后的设备 ID |
| status | string | 设备初始状态（unknown） |

#### DM2-5. CRUD

标准设备 CRUD 操作：`update_device`、`remove_device`、`get_device`、`list_devices`。

#### DM6. test_connection

测试设备连通性。

**入参：** `device_id, timeout=10`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| success | bool | 是否连接成功 |
| latency_ms | int | 延迟毫秒数 |
| device_info | object | vendor, model, os_version, hostname |
| error | string | 错误信息 |

#### DM7. execute_on_device ⭐ 核心

在设备上执行命令序列。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| device_id | string | 设备 ID |
| commands[].command | string | 命令内容 |
| commands[].is_config | bool | 是否为配置命令（需进入配置模式） |
| commands[].timeout | int | 单条命令超时（秒），默认 30 |
| commands[].expect_pattern | string | 期望的提示符/回显模式 |
| stop_on_error | bool | 遇错停止，默认 true |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| device_id | string | 设备 ID |
| status | string | success / partial / failed |
| outputs[].command | string | 执行的命令 |
| outputs[].output | string | 设备回显原文 |
| outputs[].parsed_output | object | 解析后的结构化数据（统一包络 + 按命令类型变化的 data 载荷，见下方说明） |
| outputs[].exit_code | int | 退出码 |
| outputs[].duration_ms | int | 执行耗时 |
| error | string | 错误信息 |

> **parsed_output 统一 Schema（阶段一冻结）**：所有厂商适配层返回的解析结果都必须使用以下统一包络；不同命令类型的差异仅体现在 `command_type` 和 `data` 字段中。
>
> ```json
> {
>   "schema_version": "1.0",
>   "command_type": "interface_summary | route_table | arp_table | system_info | config_change | raw_text",
>   "parse_status": "success | partial | failed",
>   "format": "table | list | kv | diff | text",
>   "summary": "string or null",
>   "data": {},
>   "warnings": ["string"]
> }
> ```
>
> **统一字段含义：**
>
> | 字段 | 类型 | 说明 |
> |------|------|------|
> | schema_version | string | 解析结果版本号，阶段一固定为 `1.0` |
> | command_type | string | 命令类型，决定 `data` 的子结构 |
> | parse_status | string | 解析状态：成功 / 部分成功 / 失败 |
> | format | string | 原始输出对应的主要结构类型 |
> | summary | string or null | 面向上层编排和前端的简要摘要 |
> | data | object | 结构化载荷，具体结构见下表 |
> | warnings | string[] | 解析告警，如“部分字段缺失”“使用回退解析规则” |
>
> **按命令类型约束的 `data` 子结构：**
>
> | command_type | data 结构 |
> |--------------|-----------|
> | interface_summary | `{ "interfaces": [{ "name": "string", "status": "up|down|administratively_down|unknown", "protocol_status": "up|down|unknown|null", "speed": "string or null", "description": "string or null" }] }` |
> | route_table | `{ "routes": [{ "destination": "string", "next_hop": "string", "protocol": "string", "out_interface": "string or null", "preference": "integer or null" }] }` |
> | arp_table | `{ "entries": [{ "ip": "string", "mac": "string", "interface": "string or null", "age": "string or null" }] }` |
> | system_info | `{ "hostname": "string or null", "model": "string or null", "version": "string or null", "uptime": "string or null", "serial_number": "string or null" }` |
> | config_change | `{ "config_changed": true, "diff_summary": "string", "affected_targets": ["string"], "next_actions": ["string"] }` |
> | raw_text | `{ "text": "string" }` |
>
> **约束：**
>
> - `parse_status=failed` 时，`data` 应返回空对象 `{}`，并在 `warnings` 中给出失败原因。
> - 无法稳定归类到已知类型时，必须回退到 `command_type=raw_text`，不得返回无类型裸对象。
> - 上层（意图引擎、前端、审计）只依赖统一包络字段，不直接假设某厂商私有字段存在。

---

### 3.4 知识检索引擎

#### KR1. search

检索知识库。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| query | string | 检索查询 |
| vendor | string | 按厂商过滤 |
| source_type | string | 按来源过滤（vendor_doc / sop / command_ref） |
| top_k | int | 返回数量，默认 5 |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| results[].content | string | 检索到的文本片段 |
| results[].source | string | 来源标识 |
| results[].source_type | string | 来源类型 |
| results[].vendor | string | 厂商 |
| results[].relevance_score | float | 相关度分数 |

#### KR2. get_device_context

获取设备相关的上下文知识。

**入参：** `vendor, device_type, os_version, intent_type, target_type`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| command_references[].command_pattern | string | 命令模式（如 `display interface *`） |
| command_references[].description | string | 命令说明 |
| command_references[].syntax | string | 完整语法格式 |
| command_references[].usage_notes | string[] | 使用注意事项 |
| capability_constraints | string[] | 该设备/版本的能力限制 |
| common_patterns | string[] | 常见操作模式 |

---

### 3.5 审计服务

#### AU1. log_event

记录审计事件。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| task_id | string | 任务 ID（可空） |
| user_id | string | 用户 ID |
| conversation_id | string | 会话 ID（可空） |
| event_type | string | 事件类型 |
| event_data | object | 事件详情 |
| timestamp | string | 事件时间（可空，默认当前时间） |

**审计事件类型：**

| 事件类型 | 说明 |
|----------|------|
| message_received | 收到用户消息 |
| run_started | 开始 agentic 调用 |
| intent_parsed | 意图解析完成 |
| tool_call_assembled | 后端完成 tool_call 组装校验（内部事件） |
| commands_generated | 候选命令生成（内部审计事件，不作为 SSE 对外推送） |
| commands_validated | 命令校验结果 |
| approval_required | 候选命令已冻结，等待用户授权 |
| user_confirmed | 用户确认执行 |
| user_rejected | 用户拒绝 |
| user_edited_commands | 用户编辑命令 |
| execution_started | 开始执行 |
| command_executed | 单条命令执行完成 |
| execution_completed | 执行完成 |
| execution_failed | 执行失败 |
| llm_call | 大模型调用记录 |
| knowledge_retrieved | 知识检索记录 |

**返回：** `audit_id, timestamp`

#### AU2. get_task_audit_trail

获取任务的完整审计链路。

**入参：** `task_id: string`

**返回：** `task_id, events[](audit_id, event_type, event_data, timestamp)`

#### AU3. query_logs

查询审计日志。

**入参：** `user_id, task_id, event_type, start_time, end_time, page, page_size`

**返回：** `items[], total`

---

### 3.6 厂商适配层

厂商适配层作为意图与执行引擎的内部子模块，通过函数调用而非网络 API 交互。

#### VA1. get_system_prompt

获取厂商特定的生成 prompt + few-shot 示例。

**入参：** `vendor, device_type, operation_type, target_type`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| system_prompt | string | 厂商特定的系统提示词 |
| examples[].intent | string | 示例意图描述 |
| examples[].commands | string[] | 对应的命令列表 |

#### VA2. get_command_templates

获取操作类型的命令模板。

**入参：** `vendor, operation_type, target_type`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| templates[].name | string | 模板名称 |
| templates[].commands | string[] | 模板命令列表 |
| templates[].description | string | 模板说明 |
| templates[].parameters | object | 模板参数定义（JSON Schema） |

#### VA3. validate_command_syntax

厂商特定语法校验。

**入参：** `vendor, commands[], device_type`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| valid | bool | 是否通过校验 |
| issues[].command | string | 有问题的命令 |
| issues[].issue | string | 问题描述 |
| issues[].suggestion | string or null | 修改建议 |

#### VA4. parse_output

解析设备回显为结构化数据。

**入参：** `vendor, command, raw_output`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| parsed_output | object | 对齐 DM7 `outputs[].parsed_output` 的统一 Schema |

> VA4 必须返回与 DM7 相同的 `parsed_output` 包络结构，不再返回未包装的厂商私有对象。若解析失败，返回 `parse_status=failed` 的统一对象，而不是 `null`。

#### VA5. get_supported_operations

获取该厂商支持的操作列表。

**入参：** `vendor, device_type`

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| operations[].operation_type | string | 操作类型（query / inspect / change / rollback） |
| operations[].target_types | string[] | 适用的目标类型列表 |
| operations[].description | string | 操作说明 |

### 3.7 函数调用与工具层

函数调用与工具层向主模型暴露结构化工具能力，主模型通过 function calling 方式调用。

#### 3.7.1 工具定义模型（skills + MCP）

阶段一开始，逻辑工具定义由以下三层组合而成：

1. **Skill**：说明书层，负责描述工具用途、调用时机、提示约束、输入输出契约引用。
2. **MCP**：连接与执行封装层，负责管理连接、屏蔽底层传输差异、执行具体工具能力。
3. **Tool Definition**：面向模型暴露的逻辑工具，引用一个 skill，并可选绑定一个 MCP capability。

约束：

- Skill 可单独存在（如 `parse_intent`、`generate_commands`），此时 `mcp_id=null`
- 需要连接或执行后端能力的逻辑工具，必须显式绑定 `mcp_id + mcp_capability`
- MCP 负责封装连接与执行，不直接替代 skill 的说明书职责
- `execute_command` 默认属于 `approval_gated` 或 `backend_only`，不可绕过 `llm/intent_engine` 的 proposal 校验门控与 DM7 的权威执行契约

#### 3.7.2 MCP 最小能力契约

##### MCP-C1. list_connections

列出当前作用域下可用连接/机器摘要。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| scope | string | 否 | 查询范围：`user / workspace / global`，默认 `user` |
| connection_type | string | 否 | 过滤类型：`device / simulator / controller / host` |
| status | string | 否 | 过滤状态 |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| items[].connection_id | string | 连接稳定标识 |
| items[].machine_id | string or null | 机器稳定标识 |
| items[].name | string | 连接显示名 |
| items[].connection_type | string | `device / simulator / controller / host` |
| items[].endpoint | string | 主机/IP/端点摘要 |
| items[].vendor | string or null | 厂商标识（如适用） |
| items[].protocol | string or null | `ssh / telnet / netconf / http ...` |
| items[].status | string | 当前状态摘要 |
| items[].capabilities | string[] | 当前连接支持的能力 |

##### MCP-C2. execute_command

在指定机器/连接上执行命令并返回标准结果。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| connection_id | string | 是 | 目标连接 ID |
| machine_id | string or null | 否 | 目标机器 ID；与 connection_id 二选一或同时提供以便校验 |
| commands[].command | string | 是 | 要执行的命令 |
| commands[].timeout | int | 否 | 单条命令超时（秒） |
| commands[].expect_pattern | string | 否 | 期望提示符/回显模式 |
| execution_mode | string | 否 | `read_only / config / diagnostic` |
| stop_on_error | bool | 否 | 遇错停止，默认 true |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| connection_id | string | 实际执行所用连接 ID |
| machine_id | string or null | 实际执行所用机器 ID |
| status | string | `success / partial / failed` |
| outputs[].command | string | 执行命令 |
| outputs[].stdout | string | 标准输出/主要回显 |
| outputs[].stderr | string or null | 错误输出 |
| outputs[].exit_code | int | 退出码 |
| outputs[].duration_ms | int | 耗时 |
| error | string or null | 错误信息 |

> 对网络设备场景，`execute_command` 默认由统一设备管理程序 DM7 作为后端执行实现；MCP 负责对连接发现、调用路由与结果包络进行统一封装。任何实际执行前，MCP 或其上层执行封装都必须先消费 `llm/intent_engine` 已冻结且已确认的 proposal，不得直接消费模型原始 tool_call 或前端自由文本。

#### 3.7.3 阶段一逻辑工具清单

| 工具 | skill_id | mcp 绑定 | 暴露策略 | 说明 |
|------|----------|----------|----------|------|
| TL1 `parse_intent` | `skill.intent.parse` | 无 | `model_direct` | 纯说明书驱动的结构化意图解析 |
| TL2 `search_knowledge` | `skill.knowledge.search` | 无 | `model_direct` | 检索知识库，不依赖连接执行 |
| TL3 `query_device_status` | `skill.device.query_status` | `mcp.device.default:execute_command` | `model_direct` | 通过受控执行能力查询设备状态 |
| TL4 `list_devices` | `skill.connection.list_devices` | `mcp.device.default:list_connections` | `model_direct` | 通过 MCP 返回可用连接/设备摘要 |
| TL5 `generate_commands` | `skill.commands.generate` | 无 | `model_direct` | 输出候选命令，不具备执行权 |

阶段一工具清单：

#### TL1. parse_intent

将用户自然语言请求解析为结构化网络运维意图。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| user_request | string | 是 | 用户的自然语言请求原文 |
| target_devices | string[] | 否 | 用户明确指定的设备 ID 列表 |
| operation_hint | string | 否 | 操作类型提示（query / inspect / change / rollback） |

**返回：** 同 IE1 的 intent 结构（见 3.2 IE1）。

#### TL2. search_knowledge

检索厂商文档与命令知识库。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| query | string | 是 | 检索查询内容 |
| vendor | string | 否 | 按厂商过滤（huawei / h3c） |
| top_k | int | 否 | 返回数量，默认 5 |

**返回：** 同 KR1 的 results 结构（见 3.4 KR1）。

#### TL3. query_device_status

查询设备当前状态。

> 实现约束：TL3 是逻辑工具；默认由 `skill.device.query_status + mcp.device.default:execute_command` 组合实现。其执行模式仅限受控只读查询，不授予候选命令阶段的配置写入能力。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| device_id | string | 是 | 目标设备 ID |
| query_type | string | 是 | 查询类型：interface_summary / route_table / arp_table / system_info |

**返回：**

| 字段 | 类型 | 说明 |
|------|------|------|
| device_id | string | 设备 ID |
| query_type | string | 查询类型 |
| data | object | 查询结果（结构因 query_type 而异） |
| collected_at | string | 采集时间 |

> **data 结构说明**：data 为开放对象，其内部结构由 query_type 决定：
>
> | query_type | data 结构示例 | 说明 |
> |------------|--------------|------|
> | interface_summary | `{ "interfaces": [{ "name": "GE1/0/1", "status": "up", "speed": "1000M" }] }` | 接口状态汇总 |
> | route_table | `{ "routes": [{ "destination": "10.0.0.0/24", "next_hop": "192.168.1.1", "protocol": "OSPF" }] }` | 路由表信息 |
> | arp_table | `{ "entries": [{ "ip": "10.0.0.1", "mac": "00:11:22:33:44:55", "interface": "GE1/0/1" }] }` | ARP 表信息 |
> | system_info | `{ "hostname": "CoreSwitch01", "uptime": "30d 12h", "version": "VRP V200R019" }` | 设备系统信息 |

#### TL4. list_devices

列出可用设备。

> 实现约束：TL4 是逻辑工具；默认由 `skill.connection.list_devices + mcp.device.default:list_connections` 组合实现。返回结果可来自设备管理程序、模拟器连接或后续控制器连接摘要，但对模型暴露为统一设备/连接列表。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| vendor | string | 否 | 按厂商过滤 |
| status | string | 否 | 按状态过滤 |

**返回：** 设备摘要列表（id, name, host, vendor, status）。

> 阶段一工具清单包含以上 4 个及 TL5，共 5 个工具。后续阶段按需扩展。

#### TL5. generate_commands

模型调用此工具提交候选命令列表，供前端授权确认。

> 实现约束：TL5 仅绑定 `skill.commands.generate`，不绑定任何执行型 MCP；该工具始终只负责提交候选命令，不具备执行权。其输出必须交由 `llm/intent_engine` 的 IE3 进行组装、冻结与校验后，才能生成授权卡片或进入执行层。

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| candidate_commands | object[] | 是 | 候选命令列表，结构对齐 IE2 的 candidate_commands |
| generation_source | string | 是 | 生成来源：knowledge_grounded_model / template_fallback |
| confidence | float | 是 | 整体置信度 (0.0-1.0) |
| validation_notes | string[] | 否 | 校验备注 |

**降级模式参数约束：**

当 `generation_source=template_fallback` 时，以下额外约束生效（对齐 TOOLS_SPEC.md §3.7 降级路径）：

- `candidate_commands[].generation_basis` 必须指向模板来源，不得伪装为知识条目引用
- `validation_notes` 必填，必须包含降级原因（如"知识检索为空，已回退到冻结模板"）
- 若既无可用知识引用也无允许使用的冻结模板，应返回空 `candidate_commands` 并在 `validation_notes` 中说明原因

**返回：** `llm/intent_engine` 完成组装校验后推送 `approval_required` SSE 事件。

### 3.8 SDN 控制器接入与拓扑服务（Phase 3 预留）

以下内部接口仅在 Phase 2 已完成站点模型、接口对象独立存储、拓扑关系读取后才实现。

说明：本节描述的是**进程内模块级接口契约**；前端 API 的请求/响应 JSON Schema 以 §8.3 为准。

#### SDN1. register_controller

注册控制器连接并验证基础连通性。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| user_id | string | 用户 ID |
| name | string | 控制器名称 |
| controller_type | string | openapi / netconf / restconf / gnmi / vendor_native |
| endpoint | string | 控制器或接口地址 |
| auth_type | string | basic / token / certificate / oauth2 |
| auth_payload | object | 认证载荷（仅在内存中处理，落库前加密） |
| description | string or null | 描述信息 |

**返回：** `controller`（见 §8.3.1 共享对象定义）

#### SDN2. list_controllers

获取已纳管控制器列表。

**入参：** `user_id, status?, controller_type?`

**返回：** `items[]`（controller_summary）

#### SDN3. get_capabilities

获取控制器支持的能力、认证约束与目标范围限制。

**入参：** `user_id, controller_id`

**返回：** `capability_summary`

#### SDN4. sync_topology

触发拓扑同步并生成最新快照。

**入参：** `user_id, controller_id, force_full_sync=false`

**返回：** `snapshot_id, sync_status, summary`

#### SDN5. get_topology_graph

获取统一拓扑图，用于前端渲染与影响分析。

**入参：** `user_id, site_ids?, controller_ids?, include_offline=false`

**返回：** `topology_graph`（见 §8.3.1）

#### SDN6. generate_controller_plan

为任务生成控制器/API 级候选操作计划。

**入参：** `task_id, user_id, target_controller_ids?, execution_mode=planned`

**返回：** `controller_operation_plan`

#### SDN7. analyze_topology_impact

分析任务或操作计划的影响范围。

**入参：** `task_id or plan_id, user_id`

**返回：** `impact_summary`

#### SDN8. execute_controller_plan

执行已通过权限与审批检查的控制器/API 级计划。

**入参：** `plan_id, user_id, approval_id?`

**返回：** `execution_ticket_id, status`

### 3.8 SDN 控制器接入与拓扑服务（Phase 3 预留）

以下内部接口仅在 Phase 2 已完成站点模型、接口对象独立存储、拓扑关系读取后才实现。

说明：本节描述的是**进程内模块级接口契约**；前端 API 的请求/响应 JSON Schema 以 §8.3 为准。

#### SDN1. register_controller

注册控制器连接并验证基础连通性。

**入参：**

| 字段 | 类型 | 说明 |
|------|------|------|
| user_id | string | 用户 ID |
| name | string | 控制器名称 |
| controller_type | string | openapi / netconf / restconf / gnmi / vendor_native |
| endpoint | string | 控制器或接口地址 |
| auth_type | string | basic / token / certificate / oauth2 |
| auth_payload | object | 认证载荷（仅在内存中处理，落库前加密） |
| description | string or null | 描述信息 |

**返回：** `controller`（见 §8.3.1 共享对象定义）

#### SDN2. list_controllers

获取已纳管控制器列表。

**入参：** `user_id, status?, controller_type?`

**返回：** `items[]`（controller_summary）

#### SDN3. get_capabilities

获取控制器支持的能力、认证约束与目标范围限制。

**入参：** `user_id, controller_id`

**返回：** `capability_summary`

#### SDN4. sync_topology

触发拓扑同步并生成最新快照。

**入参：** `user_id, controller_id, force_full_sync=false`

**返回：** `snapshot_id, sync_status, summary`

#### SDN5. get_topology_graph

获取统一拓扑图，用于前端渲染与影响分析。

**入参：** `user_id, site_ids?, controller_ids?, include_offline=false`

**返回：** `topology_graph`（见 §8.3.1）

#### SDN6. generate_controller_plan

为任务生成控制器/API 级候选操作计划。

**入参：** `task_id, user_id, target_controller_ids?, execution_mode=planned`

**返回：** `controller_operation_plan`

#### SDN7. analyze_topology_impact

分析任务或操作计划的影响范围。

**入参：** `task_id or plan_id, user_id`

**返回：** `impact_summary`

#### SDN8. execute_controller_plan

执行已通过权限与审批检查的控制器/API 级计划。

**入参：** `plan_id, user_id, approval_id?`

**返回：** `execution_ticket_id, status`

---

## 4. SSE 事件类型

### 4.1 对话流式输出

#### stream_text

主模型的流式文本回复片段。

```json
{
  "conversation_id": "uuid",
  "message_id": "uuid",
  "content": "文本片段",
  "done": false
}
```

#### stream_text_end

流式文本回复结束。

```json
{
  "conversation_id": "uuid",
  "message_id": "uuid"
}
```

#### stream_reasoning

主模型的流式思考内容片段。仅当上游 OpenAI 兼容模型实际返回 reasoning / thinking 内容时发送；前端默认折叠展示。

```json
{
  "conversation_id": "uuid",
  "message_id": "uuid",
  "content": "思考片段",
  "done": false,
  "collapsed_by_default": true
}
```

> 若上游仅提供非流式完整思考内容，后端可发送单个 `stream_reasoning` 事件承载完整内容，然后立即发送 `stream_reasoning_end`。

#### stream_reasoning_end

流式思考内容结束。

```json
{
  "conversation_id": "uuid",
  "message_id": "uuid"
}
```

### 4.2 任务状态流转

#### run_started

系统识别到需要设备操作，开始 agentic 调用。

```json
{
  "task_id": "uuid",
  "conversation_id": "uuid",
  "intent_preview": "查看 CoreSwitch01 的接口状态"
}
```

#### intent_parsed

意图解析完成，并已由 `llm/intent_engine` 标准化；前端展示意图卡片。

```json
{
  "task_id": "uuid",
  "intent": {
    "operation_type": "query",
    "target_type": "interface",
    "target_devices": [
      {
        "device_id": "uuid",
        "device_name": "CoreSwitch01",
        "vendor": "huawei"
      }
    ],
    "scope": "single",
    "description": "查看接口状态",
    "risk_level": "low",
    "constraints": [],
    "pre_checks": ["检查设备连通性", "确认接口存在"],
    "expected_result": "接口状态信息列表",
    "rollback_plan": null
  }
}
```

#### approval_required

`llm/intent_engine` 已完成候选命令 proposal 的组装、校验与冻结，等待用户授权。

```json
{
  "task_id": "uuid",
  "proposal_id": "uuid",
  "tool_call_id": "call_abc",
  "candidate_commands": [
    {
      "device_id": "uuid",
      "device_name": "CoreSwitch01",
      "commands": [
        {
          "command": "display interface brief",
          "description": "查看接口简要信息",
          "risk_level": "low",
          "is_config": false,
          "generation_basis": {
            "source_type": "knowledge_entry",
            "source_id": "huawei_vrp_interface_display_001",
            "source_title": "华为 VRP 接口查询命令",
            "snippet": "display interface brief"
          },
          "applicability": "适用于 VRP V200R019 及以上版本",
          "expect_pattern": "接口名\\s+状态",
          "confidence": 0.95
        }
      ],
      "generation_source": "knowledge_grounded_model",
      "confidence": 0.92,
      "validation_notes": []
    }
  ]
}
```

当存在多个 `generate_commands` tool_call 时，每个有效的 tool_call 会分别触发一个 `approval_required` 事件，前端分别展示授权卡片。

### 4.3 执行阶段

#### execution_started

用户已确认，开始执行。

```json
{
  "task_id": "uuid"
}
```

#### device_executing

正在某个设备上执行。

```json
{
  "task_id": "uuid",
  "device_id": "uuid",
  "device_name": "CoreSwitch01",
  "current_command": "display interface brief",
  "progress": {
    "total_devices": 2,
    "completed_devices": 0
  }
}
```

#### command_executed

单条命令执行完成。

```json
{
  "task_id": "uuid",
  "device_id": "uuid",
  "device_name": "CoreSwitch01",
  "command": "display interface brief",
  "output": "设备回显...",
  "success": true
}
```

#### execution_completed

所有命令执行完成。

```json
{
  "task_id": "uuid",
  "execution_results": [
    {
      "device_id": "uuid",
      "device_name": "CoreSwitch01",
      "status": "success",
      "outputs": [
        {
          "command": "display interface brief",
          "output": "GigabitEthernet0/0/1   up   up ...",
          "exit_code": 0
        }
      ],
      "error": null
    }
  ],
  "summary": {
    "total_devices": 2,
    "success_devices": 2,
    "failed_devices": 0
  },
  "result_summary": {
    "source": "model",
    "status": "ready",
    "content": "CoreSwitch01 接口状态已完成汇总：22 个接口 up，2 个 down，未发现执行失败。",
    "generated_at": "2026-01-01T00:00:05Z"
  }
}
```

> `result_summary` 为执行完成后由后端基于 `execution_results` 触发模型生成的用户可读总结。`execution_completed` 事件推送时应一并携带该字段，确保前端无需额外等待第二条业务事件即可展示结果卡片与总结文本。

#### execution_failed

执行失败。

```json
{
  "task_id": "uuid",
  "error": "连接超时",
  "partial_results": [
    {
      "device_id": "uuid",
      "device_name": "CoreSwitch01",
      "status": "success",
      "outputs": [
        {
          "command": "display interface brief",
          "output": "设备回显...",
          "exit_code": 0
        }
      ],
      "error": null
    }
  ]
}
```

#### task_rejected

用户拒绝了候选命令。

```json
{
  "task_id": "uuid",
  "reason": null
}
```

### 4.4 连接状态

#### sse_connected

SSE 连接建立成功。

```json
{
  "user_id": "uuid",
  "connection_id": "uuid"
}
```

#### sse_heartbeat

心跳。

```json
{
  "timestamp": "2026-01-01T00:00:00Z"
}
```

#### error

错误事件。

```json
{
  "code": "string",
  "message": "string",
  "task_id": "uuid or null"
}
```

### 4.5 事件时序

```
用户发送消息 (POST /messages)
  │
  ├─→ stream_text              模型流式回复正文
  ├─→ stream_reasoning         模型思考内容（如有，默认折叠）
  ├─→ stream_text_end
  ├─→ stream_reasoning_end
  │
  ├─→ run_started               开始 agentic 调用
  ├─→ intent_parsed             意图解析完成，前端展示意图卡片
  ├─→ approval_required         候选命令已冻结，前端展示授权卡片
  │
  │   用户点击确认
  │
  ├─→ execution_started
  ├─→ device_executing          逐设备执行
  │   ├─→ command_executed      逐命令完成
  │   └─→ ...
  ├─→ execution_completed       全部完成
  │   或
  └─→ execution_failed          失败
```

### 4.6 对外状态机与内部子阶段边界

阶段一对外任务状态机仅允许使用以下冻结状态：

```text
running → pending_approval → executing → completed
                        → rejected
             executing → failed
```

约束：

- `tasks.status`、SSE 任务主状态、以及前端任务状态展示，只能使用上述冻结状态枚举。
- `intent_parsing` 和 `commands_generating` 作为 `running` 状态的内部子阶段，不再作为对外状态暴露。
- 如实现中存在"目标识别中""知识检索中""模板降级中"等内部步骤，必须作为**内部子阶段（substage）**、调试日志或审计事件处理，不得直接写入 `tasks.status`。
- 新增内部子阶段时，不得要求前端、数据库或外部 API 同步扩展任务主状态机。
- 如果后续阶段需要暴露更细粒度阶段，必须通过新增显式字段（如 `substage`）或新增事件对象完成，而不是复用 `status` 字段。

---

## 5. 数据模型

### 5.1 核心表结构

#### users（用户表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| username | TEXT | UNIQUE NOT NULL | 用户名 |
| password_hash | TEXT | NOT NULL | bcrypt 哈希 |
| created_at | TEXT (ISO 8601) | | 创建时间 |
| updated_at | TEXT (ISO 8601) | | 更新时间 |

#### devices（设备表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| user_id | TEXT (UUID) | FK → users.id | 所属用户（数据隔离） |
| name | TEXT | NOT NULL | 设备名称/别名 |
| host | TEXT | NOT NULL | IP 或主机名 |
| port | INTEGER | NOT NULL DEFAULT 22 | 端口 |
| protocol | TEXT | NOT NULL | ssh / telnet |
| vendor | TEXT | NOT NULL | huawei / h3c |
| device_type | TEXT | NOT NULL | netmiko device_type |
| model | TEXT | | 设备型号（可自动发现） |
| os_version | TEXT | | 系统版本（可自动发现） |
| username_encrypted | BLOB | NOT NULL | 加密存储的登录用户名 |
| password_encrypted | BLOB | NOT NULL | 加密存储的登录密码 |
| description | TEXT | | 设备描述 |
| last_connected_at | TEXT (ISO 8601) | | 最后连接时间 |
| created_at | TEXT (ISO 8601) | | 创建时间 |
| updated_at | TEXT (ISO 8601) | | 更新时间 |

> 唯一约束：(user_id, host, port)

#### conversations（会话表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| user_id | TEXT (UUID) | FK → users.id | 所属用户 |
| title | TEXT | | 会话标题 |
| created_at | TEXT (ISO 8601) | | 创建时间 |
| updated_at | TEXT (ISO 8601) | | 更新时间（每次新消息更新） |
| deleted_at | TEXT (ISO 8601) | | 软删除时间 |

#### messages（消息表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| conversation_id | TEXT (UUID) | FK → conversations.id | 所属会话 |
| role | TEXT | NOT NULL | user / assistant / system（system 仅内部使用，不对前端暴露） |
| content | TEXT | NOT NULL | 消息内容 |
| reasoning_content | TEXT | | assistant 消息的思考内容；无则为空 |
| content_type | TEXT | NOT NULL | text / intent_card / command_card / result_card |
| metadata | TEXT (JSON) | | 结构化卡片数据（JSON 字符串） |
| created_at | TEXT (ISO 8601) | | 创建时间 |

> 索引：(conversation_id, created_at)

#### tasks（任务表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| user_id | TEXT (UUID) | FK → users.id | 所属用户 |
| conversation_id | TEXT (UUID) | FK → conversations.id | 所属会话 |
| message_id | TEXT (UUID) | FK → messages.id | 触发该任务的用户消息 |
| status | TEXT | NOT NULL | 任务状态（见状态机） |
| intent | TEXT (JSON) | | 结构化意图 |
| candidate_commands | TEXT (JSON) | | 候选命令列表 |
| confirmed_commands | TEXT (JSON) | | 用户确认/编辑后的命令 |
| execution_results | TEXT (JSON) | | 执行结果 |
| risk_level | TEXT | | low / medium / high |
| error_message | TEXT | | 错误信息 |
| created_at | TEXT (ISO 8601) | | 创建时间 |
| updated_at | TEXT (ISO 8601) | | 更新时间 |

> 索引：(user_id, status, created_at)

**任务状态机：**

```
running → pending_approval → executing → completed
                        → rejected
             executing → failed
```

> `intent_parsing` 和 `commands_generating` 作为 `running` 状态的内部子阶段，不再作为对外状态暴露。
> `confirmed_commands` 来源于 `proposal_id` 对应的已授权候选命令。

> 阶段一不提供主动取消任务的接口。若需取消能力，在后续阶段通过新增 POST /api/v1/tasks/{task_id}/cancel 接口实现。

#### audit_logs（审计日志表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| task_id | TEXT (UUID) | FK → tasks.id | 关联任务（可空） |
| user_id | TEXT (UUID) | FK → users.id | 操作用户 |
| conversation_id | TEXT (UUID) | | 关联会话（可空） |
| event_type | TEXT | NOT NULL | 事件类型 |
| event_data | TEXT (JSON) | NOT NULL | 事件详情 |
| timestamp | TEXT (ISO 8601) | NOT NULL DEFAULT current | 事件时间 |

> 索引：(task_id, timestamp)、(user_id, timestamp)、(event_type)
> 此表只 INSERT，不 UPDATE / DELETE。

#### user_model_configs（用户模型配置表）

每用户可保存多套模型配置，同时只有一套处于激活状态。

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT (UUID) | PK | 主键 |
| user_id | TEXT (UUID) | FK → users.id | 所属用户 |
| name | TEXT | NOT NULL | 配置名称，同一用户下唯一 |
| is_active | INTEGER | NOT NULL DEFAULT 0 | 是否为当前激活配置（0=否，1=是） |
| main_model | TEXT | | 主模型标识 |
| main_model_base_url | TEXT | | 主模型自定义端点 |
| main_model_api_key_encrypted | BLOB | | 主模型 API Key（加密） |
| created_at | TEXT (ISO 8601) | | 创建时间 |
| updated_at | TEXT (ISO 8601) | | 更新时间 |

> 联合唯一约束：(user_id, name)。同一用户下至多一行 is_active = 1，由后端切换逻辑保证。

### 5.2 表关系

```
users 1──N devices
users 1──N conversations
users 1──N tasks
users 1──N user_model_configs

conversations 1──N messages
conversations 1──N tasks

tasks 1──N audit_logs
users 1──N audit_logs
```

### 5.3 阶段一清单/拓扑接口边界

ROADMAP.md 功能开发跟踪表要求"定义设备、接口、站点、协议对象模型"。阶段一采取以下策略：

- **设备（devices 表）**：已完整定义，支持 CRUD
- **接口对象**：阶段一不单独建表，作为设备执行结果中的嵌套数据返回（如 `display interface brief` 的解析结果）
- **站点/拓扑关系**：阶段一不建表、不提供 API，设备无分组和拓扑关联
- **协议对象**：作为 devices 表的 protocol 字段管理，不单独建模

阶段二再补充：设备分组、站点模型、拓扑关系读取、接口对象独立存储。

### 5.4 Phase 3 SDN 数据对象预留

以下对象不属于阶段一实现，仅作为 Phase 3 的接口与数据结构规划，且依赖 Phase 2 已完成站点、接口、链路等拓扑基础建模。

| 对象 | 用途 | 关键字段 |
|------|------|----------|
| controller | 描述已纳管的 SDN 控制器或结构化网络接口入口 | `id`, `name`, `controller_type`, `endpoint`, `auth_type`, `capability_summary`, `status`, `last_synced_at` |
| controller_domain | 描述控制器下的逻辑管理域/租户/fabric 范围 | `id`, `controller_id`, `name`, `domain_type`, `scope_summary`, `metadata` |
| topology_snapshot | 描述从控制器或拓扑服务同步得到的拓扑快照 | `id`, `controller_id`, `snapshot_type`, `collected_at`, `summary`, `snapshot_data` |
| controller_operation_plan | 描述由意图引擎生成的控制器/API 级候选操作计划 | `id`, `task_id`, `controller_id`, `operation_type`, `targets`, `plan_payload`, `impact_summary`, `approval_status` |

说明：

- `controller_operation_plan` 与 Phase 3 的审批、权限、审计对象绑定。
- 设备、接口、站点、链路等基础对象仍以 Phase 2 的数据模型为准，本节只补充 SDN 场景新增的逻辑对象。

---

## 6. 安全要求

| 项 | 措施 |
|---|------|
| 设备凭据 | 传入明文，后端用对称加密（如 Fernet）加密后存入 BLOB 字段，解密仅在设备管理程序内部进行 |
| API Key | 模型 API Key 同样加密存储，返回前端时只返回 `api_key_set: bool` |
| 用户隔离 | 所有查询强制带 `WHERE user_id = ?`，不信任前端传参 |
| 密码存储 | 用户密码 bcrypt hash，不存明文 |
| SSE 认证 | 建立 SSE 连接时校验 token，断开重连需重新校验 |

---

## 7. 阶段一边界说明

| 项 | 阶段一策略 |
|---|---|
| 权限 | 不做 RBAC，所有登录用户权限相同，仅做用户级数据隔离 |
| 校验 | 候选命令必须经用户确认，`requires_confirmation` 始终为 `true` |
| 回滚 | 无自动回滚，失败仅记录 |
| 设备发现 | 设备由用户手动添加，不做自动发现 |
| 设备监控 | 不做实时监控，设备状态仅在 test-connection 和执行时获取 |
| 并发 | 单设备串行执行命令，多设备可并行 |
| 超时 | 单命令 30s，单任务 5min（可配置） |
| SSE 重连 | 支持 `Last-Event-ID` 恢复 |

---

## 8. 后续阶段预留接口

以下接口在当前阶段一不实现，作为后续阶段的接口规划参考。

### 8.1 Phase 2：模拟器内受控执行

| 方法 | 路径 / 接口名 | 用途 | 所属层级 |
|------|---------------|------|----------|
| POST | `/api/v1/tasks/{id}/config` | 生成 candidate config（候选配置） | 前端 API |
| GET | `/api/v1/tasks/{id}/diff` | 获取候选配置与当前配置的 diff | 前端 API |
| POST | `/api/v1/tasks/{id}/simulate` | 在模拟器中验证候选命令 | 前端 API |
| POST | `/api/v1/tasks/{id}/post-check` | 执行后检查（post-check） | 前端 API |
| POST | `/api/v1/tasks/{id}/rollback` | 执行回滚操作 | 前端 API |
| GET | `/api/v1/tasks/{id}/simulation-report` | 获取模拟验证报告 | 前端 API |
| - | `llm.intent_engine.generate_candidate_config` | 生成候选配置 | 内部 API |
| - | `llm.intent_engine.run_simulation` | 模拟器内验证执行 | 内部 API |
| - | `llm.intent_engine.post_check` | 执行后状态比对 | 内部 API |
| - | `llm.intent_engine.rollback` | 回滚到执行前状态 | 内部 API |
| - | `device_manager.capture_config_snapshot` | 捕获设备配置快照 | 内部 API |
| - | `simulator_service.setup_environment` | 搭建模拟器测试拓扑 | 内部 API |

### 8.2 Phase 3：策略与安全增强

| 方法 | 路径 / 接口名 | 用途 | 所属层级 |
|------|---------------|------|----------|
| GET | `/api/v1/roles` | 获取角色列表 | 前端 API |
| POST | `/api/v1/roles` | 创建角色 | 前端 API |
| PUT | `/api/v1/roles/{id}` | 更新角色权限 | 前端 API |
| GET | `/api/v1/users/{id}/permissions` | 获取用户权限 | 前端 API |
| POST | `/api/v1/approvals` | 创建审批单 | 前端 API |
| GET | `/api/v1/approvals/{id}` | 获取审批单详情 | 前端 API |
| POST | `/api/v1/approvals/{id}/approve` | 审批通过 | 前端 API |
| POST | `/api/v1/approvals/{id}/reject` | 审批驳回 | 前端 API |
| GET | `/api/v1/policies/change-windows` | 获取变更窗口策略 | 前端 API |
| PUT | `/api/v1/policies/change-windows` | 设置变更窗口策略 | 前端 API |
| GET | `/api/v1/policies/tool-whitelist` | 获取工具白名单 | 前端 API |
| PUT | `/api/v1/policies/tool-whitelist` | 设置工具白名单 | 前端 API |
| - | `policy_service.check_permission` | 权限校验 | 内部 API |
| - | `policy_service.check_change_window` | 变更窗口校验 | 内部 API |
| - | `policy_service.check_tool_whitelist` | 工具白名单校验 | 内部 API |
| - | `policy_service.check_scope_boundary` | 目标范围与拓扑影响范围校验 | 内部 API |
| - | `approval_service.create_approval` | 创建审批流程 | 内部 API |
| - | `approval_service.process_approval` | 处理审批动作 | 内部 API |

### 8.3 Phase 3：SDN 能力（依赖 Phase 2 拓扑基础）

以下接口仅在 Phase 2 已完成设备分组、站点模型、拓扑关系读取、接口对象独立存储后才可实现。

| 方法 | 路径 / 接口名 | 用途 | 所属层级 |
|------|---------------|------|----------|
| GET | `/api/v1/topology` | 获取统一拓扑视图（站点、设备、接口、链路、控制域） | 前端 API |
| GET | `/api/v1/controllers` | 获取已纳管控制器列表 | 前端 API |
| POST | `/api/v1/controllers` | 注册控制器连接与认证信息 | 前端 API |
| GET | `/api/v1/controllers/{id}` | 获取控制器详情、能力摘要、最近同步状态 | 前端 API |
| GET | `/api/v1/controllers/{id}/capabilities` | 获取控制器支持的能力与限制 | 前端 API |
| POST | `/api/v1/tasks/{id}/controller-plan` | 为任务生成控制器/API 级候选操作计划 | 前端 API |
| GET | `/api/v1/tasks/{id}/impact` | 获取任务的拓扑影响范围与目标对象摘要 | 前端 API |
| POST | `/api/v1/tasks/{id}/controller-execute` | 在审批通过后执行控制器/API 级计划 | 前端 API |
| - | `sdn_controller_service.register_controller` | 注册控制器并做连通性/能力发现 | 内部 API |
| - | `sdn_controller_service.list_controllers` | 查询控制器列表与状态摘要 | 内部 API |
| - | `sdn_controller_service.sync_topology` | 触发拓扑同步并生成最新快照 | 内部 API |
| - | `sdn_controller_service.get_topology_graph` | 获取统一拓扑图 | 内部 API |
| - | `sdn_controller_service.get_capabilities` | 获取控制器能力、限制与认证方式 | 内部 API |
| - | `llm.intent_engine.generate_controller_plan` | 生成控制器/API 级候选操作计划 | 内部 API |
| - | `llm.intent_engine.analyze_topology_impact` | 分析任务对拓扑和目标范围的影响 | 内部 API |
| - | `llm.intent_engine.execute_controller_plan` | 执行已通过门控的控制器/API 级计划 | 内部 API |

补充说明：

- 控制器/API 级写操作仍受 8.2 中的权限、审批、变更窗口与白名单约束。
- 读取类接口（如拓扑、控制器列表、能力查询）可先于写操作落地。
- 该阶段前端可扩展新的卡片类型，如 `topology_card`、`controller_plan_card`、`approval_card`，但不影响阶段一消息结构定义。

#### 8.3.1 共享对象定义（JSON Schema）

**controller_summary：**

```json
{
  "id": "uuid",
  "name": "Campus-Controller-A",
  "controller_type": "restconf",
  "endpoint": "https://controller.example.com",
  "status": "online",
  "last_synced_at": "2026-04-14T10:00:00Z",
  "capability_summary": {
    "supported_protocols": ["restconf"],
    "supported_operations": ["read_topology", "read_capabilities", "planned_write"],
    "requires_approval_for_write": true
  }
}
```

**topology_node：**

```json
{
  "id": "uuid",
  "node_type": "site",
  "label": "DC-01",
  "status": "online",
  "site_id": "uuid or null",
  "controller_id": "uuid or null",
  "metadata": {}
}
```

`node_type` 允许值：`site / device / interface / controller_domain / external_endpoint`

**topology_edge：**

```json
{
  "id": "uuid",
  "edge_type": "physical_link",
  "source_node_id": "uuid",
  "target_node_id": "uuid",
  "status": "up",
  "metadata": {}
}
```

`edge_type` 允许值：`physical_link / logical_link / ownership / managed_by / path_membership`

**topology_graph：**

```json
{
  "snapshot_id": "uuid",
  "generated_at": "2026-04-14T10:00:00Z",
  "nodes": [],
  "edges": [],
  "view_hints": {
    "default_layout": "force-directed",
    "supports_highlight": true,
    "supports_filter": true
  }
}
```

**controller_operation_plan：**

```json
{
  "id": "uuid",
  "task_id": "uuid",
  "controller_id": "uuid",
  "operation_type": "planned_write",
  "targets": [
    {
      "target_type": "controller_domain",
      "target_id": "uuid",
      "label": "Fabric-A"
    }
  ],
  "impact_summary": {
    "risk_level": "high",
    "affected_sites": ["uuid"],
    "affected_devices": ["uuid"],
    "requires_approval": true
  },
  "approval_status": "pending",
  "plan_payload": {},
  "created_at": "2026-04-14T10:00:00Z"
}
```

#### 8.3.2 GET `/api/v1/controllers`

获取已纳管控制器列表。

**查询参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| status | string | null | online / offline / error |
| controller_type | string | null | 按控制器类型过滤 |
| page | int | 1 | 页码 |
| page_size | int | 20 | 每页数量 |

**响应 200 JSON Schema：**

```json
{
  "items": [
    {
      "id": "uuid",
      "name": "Campus-Controller-A",
      "controller_type": "restconf",
      "endpoint": "https://controller.example.com",
      "status": "online",
      "last_synced_at": "2026-04-14T10:00:00Z",
      "capability_summary": {
        "supported_protocols": ["restconf"],
        "supported_operations": ["read_topology", "planned_write"],
        "requires_approval_for_write": true
      }
    }
  ],
  "total": 1,
  "page": 1,
  "page_size": 20
}
```

#### 8.3.3 POST `/api/v1/controllers`

注册控制器连接与认证信息。

**请求 JSON Schema：**

```json
{
  "name": "Campus-Controller-A",
  "controller_type": "restconf",
  "endpoint": "https://controller.example.com",
  "auth_type": "basic",
  "auth_payload": {
    "username": "admin",
    "password": "string"
  },
  "description": "园区网控制器"
}
```

**响应 201 JSON Schema：**

```json
{
  "id": "uuid",
  "name": "Campus-Controller-A",
  "controller_type": "restconf",
  "endpoint": "https://controller.example.com",
  "status": "online",
  "last_synced_at": null,
  "capability_summary": {
    "supported_protocols": ["restconf"],
    "supported_operations": ["read_topology"],
    "requires_approval_for_write": true
  }
}
```

#### 8.3.4 GET `/api/v1/controllers/{id}`

获取控制器详情、能力摘要、最近同步状态。

**响应 200 JSON Schema：**

```json
{
  "id": "uuid",
  "name": "Campus-Controller-A",
  "controller_type": "restconf",
  "endpoint": "https://controller.example.com",
  "auth_type": "basic",
  "status": "online",
  "last_synced_at": "2026-04-14T10:00:00Z",
  "capability_summary": {
    "supported_protocols": ["restconf"],
    "supported_operations": ["read_topology", "planned_write"],
    "requires_approval_for_write": true
  },
  "domains": [
    {
      "id": "uuid",
      "name": "Fabric-A",
      "domain_type": "fabric",
      "scope_summary": "DC-01 园区域"
    }
  ],
  "description": "园区网控制器",
  "created_at": "2026-04-10T09:00:00Z",
  "updated_at": "2026-04-14T10:00:00Z"
}
```

#### 8.3.5 GET `/api/v1/controllers/{id}/capabilities`

获取控制器支持的能力与限制。

**响应 200 JSON Schema：**

```json
{
  "controller_id": "uuid",
  "supported_protocols": ["restconf"],
  "supported_operations": ["read_topology", "read_capabilities", "planned_write"],
  "write_constraints": ["requires_approval", "change_window_enforced"],
  "target_scope_constraints": ["controller_domain_only"],
  "telemetry_support": false
}
```

#### 8.3.6 GET `/api/v1/topology`

获取统一拓扑视图，供前端拓扑页面渲染。

**查询参数：**

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| site_ids | string[] | null | 按站点过滤 |
| controller_ids | string[] | null | 按控制器过滤 |
| include_offline | bool | false | 是否包含离线对象 |
| snapshot_id | string | null | 指定拓扑快照 |

**响应 200 JSON Schema：**

```json
{
  "snapshot_id": "uuid",
  "generated_at": "2026-04-14T10:00:00Z",
  "nodes": [
    {
      "id": "uuid",
      "node_type": "site",
      "label": "DC-01",
      "status": "online",
      "site_id": "uuid",
      "controller_id": null,
      "metadata": {
        "device_count": 8
      }
    }
  ],
  "edges": [
    {
      "id": "uuid",
      "edge_type": "physical_link",
      "source_node_id": "uuid",
      "target_node_id": "uuid",
      "status": "up",
      "metadata": {
        "bandwidth": "10G"
      }
    }
  ],
  "view_hints": {
    "default_layout": "force-directed",
    "supports_highlight": true,
    "supports_filter": true
  }
}
```

#### 8.3.7 POST `/api/v1/tasks/{id}/controller-plan`

为任务生成控制器/API 级候选操作计划。

**请求 JSON Schema：**

```json
{
  "target_controller_id": "uuid",
  "execution_mode": "planned",
  "notes": "仅生成计划，不立即执行"
}
```

说明：当前预留接口按“单次生成一个控制器计划对象”设计；如后续需要一次性面向多个控制器生成计划，应扩展为批量接口并返回 `plans[]`。

**响应 202 JSON Schema：**

```json
{
  "plan": {
    "id": "uuid",
    "task_id": "uuid",
    "controller_id": "uuid",
    "operation_type": "planned_write",
    "targets": [],
    "impact_summary": {
      "risk_level": "high",
      "affected_sites": ["uuid"],
      "affected_devices": ["uuid"],
      "requires_approval": true
    },
    "approval_status": "pending",
    "plan_payload": {},
    "created_at": "2026-04-14T10:00:00Z"
  }
}
```

#### 8.3.8 GET `/api/v1/tasks/{id}/impact`

获取任务的拓扑影响范围与目标对象摘要。

**响应 200 JSON Schema：**

```json
{
  "task_id": "uuid",
  "risk_level": "high",
  "requires_approval": true,
  "affected_sites": [
    {
      "id": "uuid",
      "name": "DC-01"
    }
  ],
  "affected_devices": [
    {
      "id": "uuid",
      "name": "CoreSwitch01"
    }
  ],
  "affected_links": [
    {
      "id": "uuid",
      "label": "CoreSwitch01 -> AccessSwitch08"
    }
  ],
  "summary": "本次操作影响 DC-01 园区核心到接入链路。"
}
```

#### 8.3.9 POST `/api/v1/tasks/{id}/controller-execute`

执行已审批通过的控制器/API 级计划。

**请求 JSON Schema：**

```json
{
  "plan_id": "uuid",
  "approval_id": "uuid",
  "confirm": true
}
```

**响应 202 JSON Schema：**

```json
{
  "execution_ticket_id": "uuid",
  "task_id": "uuid",
  "plan_id": "uuid",
  "status": "queued",
  "message": "控制器操作计划已进入执行队列"
}
```

---

## 9. 阶段一 API 总数汇总（不含后续阶段预留接口）

以下统计仅覆盖阶段一正式接口，不包含 §8 的 Phase 2 / Phase 3 预留接口，也不包含 §3.8 的 Phase 3 内部服务预留接口。

| 分类 | 数量 |
|------|------|
| 认证 | 3 |
| 对话/任务 | 9 |
| 设备管理 | 6 |
| 设置 | 3 |
| SSE | 1 |
| 审计日志 | 2 |
| **前端 API 小计** | **24** |
| 大模型网关 | 1 |
| 意图引擎 | 5 |
| 设备管理程序 | 8 |
| 知识检索 | 2 |
| 审计服务 | 3 |
| **内部服务 API 小计** | **19** |
| 厂商适配层 | 5 |
| 函数调用与工具层 | 5 |
| **总计** | **52** |
