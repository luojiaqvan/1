# 数据库定义文档

## 1. 文档说明

### 1.1 文档定位

本文档是"大模型 + 网络工程配置/运维平台"阶段一数据库 schema 权威文档。定义所有表结构、字段类型、约束关系和索引策略，供开发人员编写 DDL 或 ORM 模型使用。

### 1.2 与其他文档的关系

| 文档 | 权威职责 | 与本文档的关系 |
|------|----------|---------------|
| API_SPEC.md | 数据模型权威来源 | 本文档将 API_SPEC.md §5 数据模型翻译为可执行的数据库定义 |
| ARCHITECTURE.md | 凭据加密方案、安全性设计 | 本文档引用 ARCHITECTURE.md §7.5 和 §9 的安全方案 |
| ROADMAP.md | 项目范围、功能边界 | 本文档不超出 ROADMAP.md 定义的阶段一范围 |

### 1.3 适用范围

- 阶段：阶段一
- 数据库：SQLite
- 用途：数据库表结构定义、DDL 编写参考、ORM 模型编写参考

---

## 2. 设计原则

### 2.1 安全优先

- 凭据加密：设备用户名密码、模型 API Key 使用 Fernet 对称加密（AES-128-CBC）存储为 BLOB 字段
- 用户隔离：所有业务查询强制带 user_id 过滤，外键约束确保数据归属
- 审计不可变：audit_logs 表只 INSERT，不 UPDATE/DELETE

### 2.2 与 API_SPEC.md 对齐

- 所有表结构、字段类型、约束完全对齐 API_SPEC.md §5 数据模型
- 不发明 API_SPEC.md 中不存在的字段或表
- CHECK 约束严格按照 API_SPEC 定义的枚举值编写可执行 SQL

### 2.3 命名约定

- 表名：小写下划线（如 users, devices, conversations）
- 字段名：小写下划线（如 user_id, created_at）
- 时间字段：统一使用 created_at, updated_at，类型为 TEXT，存储 ISO 8601 UTC 格式字符串
- 主键：统一使用 TEXT 类型存储 UUID，由应用层生成
- 外键：使用 <table>_id 格式（如 user_id, conversation_id）

### 2.4 SQLite 类型映射说明

SQLite 使用动态类型系统，实际存储类型为 TEXT、INTEGER、REAL、BLOB 或 NULL。本项目类型映射如下：

| 文档标注类型 | SQLite 实际类型 | 说明 |
|-------------|----------------|------|
| TEXT | TEXT | 字符串 |
| INTEGER | INTEGER | 整数 |
| BLOB | BLOB | 二进制数据（加密凭据） |
| JSON | TEXT | JSON 字符串，由应用层序列化/反序列化 |
| TIMESTAMP | TEXT | ISO 8601 UTC 时间字符串 |
| UUID | TEXT | UUID 字符串 |

> SQLite 不支持原生的 UUID、JSONB、TIMESTAMPTZ 类型。JSON 数据以 TEXT 存储，由应用层负责序列化/反序列化。时间以 ISO 8601 UTC 字符串存储，由应用层负责格式化和解析。

### 2.5 JSON 使用原则

- 结构化可变数据使用 JSON（TEXT 存储）：intent, candidate_commands, confirmed_commands, execution_results, metadata, event_data
- JSON 字段允许 NULL，根据业务需要可选存储
- 应用层负责 JSON 序列化（json.dumps）和反序列化（json.loads）

补充约束：

- `candidate_commands` 中若包含 `generation_basis`、`generation_source` 等字段，其结构必须对齐 API_SPEC.md 当前冻结契约，不得在数据库层另行发明枚举或对象格式。
- `execution_results` 中若包含 `parsed_output`，其结构必须对齐 API_SPEC.md 定义的统一包络 Schema。
- 知识引用追溯信息优先记录在 `audit_logs.event_data` 中；阶段一不要求单独拆表存储 `knowledge_refs`。

### 2.6 软删除策略

- 仅 conversations 表使用 deleted_at 字段实现软删除
- 其他表不使用软删除，直接物理删除

### 2.7 审计日志约束

- audit_logs 表只 INSERT，不 UPDATE/DELETE
- 所有审计事件必须记录，不可修改或删除

---

## 3. 表结构定义

### 3.1 users（用户表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| username | TEXT | UNIQUE NOT NULL | 用户名 |
| password_hash | TEXT | NOT NULL | bcrypt 哈希 |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |
| updated_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 更新时间（ISO 8601 UTC） |

### 3.2 devices（设备表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| user_id | TEXT | NOT NULL, REFERENCES users(id) ON DELETE CASCADE | 所属用户 |
| name | TEXT | NOT NULL | 设备名称/别名 |
| host | TEXT | NOT NULL | IP 或主机名 |
| port | INTEGER | NOT NULL DEFAULT 22 | 端口 |
| protocol | TEXT | NOT NULL, CHECK (protocol IN ('ssh', 'telnet')) | 连接协议 |
| vendor | TEXT | NOT NULL, CHECK (vendor IN ('huawei', 'h3c')) | 设备厂商 |
| device_type | TEXT | NOT NULL | netmiko device_type |
| model | TEXT | | 设备型号（可自动发现） |
| os_version | TEXT | | 系统版本（可自动发现） |
| username_encrypted | BLOB | NOT NULL | 加密存储的设备登录用户名 |
| password_encrypted | BLOB | NOT NULL | 加密存储的设备登录密码 |
| description | TEXT | | 设备描述 |
| last_connected_at | TEXT | | 最后连接时间（ISO 8601 UTC） |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |
| updated_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 更新时间（ISO 8601 UTC） |

**唯一约束：**
- UNIQUE(user_id, host, port)

### 3.3 conversations（会话表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| user_id | TEXT | NOT NULL, REFERENCES users(id) ON DELETE CASCADE | 所属用户 |
| title | TEXT | | 会话标题 |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |
| updated_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 更新时间（ISO 8601 UTC） |
| deleted_at | TEXT | | 软删除时间（ISO 8601 UTC） |

### 3.4 messages（消息表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| conversation_id | TEXT | NOT NULL, REFERENCES conversations(id) ON DELETE CASCADE | 所属会话 |
| role | TEXT | NOT NULL, CHECK (role IN ('user', 'assistant', 'system')) | 消息角色 |
| content | TEXT | NOT NULL | 消息内容 |
| content_type | TEXT | NOT NULL, CHECK (content_type IN ('text', 'intent_card', 'command_card', 'result_card')) | 内容类型 |
| metadata | TEXT | | 结构化卡片数据（JSON 字符串，应用层序列化） |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |

**存储约定：**

- 执行完成后的模型结果总结，默认作为 `assistant` 消息写入 `messages` 表。
- 若前端需要同时展示结果卡片与总结文本，可采用以下两种方式之一：
  1. 单条 `assistant` 消息，`content_type=result_card`，在 `metadata` 中同时放结构化结果与 `result_summary`
  2. 两条 `assistant` 消息：一条 `result_card`，一条 `text` 类型总结消息
- 阶段一不要求为 `result_summary` 单独新增 `messages` 表字段；优先复用 `content` 与 `metadata`。

**索引：**
- INDEX(messages_conversation_created_idx ON messages(conversation_id, created_at))

### 3.5 tasks（任务表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| user_id | TEXT | NOT NULL, REFERENCES users(id) ON DELETE CASCADE | 所属用户 |
| conversation_id | TEXT | NOT NULL, REFERENCES conversations(id) ON DELETE CASCADE | 所属会话 |
| message_id | TEXT | REFERENCES messages(id) | 触发该任务的用户消息 |
| status | TEXT | NOT NULL, CHECK (status IN ('running', 'pending_approval', 'executing', 'completed', 'rejected', 'failed')) | 任务状态 |
| intent | TEXT | | 结构化意图（JSON 字符串，应用层序列化） |
| candidate_commands | TEXT | | 候选命令列表（JSON 字符串，应用层序列化） |
| confirmed_commands | TEXT | | 用户确认后的命令（来自 proposal_id 关联的已冻结候选命令，JSON 字符串） |
| execution_results | TEXT | | 执行结果（JSON 字符串，应用层序列化） |
| risk_level | TEXT | CHECK (risk_level IN ('low', 'medium', 'high')) | 风险等级 |
| error_message | TEXT | | 错误信息 |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |
| updated_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 更新时间（ISO 8601 UTC） |

**索引：**
- INDEX(tasks_user_status_created_idx ON tasks(user_id, status, created_at))

**任务状态机：**

```
running → pending_approval → executing → completed
                           → rejected
                executing → failed
```

**状态转换规则：**

| 当前状态 | 允许的下一状态 | 触发条件 |
|---------|---------------|----------|
| running | pending_approval | 后端完成 tool_call 组装校验，候选命令已冻结 |
| running | failed | Agentic 调用失败 |
| pending_approval | executing | 用户确认 |
| pending_approval | rejected | 用户拒绝 |
| executing | completed | 所有命令执行成功 |
| executing | failed | 任一命令执行失败 |

**状态边界约束：**

- `tasks.status` 仅承载对外任务主状态机，不承载内部实现细节。
- 目标识别、知识检索、模板降级、结果总结等内部子阶段不得写入 `tasks.status`。
- 如需记录内部子阶段，应通过 `audit_logs.event_data` 或内部 trace 机制承载，而不是扩展 `status` 枚举。

**结果总结落库约定：**

- 阶段一要求执行完成后生成 `result_summary`，但默认不强制单独落在 `tasks` 表独立字段中。
- 如需从任务详情直接返回结果总结，可由应用层从最新的 assistant 结果消息中回填，或在后续版本通过独立迁移新增字段。

### 3.6 audit_logs（审计日志表）

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| task_id | TEXT | REFERENCES tasks(id) | 关联任务（可空） |
| user_id | TEXT | NOT NULL, REFERENCES users(id) | 操作用户 |
| conversation_id | TEXT | | 关联会话（可空） |
| event_type | TEXT | NOT NULL | 事件类型（14 种，见 API_SPEC.md §3.5 AU1） |
| event_data | TEXT | NOT NULL | 事件详情（JSON 字符串，应用层序列化） |
| timestamp | TEXT | NOT NULL DEFAULT (datetime('now')) | 事件时间（ISO 8601 UTC） |

**索引：**
- INDEX(audit_logs_task_timestamp_idx ON audit_logs(task_id, timestamp))
- INDEX(audit_logs_user_timestamp_idx ON audit_logs(user_id, timestamp))
- INDEX(audit_logs_event_type_idx ON audit_logs(event_type))

**操作约束：**
- 此表只 INSERT，不 UPDATE / DELETE

**追溯约定：**

- `knowledge_retrieved` 事件应尽量在 `event_data` 中记录本次使用的 `knowledge_refs` 最小追溯信息，如 `source_type`、`source_id`。
- `commands_generated` 事件应尽量在 `event_data` 中记录 `generation_source` 与关键 `generation_basis`，用于后续问题回放。
- 阶段一不要求为知识引用追溯单独建表，优先通过审计事件承载。

### 3.7 user_model_configs（用户模型配置表）

每用户可保存多套模型配置，同时只有一套处于激活状态。切换配置时由后端将旧配置的 `is_active` 置为 `false`，新配置置为 `true`。后端在运行时始终读取当前用户的激活配置。

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| id | TEXT | PRIMARY KEY | 主键（UUID，应用层生成） |
| user_id | TEXT | NOT NULL, REFERENCES users(id) ON DELETE CASCADE | 所属用户 |
| name | TEXT | NOT NULL | 配置名称（如"生产 GPT-4o"、"本地 Ollama"），同一用户下唯一 |
| is_active | INTEGER | NOT NULL DEFAULT 0 | 是否为当前激活配置（0=否，1=是）；同一用户下至多一行为 1 |
| main_model | TEXT | | 主模型标识 |
| main_model_base_url | TEXT | | 主模型自定义端点 |
| main_model_api_key_encrypted | BLOB | | 主模型 API Key（加密） |
| created_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 创建时间（ISO 8601 UTC） |
| updated_at | TEXT | NOT NULL DEFAULT (datetime('now')) | 更新时间（ISO 8601 UTC） |

**业务约束：**

- `(user_id, name)` 联合唯一——同一用户下配置名称不可重复
- `(user_id, is_active)` 实际至多一行 `is_active = 1`——由后端切换逻辑保证，不使用数据库 UNIQUE 约束（因为 SQLite 不支持部分唯一索引 `WHERE is_active = 1` 的跨平台写法）
- 切换激活配置为原子操作：在同一事务中将旧配置 `is_active` 置 0、新配置置 1
- 删除激活配置时，后端应阻止删除或自动激活该用户的另一套配置（具体策略由 API 层定义）

---

## 4. 表关系

```
users 1──N devices
users 1──N conversations
users 1──N tasks
users 1──N user_model_configs

conversations 1──N messages
conversations 1──N tasks

tasks 1──N audit_logs
users 1──N audit_logs
```

**外键约束汇总：**

| 表 | 外键字段 | 引用表 | 删除策略 |
|----|---------|--------|----------|
| devices | user_id | users(id) | CASCADE |
| conversations | user_id | users(id) | CASCADE |
| tasks | user_id | users(id) | CASCADE |
| user_model_configs | user_id | users(id) | CASCADE |
| messages | conversation_id | conversations(id) | CASCADE |
| tasks | conversation_id | conversations(id) | CASCADE |
| tasks | message_id | messages(id) | 无（保留历史） |
| audit_logs | task_id | tasks(id) | 无（保留历史） |
| audit_logs | user_id | users(id) | 无（保留历史） |

---

## 5. 索引策略

### 5.1 主键索引

所有表的 id 字段自动创建主键索引（PRIMARY KEY）。

### 5.2 唯一约束索引

| 表 | 约束 | 字段 |
|----|------|------|
| users | UNIQUE | username |
| devices | UNIQUE | (user_id, host, port) |
| user_model_configs | UNIQUE | (user_id, name) |

### 5.3 外键索引

SQLite 不自动为外键创建索引。以下外键建议手动创建索引以优化查询：

| 表 | 外键字段 | 是否自动索引 |
|----|---------|-------------|
| devices | user_id | 否（建议手动创建） |
| conversations | user_id | 否（建议手动创建） |
| tasks | user_id | 否（建议手动创建） |
| user_model_configs | user_id | 否（建议手动创建） |
| messages | conversation_id | 是（已有 messages_conversation_created_idx） |
| tasks | conversation_id | 否（建议手动创建） |
| tasks | message_id | 否（可选） |
| audit_logs | task_id | 是（已有 audit_logs_task_timestamp_idx） |
| audit_logs | user_id | 是（已有 audit_logs_user_timestamp_idx） |

### 5.4 业务索引

| 表 | 索引名 | 字段 | 用途 |
|----|--------|------|------|
| messages | messages_conversation_created_idx | (conversation_id, created_at) | 查询会话消息按时间排序 |
| tasks | tasks_user_status_created_idx | (user_id, status, created_at) | 查询用户任务按状态和时间过滤 |
| audit_logs | audit_logs_task_timestamp_idx | (task_id, timestamp) | 查询任务审计日志按时间排序 |
| audit_logs | audit_logs_user_timestamp_idx | (user_id, timestamp) | 查询用户审计日志按时间排序 |
| audit_logs | audit_logs_event_type_idx | (event_type) | 按事件类型查询审计日志 |

---

## 6. 安全约束

### 6.1 凭据加密方案

**加密算法：** Fernet 对称加密（基于 AES-128-CBC）

**密钥管理：**
- 密钥来源：环境变量 `CREDENTIAL_ENCRYPTION_KEY`
- 密钥长度：32 字节（URL-safe base64 编码）
- 密钥轮换：阶段一不支持

**加密字段清单：**
- devices.username_encrypted
- devices.password_encrypted
- user_model_configs.main_model_api_key_encrypted

**加密/解密边界：**

| 阶段 | 位置 | 形式 |
|------|------|------|
| 前端输入 | 用户浏览器 | 明文（HTTPS 传输） |
| 后端接收 | API 层 | 明文（仅在内存中短暂存在） |
| 存储前 | 加密模块 | 加密 |
| 数据库 | devices/user_model_configs 表 | 加密（BLOB） |
| 使用时 | 设备管理程序 | 解密（仅在内存中） |

### 6.2 用户数据隔离

**查询强制带 user_id：**
- 所有业务查询必须带 `user_id` 过滤
- 不信任前端传参，始终在后端强制过滤

**外键约束：**
- devices.user_id → users.id（CASCADE）
- conversations.user_id → users.id（CASCADE）
- tasks.user_id → users.id（CASCADE）

### 6.3 审计日志不可变

- audit_logs 表只 INSERT，不 UPDATE/DELETE
- 所有审计事件必须记录，不可修改或删除

---

## 7. 阶段一边界

### 7.1 不包含的表/功能

根据 ROADMAP.md 和 API_SPEC.md §5.3 阶段一策略，以下表和功能不在阶段一范围内：

- 接口对象表：阶段一不单独建表，作为设备执行结果中的嵌套数据返回
- 站点表：阶段一不建表、不提供 API，设备无分组
- 拓扑关系表：阶段一不建表、不提供 API，设备无拓扑关联
- 审批表：阶段一不包含审批流程
- 角色权限表（RBAC）：阶段一不包含角色权限管理
- 协议对象表：作为 devices 表的 protocol 字段管理，不单独建模
- 控制器表 / 控制域表 / 拓扑快照表 / 控制器操作计划表：阶段一不包含 SDN 场景数据对象

### 7.2 阶段一设备管理策略

引用 API_SPEC.md §5.3 原文：

> ROADMAP.md 功能开发跟踪表要求"定义设备、接口、站点、协议对象模型"。阶段一采取以下策略：
>
> - 设备（devices 表）：已完整定义，支持 CRUD
> - 接口对象：阶段一不单独建表，作为设备执行结果中的嵌套数据返回（如 `display interface brief` 的解析结果）
> - 站点/拓扑关系：阶段一不建表、不提供 API，设备无分组和拓扑关联
> - 协议对象：作为 devices 表的 protocol 字段管理，不单独建模
>
> 阶段二再补充：设备分组、站点模型、拓扑关系读取、接口对象独立存储。

### 7.3 后续扩展预留

阶段二将新增：
- 设备分组、站点模型、拓扑关系读取
- 接口对象独立存储

阶段三将新增：
- 审批流程、RBAC
- 如启用双模型串联，再通过独立迁移补充专用命令生成模型覆盖字段；未启用时各配置继续保持单模型字段

### 7.4 Phase 3 SDN 数据结构预留

以下表仅作为 Phase 3 的预留规划，不属于阶段一落库范围；若 Phase 2 的站点、接口、拓扑关系表未完成，不应提前创建这些表。

| 表名 | 用途 | 关键字段（规划） | 依赖 |
|------|------|------------------|------|
| `controllers` | 存储已纳管的 SDN 控制器或结构化网络接口入口 | `id`, `user_id`, `name`, `controller_type`, `endpoint`, `auth_type`, `username_encrypted`, `secret_encrypted`, `capability_summary`, `status`, `last_synced_at`, `created_at`, `updated_at` | users |
| `controller_domains` | 存储控制器下的逻辑域 / fabric / 租户范围 | `id`, `user_id`, `controller_id`, `name`, `domain_type`, `scope_summary`, `metadata`, `created_at`, `updated_at` | users, controllers |
| `topology_snapshots` | 存储拓扑同步结果与摘要，支持回看与审计定位 | `id`, `user_id`, `controller_id`, `snapshot_type`, `summary`, `snapshot_data`, `collected_at`, `created_at` | users, controllers；依赖 Phase 2 拓扑基础 |
| `controller_operation_plans` | 存储由意图引擎生成的控制器/API 级候选操作计划 | `id`, `user_id`, `task_id`, `controller_id`, `operation_type`, `targets`, `plan_payload`, `impact_summary`, `approval_status`, `created_at`, `updated_at` | users, tasks, controllers |

补充约束：

- 以上表均应遵循与阶段一一致的用户隔离原则，强制带 `user_id`。
- 控制器认证信息必须沿用 Fernet 加密存储，不得明文落库。
- `topology_snapshots.snapshot_data`、`controller_operation_plans.plan_payload`、`impact_summary` 建议使用 JSON（TEXT 存储），承接结构化但可变的数据。
- 审批、RBAC、审计的通用表结构由 Phase 3 通用策略能力统一定义，SDN 表通过外键或业务字段与其关联，不重复造表。

### 7.4 Phase 3 SDN 数据结构预留

以下表仅作为 Phase 3 的预留规划，不属于阶段一落库范围；若 Phase 2 的站点、接口、拓扑关系表未完成，不应提前创建这些表。

| 表名 | 用途 | 关键字段（规划） | 依赖 |
|------|------|------------------|------|
| `controllers` | 存储已纳管的 SDN 控制器或结构化网络接口入口 | `id`, `user_id`, `name`, `controller_type`, `endpoint`, `auth_type`, `username_encrypted`, `secret_encrypted`, `capability_summary`, `status`, `last_synced_at`, `created_at`, `updated_at` | users |
| `controller_domains` | 存储控制器下的逻辑域 / fabric / 租户范围 | `id`, `user_id`, `controller_id`, `name`, `domain_type`, `scope_summary`, `metadata`, `created_at`, `updated_at` | users, controllers |
| `topology_snapshots` | 存储拓扑同步结果与摘要，支持回看与审计定位 | `id`, `user_id`, `controller_id`, `snapshot_type`, `summary`, `snapshot_data`, `collected_at`, `created_at` | users, controllers；依赖 Phase 2 拓扑基础 |
| `controller_operation_plans` | 存储由意图引擎生成的控制器/API 级候选操作计划 | `id`, `user_id`, `task_id`, `controller_id`, `operation_type`, `targets`, `plan_payload`, `impact_summary`, `approval_status`, `created_at`, `updated_at` | users, tasks, controllers |

补充约束：

- 以上表均应遵循与阶段一一致的用户隔离原则，强制带 `user_id`。
- 控制器认证信息必须沿用 Fernet 加密存储，不得明文落库。
- `topology_snapshots.snapshot_data`、`controller_operation_plans.plan_payload`、`impact_summary` 建议使用 JSONB，承接结构化但可变的数据。
- 审批、RBAC、审计的通用表结构由 Phase 3 通用策略能力统一定义，SDN 表通过外键或业务字段与其关联，不重复造表。

---
