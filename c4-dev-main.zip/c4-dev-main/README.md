# 大模型 + 网络工程配置/运维平台

本项目是一个面向多厂商网络设备的智能运维平台，目标是将自然语言请求转换为结构化运维意图，并在受控前提下生成候选命令、执行命令并返回结果。

当前聚焦阶段一主链路：

- 自然语言请求
- 结构化意图解析
- 候选命令生成
- 用户确认
- 设备执行与结果返回

## 阶段一主流程示意图

```mermaid
flowchart TD
    U[用户]
    FE[前端]
    API1[后端接收请求]
    GW[LLM网关]
    IE[意图引擎]
    KS[知识检索]
    SSE[SSE推送]
    CONF[用户确认]
    API2[后端执行任务]
    DM[设备管理]
    DEV[网络设备]
    API3[后端汇总结果]
    DB[数据库和审计]
    U -- 发起自然语言请求 --> FE
    FE -- 提交请求 --> API1
    API1 -- 发起Agentic调用 --> GW
    GW -- 交给意图收口 --> IE
    IE -- 检索知识 --> KS
    KS -- 返回知识引用 --> IE
    IE -- 返回意图和候选命令 --> API1
    API1 -- 推送状态与候选命令 --> SSE
    SSE -- 实时更新界面 --> FE
    FE -- 用户点击确认 --> CONF
    CONF -- 提交执行确认 --> API2
    API2 -- 下发已确认命令 --> DM
    DM -- 连接并执行命令 --> DEV
    DEV -- 返回设备输出 --> DM
    DM -- 返回执行结果 --> API3
    API3 -- 写入消息任务审计 --> DB
    API3 -- 返回最终结果 --> FE
```

当前阶段不包含审批、RBAC、自动回滚等后续能力。

## 文档导航

项目当前以文档设计为主，核心文档如下：

- `docs/ROADMAP.md`
  - 项目路线、阶段目标、模块边界、演进方向
  - 用于回答“项目做什么、先做什么、暂不做什么”
- `docs/API_SPEC.md`
  - 阶段一前端 API、内部服务接口、数据模型、SSE 事件定义
  - 用于回答“接口怎么定义、请求响应长什么样”
- `docs/ARCHITECTURE.md`
  - 阶段一技术架构冻结基线，定义组件结构、核心数据流、运行约束
  - 用于回答“系统怎么分层、模块怎么协作”
- `docs/TOOLS_SPEC.md`
  - LLM 提示词工程、工具调用规范、厂商适配策略、命令知识库 Schema
  - 用于回答“模型怎么调用工具、怎么生成候选命令、怎么防幻觉”
- `AGENTS.template.md`
  - 人类开发者与 AI Agent 的协作规则模板
  - 用于回答“协作时应遵守什么规则”

建议阅读顺序：

1. `docs/ROADMAP.md`
2. `docs/API_SPEC.md`
3. `docs/ARCHITECTURE.md`
4. `docs/TOOLS_SPEC.md`
5. `AGENTS.template.md`

## 当前仓库状态

- 当前仓库主要用于沉淀阶段一设计文档
- 代码骨架与实现将在现有文档约束下逐步推进
- 当前默认支持厂商：华为 VRP、H3C Comware
- 当前默认协议：SSH、Telnet（通过 `netmiko`）
- `参考项目/` 目录用于保存调研总结及参考项目引用信息，便于后续对照分析

## 使用注意事项

- AI 工具默认读取 `AGENTS.md`
- 仓库中提交的是模板文件 `AGENTS.template.md`
- 本地使用前，请先自行复制一份模板并重命名为 `AGENTS.md`

示例：

```bash
cp AGENTS.template.md AGENTS.md
```

Windows PowerShell 示例：

```powershell
Copy-Item AGENTS.template.md AGENTS.md
```

其他注意事项：

- `AGENTS.md` 已加入 `.gitignore`，用于保存开发者本地协作规则
- 不要将本地专用配置、凭据或临时分析产物提交到仓库
- 如核心设计发生变更，应同步更新对应文档，避免实现与文档漂移
- 如需实际查看、运行或二次分析 `参考项目/` 下的参考仓库，请单独克隆对应子项目源码；仅克隆当前主仓库不会自动拉取这些参考项目的完整内容
- `参考项目/参考项目调研总结.md` 用于快速了解这些参考项目的主要价值、适用边界与对本项目的可借鉴点

## 团队开发环境使用方式

为便于团队统一开发环境，建议在仓库中维护 `environment.yml` 作为 Conda 环境定义文件。团队成员**不共享同一个本地虚拟环境目录**，而是各自在本机基于同一份环境定义创建环境，以保证 Python 版本和基础运行时一致。

推荐使用方式：

```bash
conda env create -f environment.yml
conda activate c4-dev
```

环境职责约定：

- Conda 负责统一 Python、pip、Node.js 等运行时基线
- Python 业务依赖仍通过 `requirements.txt` / `requirements-dev.txt` 或 `pyproject.toml` 管理
- 前端依赖仍通过 `package.json` 及对应 lockfile 管理
- `.env`、密钥、数据库实例、模拟器环境（如 eNSP/HCL）不纳入 Conda 环境定义

## 后续工作

- 基于现有文档推进项目骨架与模块实现
- 在实现过程中持续校正文档与设计约束
- 对新增能力优先补充到现有核心文档，而不是扩散新文档
