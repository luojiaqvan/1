"""LiteLLM 最小异步封装。"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

import litellm

from .config import GatewaySettings, get_gateway_settings
from .exceptions import GatewayError, normalize_exception
from .models import ChatCompletionRequest, GatewayModelConfig, HealthResponse, StreamChunk


class LLMGateway:
    def __init__(
        self,
        settings: GatewaySettings | None = None,
        completion_fn: Any | None = None,
    ) -> None:
        self.settings = settings or get_gateway_settings()
        self._completion_fn = completion_fn or litellm.acompletion

    async def health_check(self) -> HealthResponse:
        return HealthResponse(
            default_model=self.settings.default_model,
            provider_configured=self.settings.provider_configured,
        )

    async def chat_completion(self, request: ChatCompletionRequest) -> dict[str, Any]:
        payload = self._build_payload(request, stream=False)

        try:
            response = await self._completion_fn(**payload)
        except Exception as exc:  # noqa: BLE001
            raise normalize_exception(exc) from exc

        return self._normalize_chat_response(self._to_dict(response))

    async def chat_completion_stream(
        self,
        request: ChatCompletionRequest,
    ) -> AsyncIterator[StreamChunk]:
        payload = self._build_payload(request, stream=True)

        try:
            response = await self._completion_fn(**payload)
        except Exception as exc:  # noqa: BLE001
            raise normalize_exception(exc) from exc

        async def stream_generator() -> AsyncIterator[StreamChunk]:
            index = 0
            try:
                async for chunk in response:
                    delta = self._extract_delta(chunk)
                    if delta:
                        yield StreamChunk(delta=delta, done=False, index=index)
                        index += 1
            except Exception as exc:  # noqa: BLE001
                raise normalize_exception(exc) from exc

            yield StreamChunk(delta="", done=True, index=index)

        return stream_generator()

    def _build_payload(self, request: ChatCompletionRequest, *, stream: bool) -> dict[str, Any]:
        runtime_config = self._resolve_runtime_model_config(request.runtime_model_config)

        payload: dict[str, Any] = {
            "model": runtime_config.model,
            "messages": [message.model_dump(exclude_none=True) for message in request.messages],
            "stream": stream,
            "timeout": request.timeout_seconds or runtime_config.timeout_seconds or self.settings.timeout_seconds,
        }

        if runtime_config.api_base:
            payload["api_base"] = runtime_config.api_base
        if runtime_config.api_key:
            payload["api_key"] = runtime_config.api_key
        if runtime_config.extra_headers:
            payload["extra_headers"] = runtime_config.extra_headers
        if request.tools is not None:
            payload["tools"] = request.tools
        if request.response_format is not None:
            payload["response_format"] = request.response_format
        if request.user_id is not None:
            payload["user"] = request.user_id
        if request.temperature is not None:
            payload["temperature"] = request.temperature
        if request.max_tokens is not None:
            payload["max_tokens"] = request.max_tokens

        return payload

    def _resolve_runtime_model_config(self, model_config: GatewayModelConfig) -> GatewayModelConfig:
        normalized_model = self._normalize_model_identifier(
            model=model_config.model,
            api_base=model_config.api_base,
        )

        return model_config.model_copy(
            update={
                "model": normalized_model,
                "api_base": model_config.api_base.strip() if isinstance(model_config.api_base, str) else model_config.api_base,
                "api_key": model_config.api_key.strip() if isinstance(model_config.api_key, str) else model_config.api_key,
            }
        )

    def _normalize_model_identifier(self, *, model: str, api_base: str | None) -> str:
        normalized = model.strip()
        if not normalized:
            raise GatewayError(
                "invalid_model_config",
                "模型配置不合法",
                details={"field": "model", "reason": "model 不能为空"},
                status_code=400,
            )

        if "/" in normalized:
            return normalized

        if api_base:
            return f"openai/{normalized}"

        raise GatewayError(
            "invalid_model_config",
            "模型配置不合法",
            details={
                "field": "model",
                "reason": "model 缺少 provider 前缀，且未提供 api_base 用于按 OpenAI 兼容端点归一化",
            },
            status_code=400,
        )

    def _to_dict(self, response: Any) -> dict[str, Any]:
        if hasattr(response, "model_dump"):
            return response.model_dump(exclude_none=True)
        if isinstance(response, dict):
            return response
        if hasattr(response, "dict"):
            return response.dict(exclude_none=True)
        return {"result": response}

    def _extract_delta(self, chunk: Any) -> str:
        data = self._to_dict(chunk)
        choices = data.get("choices") or []
        if not choices:
            return ""

        first_choice = choices[0] or {}
        delta = first_choice.get("delta") or {}
        content = delta.get("content")

        if content is None:
            return ""
        if isinstance(content, list):
            return "".join(part.get("text", "") for part in content if isinstance(part, dict))
        return str(content)

    def _normalize_chat_response(self, data: dict[str, Any]) -> dict[str, Any]:
        normalized: dict[str, Any] = {}

        for key in ("id", "object", "created", "model"):
            value = data.get(key)
            if value is not None:
                normalized[key] = value

        choices = data.get("choices") or []
        normalized_choices: list[dict[str, Any]] = []
        for choice in choices:
            if not isinstance(choice, dict):
                continue

            normalized_choice: dict[str, Any] = {}
            if choice.get("index") is not None:
                normalized_choice["index"] = choice["index"]
            if choice.get("finish_reason") is not None:
                normalized_choice["finish_reason"] = choice["finish_reason"]

            message = choice.get("message")
            if isinstance(message, dict):
                normalized_message: dict[str, Any] = {}
                for message_key in ("role", "content", "tool_calls"):
                    message_value = message.get(message_key)
                    if message_value is not None:
                        normalized_message[message_key] = message_value
                if normalized_message:
                    normalized_choice["message"] = normalized_message

            if normalized_choice:
                normalized_choices.append(normalized_choice)

        normalized["choices"] = normalized_choices

        usage = data.get("usage")
        if isinstance(usage, dict):
            normalized["usage"] = usage

        return normalized
