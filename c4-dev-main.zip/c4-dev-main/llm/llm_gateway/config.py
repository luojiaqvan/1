"""LLM Gateway 最小配置。"""

from __future__ import annotations

import os
from functools import lru_cache

from pydantic import BaseModel, Field


class GatewaySettings(BaseModel):
    """阶段一最小化网关配置。"""

    default_model: str = Field(default="gpt-4o-mini")
    timeout_seconds: float = Field(default=30.0, gt=0)
    api_base: str | None = None
    api_key: str | None = None

    @property
    def provider_configured(self) -> bool:
        return bool(self.api_key)


@lru_cache(maxsize=1)
def get_gateway_settings() -> GatewaySettings:
    return GatewaySettings(
        default_model=os.getenv("LLM_GATEWAY_DEFAULT_MODEL", "gpt-4o-mini"),
        timeout_seconds=float(os.getenv("LLM_GATEWAY_TIMEOUT_SECONDS", "30")),
        api_base=os.getenv("OPENAI_API_BASE") or os.getenv("LITELLM_API_BASE"),
        api_key=os.getenv("OPENAI_API_KEY") or os.getenv("LITELLM_API_KEY"),
    )
