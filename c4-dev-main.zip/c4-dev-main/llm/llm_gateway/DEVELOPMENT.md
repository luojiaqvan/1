# 大模型网关开发文档

## 1. 文档说明

### 1.1 目的与范围

本文档是 `llm/llm_gateway` 模块的实现指南，定位为面向开发者的操作手册，用于指导基于 LiteLLM 封装的大模型网关开发。

**本文档目标读者：**
- 负责实现大模型网关模块的后端开发者
- 需要理解网关接口契约的协作模块开发者（意图引擎、审计服务）
- 后续维护和优化网关模块的开发者

**本文档范围：**
- 明确网关模块职责边界与接口契约
- 提供具体的文件结构与模块骨架建议
- 规定统一流式 Agentic 调用接口的实现要点
- 定义配置管理、模型路由、流式转发的技术方案
- 规范安全性要求与版本锁定策略
- 提供分阶段实施路径与验收标准

**本文档不包含：**
- 通用 LiteLLM 使用教程（请参考官方文档）
- 前端对接细节（见 `API_SPEC.md §2`）
- 意图解析与命令生成逻辑（见 `TOOLS_SPEC.md`）
- 部署与运维方案（见后续文档）

### 1.2 与权威文档的关系

本模块实现必须严格遵循以下权威文档：

| 文档 | 权威内容 | 本模块如何引用 |
|------|----------|----------------|
| `ROADMAP.md` | 模块职责、阶段一定位、LiteLLM 选型决策 | 作为职责边界与验收标准依据 |
| `ARCHITECTURE.md` | 单进程架构、组件依赖关系、安全约束 | 作为实现约束与设计模式依据 |
| `API_SPEC.md §3.1` | 统一流式 Agentic 调用接口定义、请求响应结构 | 作为接口实现的唯一权威 |
| `TOOLS_SPEC.md §2` | 主模型提示词规范、工具调用约定 | 作为模型调用参数拼装依据 |
| `AGENTS.md` | 协作规则、提交规范、文档风格 | 作为开发过程规范 |

**不变量声明：**
- 本模块对外暴露统一流式 Agentic 调用接口（不再区分 LG1/LG2/LG3）
- 本模块负责 tool_call 片段的拼装与校验
- 本模块接收 `toolset`（skills + MCP + tool_definitions），并在内部编译为 provider tools
- 本模块不负责意图解析和命令生成（由意图引擎负责）
- 本模块不直接持有设备连接（由设备管理程序负责）
- 本模块必须锁定 LiteLLM 版本并验证包完整性

---

## 2. 模块职责与边界

### 2.1 核心职责

根据 `ROADMAP.md §5.3` 和 `ARCHITECTURE.md §3.1`，本模块承担以下职责：

1. **统一流式 Agentic 调用接口封装**
   - 对接 LiteLLM，对外暴露统一的流式 Agentic Chat Completions 接口
   - 单次调用同时支持文本流式输出和 tool_call 流式返回
   - 不再区分 LG1/LG2/LG3，合并为单一 Agentic 调用

2. **模型统一路由**
   - 统一 Agentic 调用使用同一模型，Phase 1 无需按场景路由
- 支持消费后端传入的用户级模型配置对象（后端已从 `user_model_configs` 表中选出当前激活配置并完成解密）
   - Phase 3 可选扩展为不同任务类型使用不同模型，但默认必须兼容同一上下文单模型模式

3. **流式输出转发**
   - 对接 LiteLLM 的流式响应
   - 转换为内部统一的 StreamChunk 判别联合结构（包含 text_delta、tool_call_start、tool_call_args_delta、tool_call_complete、state、error 类型）
   - 支持 SSE 推送到前端

4. **Tool Call 拼装与校验**
   - 累积流式返回的 tool_call 参数片段（args delta）
   - 在 tool_call 完成时拼装完整 JSON 并校验
   - 无效 JSON 的 tool_call 跳过并记录错误日志
   - 多个 tool_call 分别独立拼装与授权

5. **限流、日志与成本统计**
   - 记录每次模型调用的 token 消耗
   - 记录调用耗时、成功失败状态
   - 支持按用户维度的调用限流（阶段一可选）

6. **失败切换与降级**
   - 主模型调用失败时的降级策略
   - 单一 Agentic 调用整体降级，不按接口分别降级

### 2.2 非职责（本模块不做）

以下职责明确不属于本模块，避免越界：

- **意图解析逻辑**：由意图引擎（`llm/intent_engine`）负责
- **命令生成逻辑**：由意图引擎 + 厂商适配层负责
- **设备连接管理**：由设备管理程序（`backend/device_manager`）负责
- **用户认证**：由后端 API 服务（`backend/api`）负责
- **SSE 推送实现**：由 SSE 管理器（`backend/sse`）负责
- **审计日志记录**：由审计服务（`backend/audit_service`）负责
- **提示词工程**：由工具层（`llm/tools`）和厂商适配层负责

### 2.3 与其他模块的边界

| 调用方向 | 接口 | 数据格式 | 说明 |
|----------|------|----------|------|
| 后端 API 服务 → 本模块 | 进程内函数调用 | `model_config` + 请求参数 | 后端负责传入当前调用应使用的模型配置 |
| 意图引擎 → 本模块 | 统一流式 Agentic 调用 | `model_config + messages + toolset` | 进程内函数调用 |
| 本模块 → LiteLLM | HTTP | OpenAI API 格式 | 外部 HTTP 调用 |
| 本模块 → 审计服务 | AU1 | 审计事件结构 | 调用日志记录 |

---

## 3. 推荐模块骨架

### 3.1 目录结构

```
llm/llm_gateway/
├── __init__.py                 # 模块导出
├── core/                       # 核心实现
│   ├── __init__.py
│   ├── gateway.py              # 主网关类，封装 LiteLLM
│   ├── models.py               # 数据模型定义（请求/响应）
│   ├── config.py               # 配置加载与管理
│   └── exceptions.py           # 自定义异常类
├── interfaces/                 # 接口实现
│   ├── __init__.py
│   └── agentic_streaming.py    # 统一流式 Agentic 调用
├── routing/                    # 路由策略
│   ├── __init__.py
│   └── model_router.py         # 模型路由与降级
├── observability/              # 可观察性
│   ├── __init__.py
│   ├── logger.py               # 调用日志记录
│   ├── metrics.py              # 成本与性能指标
│   └── auditor.py              # 审计事件转发
├── utils/                      # 工具函数
│   ├── __init__.py
│   ├── stream_parser.py        # 流式响应解析
│   ├── tool_call_assembler.py  # Tool call 片段拼装与校验
│   └── validator.py            # 参数校验
├── config/                     # 配置文件（不提交到仓库）
│   ├── litellm_config.yaml     # LiteLLM 配置模板（示例）
│   └── litellm_config.example.yaml  # 配置示例
└── DEVELOPMENT.md              # 本文档
```

### 3.2 核心文件说明

#### `core/gateway.py`

主网关类，封装 LiteLLM 客户端。

```python
class LLMGateway:
    """大模型网关主类"""

    def __init__(self, config: GatewayConfig):
        self.config = config
        self.litellm_client = self._init_litellm()
        self.model_router = ModelRouter(config)
        self.auditor = GatewayAuditor()

    async def agentic_completion_stream(
        self,
        model_config: GatewayModelConfig,
        messages: List[Dict],
        toolset: Optional[Dict] = None,
        user_id: str = None,
        **kwargs
    ) -> AsyncGenerator[StreamChunk, None]:
        """统一流式 Agentic 调用接口，同时支持文本流和 tool_call 流"""
        pass

    def _init_litellm(self) -> LiteLLM:
        """初始化 LiteLLM 客户端"""
        pass
```

#### `core/models.py`

数据模型定义，对齐 `API_SPEC.md §3.1`。

```python
from pydantic import BaseModel
from typing import List, Optional, Dict, Union, AsyncGenerator, Literal

class ChatCompletionRequest(BaseModel):
    """统一流式 Agentic 调用请求结构"""
    model: str
    messages: List[Dict[str, str]]
    toolset: Optional[Dict] = None
    stream: bool = True
    user_id: str

class SkillDefinition(BaseModel):
    skill_id: str
    name: str
    description: str
    instruction: str
    input_schema_ref: Optional[str] = None
    output_schema_ref: Optional[str] = None
    enabled: bool = True

class MCPBinding(BaseModel):
    mcp_id: str
    server_name: str
    transport: str
    capabilities: List[str]
    connection_scope: Optional[str] = None
    timeout_seconds: Optional[float] = None
    enabled: bool = True

class ToolDefinition(BaseModel):
    tool_name: str
    skill_id: str
    mcp_id: Optional[str] = None
    mcp_capability: Optional[str] = None
    exposure: Literal["model_direct", "approval_gated", "backend_only"]
    provider_schema: str

class ModelToolset(BaseModel):
    toolset_id: str
    skills: List[SkillDefinition]
    mcps: List[MCPBinding] = []
    tool_definitions: List[ToolDefinition]

# --- StreamChunk 判别联合类型 ---

class TextDeltaChunk(BaseModel):
    """文本增量块"""
    type: Literal["text_delta"] = "text_delta"
    delta: str

class ToolCallStartChunk(BaseModel):
    """Tool call 开始块"""
    type: Literal["tool_call_start"] = "tool_call_start"
    tool_call_id: str
    function_name: str

class ToolCallArgsDeltaChunk(BaseModel):
    """Tool call 参数增量块"""
    type: Literal["tool_call_args_delta"] = "tool_call_args_delta"
    tool_call_id: str
    args_delta: str

class ToolCallCompleteChunk(BaseModel):
    """Tool call 完成块（含拼装校验结果）"""
    type: Literal["tool_call_complete"] = "tool_call_complete"
    tool_call_id: str
    function_name: str
    arguments: str
    valid: bool

class StateChunk(BaseModel):
    """状态变更块"""
    type: Literal["state"] = "state"
    state: Literal["running", "pending_approval", "executing", "completed", "failed", "rejected"]

class ErrorChunk(BaseModel):
    """错误块"""
    type: Literal["error"] = "error"
    error_code: str
    error_message: str

StreamChunk = Union[
    TextDeltaChunk,
    ToolCallStartChunk,
    ToolCallArgsDeltaChunk,
    ToolCallCompleteChunk,
    StateChunk,
    ErrorChunk,
]
```

#### `interfaces/agentic_streaming.py`

实现统一流式 Agentic 调用接口。

```python
class AgenticStreaming:
    """统一流式 Agentic 调用 — 文本 + tool_call 同时流式返回"""

    def __init__(self, gateway: LLMGateway, tool_call_assembler: ToolCallAssembler):
        self.gateway = gateway
        self.tool_call_assembler = tool_call_assembler

    async def agentic_completion_stream(
        self,
        model_config: GatewayModelConfig,
        messages: List[Dict],
        toolset: Optional[ModelToolset] = None,
        user_id: str = None
    ) -> AsyncGenerator[StreamChunk, None]:
        """
        统一流式 Agentic 调用

        同时处理：
        - 文本增量（delta.content → TextDeltaChunk）
        - Tool call 片段（delta.tool_calls → ToolCallStart/ArgsDelta/Complete）
        - 状态变更（state → StateChunk）
        - 错误（error → ErrorChunk）
        """
        pass
```

#### `utils/tool_call_assembler.py`

实现 Tool Call 参数片段的累积拼装与校验。

```python
class ToolCallAssembler:
    """Tool Call 片段拼装器"""

    def __init__(self):
        self._pending: Dict[str, Dict] = {}  # tool_call_id → {function_name, args_buffer}

    def on_tool_call_start(self, tool_call_id: str, function_name: str) -> None:
        """记录 tool_call 开始"""
        pass

    def on_args_delta(self, tool_call_id: str, args_delta: str) -> None:
        """累积参数片段"""
        pass

    def on_tool_call_complete(self, tool_call_id: str) -> Optional[ToolCallCompleteChunk]:
        """拼装完成并校验 JSON，返回 ToolCallCompleteChunk 或 None"""
        pass

    def reset(self) -> None:
        """重置所有待处理状态"""
        pass
```

---

## 4. 流式 Agentic 调用实现

### 4.1 接口契约

统一流式 Agentic 调用，单次调用同时支持文本流式输出和 tool_call 流式返回：

```python
async def agentic_completion_stream(
    model_config: GatewayModelConfig,
    messages: List[Dict],
    toolset: Optional[ModelToolset] = None,
    user_id: str = None
) -> AsyncGenerator[StreamChunk, None]:
    """
    统一流式 Agentic 调用

    请求结构：
- model_config: 运行时模型配置（从 `user_model_configs` 中读取当前激活配置并解密）
    - messages: 包含 system prompt、对话历史
    - toolset: 工具定义集合（skills + MCP + tool_definitions）
    - stream: 固定为 True

    响应结构（StreamChunk 判别联合）：
    - TextDeltaChunk: 文本增量
    - ToolCallStartChunk: tool_call 开始（含 tool_call_id、function_name）
    - ToolCallArgsDeltaChunk: tool_call 参数片段增量
    - ToolCallCompleteChunk: tool_call 完成（含拼装后的完整 arguments、校验结果）
    - StateChunk: 状态变更（running → pending_approval → executing → completed）
    - ErrorChunk: 错误信息
    """
    pass
```

### 4.2 实现要点

1. **接收后端传入的模型配置对象**
   ```python
   model = model_config.model
   api_key = model_config.api_key
   base_url = model_config.api_base
   timeout_seconds = model_config.timeout_seconds
   ```

2. **先编译 toolset，再使用 `litellm.acompletion_stream` 调用**
    ```python
    compiled_tools = self.compile_provider_tools(toolset, execution_phase="planning")

    async for chunk in litellm.acompletion_stream(
        model=model,
        messages=messages,
        tools=compiled_tools,
        api_key=api_key,
        api_base=base_url,
        timeout=timeout_seconds,
        stream=True
   ):
       async for stream_chunk in self._parse_agentic_chunk(chunk):
           yield stream_chunk
   ```

3. **Chunk 解析：同时处理文本和 tool_call**

   - **文本增量**：`delta.content` → `TextDeltaChunk`
   - **Tool call 开始**：`delta.tool_calls[i]` 首次出现（含 `function.name`）→ `ToolCallStartChunk`
   - **Tool call 参数片段**：`delta.tool_calls[i].function.arguments` → `ToolCallArgsDeltaChunk`
   - **Tool call 完成**：`finish_reason == "tool_calls"` 或 `delta.tool_calls[i]` 无新内容 → 触发拼装校验 → `ToolCallCompleteChunk`

   ```python
   async def _parse_agentic_chunk(self, litellm_chunk) -> AsyncGenerator[StreamChunk, None]:
       choice = litellm_chunk.choices[0]
       delta = choice.delta

       # 文本增量
       if delta.content:
           yield TextDeltaChunk(delta=delta.content)

       # Tool call 片段
       if delta.tool_calls:
           for tc in delta.tool_calls:
               if tc.function.name:
                   # 新 tool_call 开始
                   self.tool_call_assembler.on_tool_call_start(tc.id, tc.function.name)
                   yield ToolCallStartChunk(tool_call_id=tc.id, function_name=tc.function.name)
               if tc.function.arguments:
                   # 参数增量
                   self.tool_call_assembler.on_args_delta(tc.id, tc.function.arguments)
                   yield ToolCallArgsDeltaChunk(tool_call_id=tc.id, args_delta=tc.function.arguments)

       # Tool call 完成
       if choice.finish_reason == "tool_calls":
           for complete_chunk in self.tool_call_assembler.finalize_all():
               yield complete_chunk
           yield StateChunk(state="pending_approval")

       # 文本流完成
       if choice.finish_reason == "stop":
           yield StateChunk(state="completed")
   ```

4. **Toolset 编译与 Tool Call 拼装校验**

   - `compile_provider_tools()` 负责把 `toolset.skills + toolset.mcps + toolset.tool_definitions` 编译为 LiteLLM/OpenAI 兼容 `tools[]`
   - `exposure=approval_gated / backend_only` 的定义，在候选命令生成阶段不得下发给主模型
   - 需要连接发现或执行的逻辑工具，必须校验其 `mcp_id` 与 `mcp_capability` 是否存在且可用

   - `ToolCallAssembler` 按 `tool_call_id` 累积参数片段
   - 完成时拼装完整 JSON 字符串并校验：
     - 有效 JSON → `ToolCallCompleteChunk(valid=True)`
     - 无效 JSON → `ToolCallCompleteChunk(valid=False)`，跳过该 tool_call，记录错误日志
   - 多个 tool_call 独立拼装，互不影响

5. **状态管理**

   | 事件 | 发出的 StateChunk |
   |------|-------------------|
   | 开始调用 | `StateChunk(state="running")` |
   | 收到 tool_calls 完成 | `StateChunk(state="pending_approval")` |
   | 文本流正常结束 | `StateChunk(state="completed")` |
   | 调用失败 | `StateChunk(state="failed")` |

6. **审计日志**
   ```python
   await auditor.log_llm_call(
       user_id=user_id,
       model=model,
       interface="agentic_streaming",
       request_tokens=response.usage.prompt_tokens,
       response_tokens=response.usage.completion_tokens,
       success=True
   )
   ```

### 4.3 错误处理

| 错误类型 | 处理策略 | 返回给调用方 |
|----------|----------|--------------|
| API Key 无效 | 返回明确错误 | `ErrorChunk(error_code="GATEWAY_INVALID_API_KEY", ...)` |
| 模型不可用 | 尝试降级模型 | 使用备用模型或返回 `ErrorChunk` |
| 超时 | 重试 1 次 | `ErrorChunk(error_code="GATEWAY_TIMEOUT", ...)` |
| 连接中断 | 发送错误 chunk 并结束流 | `ErrorChunk` + `StateChunk(state="failed")` |
| Chunk 乱序 | 记录警告，按 tool_call_id 重组 | 正常继续 |
| Tool call JSON 无效 | 跳过该 tool_call | `ToolCallCompleteChunk(valid=False)` |

---

## 5. 配置管理策略

### 5.1 配置来源与职责边界

阶段一配置优先级仍为：

1. **数据库用户激活配置**（`user_model_configs` 表中 `is_active = 1` 的记录）
2. **环境变量**（.env 文件）
3. **代码默认值**（fallback）

但这三层优先级的**合并动作由后端 API 服务负责**，大模型网关只负责消费后端传入的最终运行时配置对象。

网关侧的职责是：

- 校验 `model_config` 字段是否完整可用
- 将 `model` 归一化为 LiteLLM 可识别格式
- 将 `model_config` 与请求级动态参数合并
- 在不泄露敏感字段的前提下将其转换为 LiteLLM 调用参数

### 5.2 环境变量配置

```bash
# LiteLLM 配置
LITELLM_MODEL_MAIN=gpt-4o
LITELLM_API_KEY=sk-xxx
LITELLM_BASE_URL=https://api.openai.com/v1

# 限流配置（可选）
LITELLM_RPM_LIMIT=100
LITELLM_TPM_LIMIT=10000

# 超时配置
LITELLM_TIMEOUT=30
```

### 5.3 数据库用户激活配置（由后端 API 服务读取）

后端 API 服务从 `user_model_configs` 表加载当前激活配置：

| 字段 | 用途 | 优先级 |
|------|------|--------|
| main_model | 主模型标识 | 覆盖环境变量 |
| main_model_base_url | 主模型自定义端点 | 覆盖环境变量 |
| main_model_api_key_encrypted | 主模型 API Key | 覆盖环境变量 |

后端完成读取、解密和优先级合并后，应向网关传入如下运行时配置对象：

```python
class GatewayModelConfig(BaseModel):
    model: str
    api_base: str | None = None
    api_key: str | None = None
    timeout_seconds: float | None = None
    extra_headers: dict | None = None
```

其中：

- 阶段一到阶段二中，统一 Agentic 调用默认传入当前激活的主模型配置对象
- Phase 3 如启用双模型串联，再为特定场景传入专用命令生成模型配置对象
- `model` 必须已经是 LiteLLM 可识别的模型标识，如 `openai/gpt-4o` 或 `openai/Qwen3.5-35B-A3B-UD-Q6_K_S.gguf`

### 5.4 配置加密

```python
def resolve_gateway_model_config(user_id: str, interface: str) -> GatewayModelConfig:
    """后端 API 服务负责读取、解密并组装网关运行时配置"""
    user_config = load_active_user_model_config_from_db(user_id)
    defaults = load_default_config_from_env()

    model = user_config.main_model or defaults.main_model
    api_base = user_config.main_model_base_url or defaults.main_model_base_url
    api_key = decrypt(user_config.main_model_api_key_encrypted) if user_config.main_model_api_key_encrypted else defaults.main_model_api_key

    return GatewayModelConfig(
        model=normalize_model_identifier(model, api_base),
        api_base=api_base,
        api_key=api_key,
        timeout_seconds=defaults.timeout_seconds,
    )
```

---

## 6. 模型路由与降级策略

### 6.1 路由规则

统一 Agentic 调用使用同一模型，Phase 1 无需按场景路由：

| 调用场景 | 目标模型 | 说明 |
|----------|----------|------|
| 统一流式 Agentic 调用 | main_model | 优先选择用户配置，其次默认 |

### 6.2 降级策略

```python
class ModelRouter:
    """模型路由与降级"""

    FALLBACK_MODELS = {
        "gpt-4o": "gpt-4o-mini",
    }

    async def route(
        self,
        user_id: str
    ) -> str:
        """路由到合适的模型（单一 Agentic 调用，不区分接口）"""
        primary = await self._get_primary_model(user_id)
        if await self._check_model_available(primary):
            return primary
        else:
            fallback = self.FALLBACK_MODELS.get(primary)
            if fallback:
                logger.warning(f"Model {primary} unavailable, fallback to {fallback}")
                return fallback
            else:
                raise LLMGatewayError(f"Model {primary} unavailable and no fallback")
```

### 6.3 健康检查

```python
async def _check_model_available(model: str, api_key: str) -> bool:
    """检查模型是否可用"""
    try:
        response = await litellm.acompletion(
            model=model,
            messages=[{"role": "user", "content": "test"}],
            api_key=api_key,
            max_tokens=1
        )
        return True
    except Exception as e:
        logger.error(f"Model health check failed: {e}")
        return False
```

---

## 7. 流式转发规则

### 7.1 流式转发流程

```mermaid
sequenceDiagram
    participant API as 后端 API
    participant Gateway as 大模型网关
    participant LiteLLM as LiteLLM
    participant Model as 模型服务
    participant SSE as SSE 推送

    API->>Gateway: agentic_completion_stream 请求
    Gateway->>LiteLLM: acompletion_stream（含 compiled tools）
    LiteLLM->>Model: HTTP SSE
    Model-->>LiteLLM: stream chunks（text + tool_calls）
    loop 逐块转发
        LiteLLM-->>Gateway: chunk
        Gateway->>Gateway: 解析 delta.content / delta.tool_calls
        Gateway->>Gateway: ToolCallAssembler 拼装校验
        Gateway-->>API: AsyncGenerator[StreamChunk]
        API->>SSE: 推送到前端
    end
    Gateway-->>API: StateChunk(state="completed"/"pending_approval")
```

### 7.2 Chunk 转换规则

| LiteLLM Chunk 字段 | 内部 StreamChunk 类型 | 转换规则 |
|--------------------|----------------------|----------|
| `delta.content`（非空） | `TextDeltaChunk` | 直接映射 `delta` 字段 |
| `delta.tool_calls[i]`（含 `function.name`） | `ToolCallStartChunk` | 提取 `tool_call_id`、`function_name` |
| `delta.tool_calls[i].function.arguments`（增量） | `ToolCallArgsDeltaChunk` | 提取 `tool_call_id`、`args_delta` |
| `finish_reason == "tool_calls"` | `ToolCallCompleteChunk`（全部）+ `StateChunk("pending_approval")` | 触发 ToolCallAssembler 完成拼装校验 |
| `finish_reason == "stop"` | `StateChunk("completed")` | 文本流正常结束 |
| 异常 | `ErrorChunk` + `StateChunk("failed")` | 携带错误码和错误信息 |

### 7.3 保序与去重

- **文本保序**：前端按 `TextDeltaChunk` 到达顺序拼接
- **Tool call 按 ID 重组**：同一 `tool_call_id` 的 `ArgsDelta` 按到达顺序累积
- **容错**：乱序时缓存并按 `tool_call_id` 重组

---

## 8. 错误处理与可观察性

### 8.1 错误分类

| 错误类型 | 异常类 | HTTP 状态码 | 处理策略 |
|----------|--------|-------------|----------|
| API Key 无效 | `InvalidAPIKeyError` | 401 | 返回明确错误，不重试 |
| 模型不可用 | `ModelUnavailableError` | 503 | 降级或重试 1 次 |
| 超时 | `RequestTimeoutError` | 504 | 重试 1 次 |
| 限流 | `RateLimitError` | 429 | 延迟重试 |
| 响应格式非法 | `InvalidResponseError` | 502 | 记录日志，返回错误 |

### 8.2 日志记录

```python
class GatewayLogger:
    """网关日志记录"""

    async def log_llm_call(
        self,
        user_id: str,
        model: str,
        interface: str,
        request_tokens: int,
        response_tokens: int,
        latency_ms: int,
        success: bool,
        error: Optional[str] = None
    ):
        """记录每次模型调用"""
        await db.execute("""
            INSERT INTO llm_call_logs (
                user_id, model, interface,
                request_tokens, response_tokens,
                latency_ms, success, error,
                timestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, user_id, model, interface, request_tokens, response_tokens,
            latency_ms, success, error, datetime.utcnow())
```

### 8.3 成本统计

```python
class MetricsCollector:
    """成本与性能指标收集"""

    async def record_call(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int
    ):
        """记录 token 消耗与成本"""
        cost = self._calculate_cost(model, prompt_tokens, completion_tokens)
        await redis.incrby(f"cost:user:{user_id}:daily", cost)
        await redis.incrby(f"tokens:model:{model}:total", prompt_tokens + completion_tokens)
```

### 8.4 审计事件转发

```python
class GatewayAuditor:
    """审计事件转发"""

    async def log_llm_call(self, **kwargs):
        """转发到审计服务（AU1）"""
        await audit_service.log_event(
            task_id=kwargs.get("task_id"),
            user_id=kwargs["user_id"],
            event_type="llm_call",
            event_data={
                "model": kwargs["model"],
                "interface": kwargs["interface"],
                "request_tokens": kwargs["request_tokens"],
                "response_tokens": kwargs["response_tokens"],
                "latency_ms": kwargs["latency_ms"],
                "success": kwargs["success"]
            }
        )
```

---

## 9. 安全性与版本锁定要求

### 9.1 LiteLLM 版本锁定（强制）

根据 `ROADMAP.md §5.3` 和 `ARCHITECTURE.md §5.2` 的安全要求：

**必须在 `requirements.txt` 中锁定完整版本号：**

```txt
litellm==1.x.x  # 具体版本号，禁止使用 >= 或无版本号
```

**使用哈希验证包完整性：**

```bash
pip install --require-hashes -r requirements.txt
```

**在 `requirements.txt` 中添加哈希：**

```txt
litellm==1.x.x \
    --hash=sha256:abc123... \
    --hash=sha256:def456...
```

### 9.2 安全检查清单

- [ ] 在 `requirements.txt` 中锁定 LiteLLM 完整版本号
- [ ] 使用 `pip install --require-hashes` 验证包完整性
- [ ] 从官方源安装（PyPI），不使用第三方镜像
- [ ] 定期检查 LiteLLM 版本变更日志与社区安全通告
- [ ] 定期更新到受支持的安全版本，但不自动升级
- [ ] 在 AGENTS.md 中记录 LiteLLM 版本更新决策

### 9.3 API Key 安全存储

- **禁止**在代码中硬编码 API Key
- **禁止**在日志中记录明文 API Key
- **必须**加密存储在数据库（`user_model_configs` 表）
- **必须**使用 Fernet 对称加密
- **必须**从环境变量加载加密密钥（`CREDENTIAL_ENCRYPTION_KEY`）

### 9.4 用户隔离

- **必须**在所有查询中带 `user_id` 过滤
- **必须**验证用户对模型配置的访问权限
- **禁止**跨用户共享模型配置

---

## 10. 分阶段实施计划

### 10.1 Phase 1：统一流式 Agentic 调用（最小可用）

**目标：**打通统一 Agentic 流式调用链路

**交付物：**

- [ ] 实现 `core/gateway.py` 基础网关类
- [ ] 实现 `interfaces/agentic_streaming.py` 统一流式 Agentic 调用
- [ ] 实现 `utils/tool_call_assembler.py` Tool Call 拼装与校验
- [ ] 实现配置加载（环境变量 + 数据库）
- [ ] 实现基础日志记录
- [ ] 实现模型路由与降级（`routing/model_router.py`）
- [ ] 单元测试：mock LiteLLM 调用

**验收标准：**

- 可以通过统一 Agentic 接口流式获取文本和 tool_call
- Tool call 参数正确拼装并校验（有效 JSON / 无效 JSON 均可处理）
- 配置可以从数据库正确加载
- 日志正确记录到数据库
- 主模型不可用时自动降级

### 10.2 Phase 2：可观察性、优化与可选双模型串联

**目标：**完善监控与成本统计，并按需支持双模型串联

**交付物：**

- [ ] 实现审计事件转发（`observability/auditor.py`）
- [ ] 实现成本统计（`observability/metrics.py`）
- [ ] 实现限流（可选）
- [ ] 可选：为特定场景增加专用命令生成模型覆盖配置
- [ ] 性能测试与优化
- [ ] 压力测试

**验收标准：**

- 每次调用都有审计日志
- 成本统计准确
- 如启用双模型模式，未配置专用命令生成模型时仍可退回单一模型模式
- 支持 100 并发调用

---

## 11. 测试与验收清单

### 11.1 单元测试

| 模块 | 测试内容 | 覆盖率要求 |
|------|----------|------------|
| `core/gateway.py` | 初始化、配置加载 | 80% |
| `interfaces/agentic_streaming.py` | 统一 Agentic 流式解析、text/tool_call chunk 生成 | 90% |
| `utils/tool_call_assembler.py` | 参数片段累积、JSON 拼装校验、无效 JSON 处理 | 90% |
| `routing/model_router.py` | 路由、降级、健康检查 | 85% |
| `observability/logger.py` | 日志记录 | 80% |

### 11.2 集成测试

| 场景 | 测试步骤 | 预期结果 |
|------|----------|----------|
| 统一 Agentic 调用（文本） | 1. 调用 agentic_completion_stream<br>2. 不传 toolset 或传空工具集<br>3. 接收 TextDeltaChunk<br>4. 验证拼接 | 文本完整拼接 |
| 统一 Agentic 调用（tool_call） | 1. 调用 agentic_completion_stream<br>2. 传入 toolset<br>3. 接收 ToolCallStart/ArgsDelta/Complete<br>4. 验证拼装 | tool_call JSON 有效 |
| Tool call 无效 JSON | 1. 模拟返回无效 JSON 片段<br>2. 触发拼装完成 | ToolCallCompleteChunk(valid=False) |
| 多 tool_call 并发 | 1. 模拟多个 tool_call 同时返回<br>2. 验证独立拼装 | 每个 tool_call 独立完整 |
| 流式错误恢复 | 1. 模拟连接中断<br>2. 验证 ErrorChunk 发出 | ErrorChunk + StateChunk("failed") |
| 模型降级 | 1. 主模型不可用<br>2. 触发降级 | 使用备用模型 |
| 配置加载 | 1. 无用户配置<br>2. 使用默认 | 加载默认配置 |

### 11.3 端到端测试

| 场景 | 涉及模块 | 验收标准 |
|------|----------|----------|
| 用户消息 → Agentic 调用 | API → Gateway → LiteLLM | 模型返回 text_delta + tool_call |
| 流式 tool_call 推送 | Gateway → SSE → 前端 | 前端实时接收 tool_call 片段 |
| Tool call 拼装校验 | Gateway → 意图引擎 | 完整有效的 tool_call 传递给意图引擎 |
| 审计日志记录 | Gateway → 审计服务 | 所有调用都有日志 |

### 11.4 性能测试

| 指标 | 目标值 | 测试方法 |
|------|--------|----------|
| Agentic 调用首字节延迟 | P95 < 1s | 流式测试 |
| Tool call 拼装延迟 | P95 < 50ms | 单元测试 |
| 并发支持 | 100 QPS | 压力测试 |
| 流式并发 | 50 并发 | 流式压力测试 |

### 11.5 安全测试

| 检查项 | 验证方法 | 通过标准 |
|--------|----------|----------|
| LiteLLM 版本锁定 | 检查 requirements.txt | 有完整版本号 |
| API Key 加密存储 | 检查数据库 | BLOB 字段非明文 |
| 用户隔离 | 跨用户测试 | 无法访问他人配置 |
| 审计日志完整性 | 检查日志记录 | 所有调用都有记录 |

---

## 12. 常见问题与最佳实践

### 12.1 常见问题

**Q1: LiteLLM 调用超时怎么办？**

A: 设置合理的超时时间（默认 30s），超时后重试 1 次，仍失败则返回错误给调用方。

**Q2: 流式输出中断怎么办？**

A: 记录错误日志，发送 `ErrorChunk` + `StateChunk(state="failed")`，前端展示错误并提示用户重试。

**Q3: 如何选择当前模型配置？**

A: 阶段一到阶段二建议优先选择一个同时支持 function calling 和流式输出的模型（如 GPT-4o）。Phase 2 如确有成本或效果需求，再为特定场景增加专用模型覆盖。

**Q4: 用户自定义的 base_url 如何处理？**

A: 优先使用用户配置的 `base_url`，如为空则使用环境变量配置的默认值。

### 12.2 最佳实践

1. **始终锁定 LiteLLM 版本**
   - 在 `requirements.txt` 中明确版本号
   - 定期检查安全更新，手动升级

2. **所有敏感信息加密存储**
   - API Key 必须加密
   - 日志中不记录明文敏感信息

3. **完善的错误处理**
   - 区分可重试错误和不可重试错误
   - 记录详细的错误日志

4. **审计日志不可遗漏**
   - 每次模型调用都要记录
   - 包含 token 消耗、耗时、成功失败状态

5. **用户数据隔离**
   - 所有查询带 user_id
   - 验证用户对配置的访问权限

---

## 13. 参考资料与依赖

### 13.1 官方文档

- [LiteLLM 官方文档](https://docs.litellm.ai/)
- [OpenAI API 文档](https://platform.openai.com/docs/api-reference)
- [FastAPI 异步编程](https://fastapi.tiangolo.com/async/)

### 13.2 内部文档

- `ROADMAP.md §5.3`：大模型网关职责定义
- `ARCHITECTURE.md §3.1`：网关组件边界
- `API_SPEC.md §3.1`：统一流式 Agentic 调用接口定义
- `TOOLS_SPEC.md §2`：主模型提示词规范

### 13.3 依赖库

```txt
# 核心
litellm==1.x.x  # 必须锁定版本
fastapi>=0.100.0
pydantic>=2.0.0

# 异步
aiohttp>=3.8.0
asyncio>=3.4.3

# 数据库
aiosqlite>=0.20.0  # SQLite 异步驱动

# 加密
cryptography>=41.0.0  # Fernet 加密

# 日志
loguru>=0.7.0

# 测试
pytest>=7.4.0
pytest-asyncio>=0.21.0
pytest-mock>=3.11.0
```

---

## 附录 A：配置文件示例

### A.1 `litellm_config.example.yaml`

```yaml
# LiteLLM 配置示例（不包含敏感信息）
model_list:
  - model_name: gpt-4o
    litellm_params:
      model: openai/gpt-4o
      api_key: os.environ/LITELLM_API_KEY
      base_url: os.environ/LITELLM_BASE_URL

  - model_name: gpt-4o-mini
    litellm_params:
      model: openai/gpt-4o-mini
      api_key: os.environ/LITELLM_API_KEY
      base_url: os.environ/LITELLM_BASE_URL

litellm_settings:
  drop_params: true  # 删除不支持的参数
  set_verbose: false  # 生产环境关闭详细日志
  success_callback: ["langfuse"]  # 可选：集成 Langfuse

# 限流配置（可选）
litellm_logging:
  fallbacks:
    - gpt-4o: gpt-4o-mini
```

---

## 附录 B：错误代码定义

| 错误代码 | HTTP 状态码 | 说明 | 处理建议 |
|----------|-------------|------|----------|
| `GATEWAY_INVALID_API_KEY` | 401 | API Key 无效 | 检查用户配置 |
| `GATEWAY_MODEL_UNAVAILABLE` | 503 | 模型不可用 | 触发降级 |
| `GATEWAY_TIMEOUT` | 504 | 请求超时 | 重试 1 次 |
| `GATEWAY_RATE_LIMIT` | 429 | 超过限流 | 延迟重试 |
| `GATEWAY_INVALID_RESPONSE` | 502 | 响应格式非法 | 记录日志，返回错误 |
| `GATEWAY_CONFIG_NOT_FOUND` | 404 | 配置不存在 | 加载默认配置 |

---

## 附录 C：验收检查表

### C.1 代码质量检查

- [ ] 所有函数都有类型注解
- [ ] 所有公开接口都有 docstring
- [ ] 单元测试覆盖率 >= 80%
- [ ] 通过 `ruff` 或 `black` 代码风格检查
- [ ] 通过 `mypy` 类型检查

### C.2 安全检查

- [ ] LiteLLM 版本已锁定
- [ ] API Key 加密存储
- [ ] 日志中无明文敏感信息
- [ ] 用户隔离正确实现
- [ ] 审计日志完整

### C.3 功能检查

- [ ] 统一流式 Agentic 调用接口已实现
- [ ] Tool call 拼装与校验正确
- [ ] 流式输出正确转发
- [ ] 配置加载优先级正确
- [ ] 模型降级策略生效
- [ ] 错误处理完善

### C.4 性能检查

- [ ] 响应时间符合目标
- [ ] 并发支持符合目标
- [ ] 无内存泄漏
- [ ] 无连接泄漏

---

**文档版本：** v2.0
**最后更新：** 2026-04-23
**维护者：** 后端开发团队
**变更记录：**
- v2.0 (2026-04-23): 对齐流式 Agentic 架构，合并 LG1/LG2/LG3 为统一 Agentic 调用
- v1.0 (2026-04-14): 初始版本，对齐 ROADMAP、ARCHITECTURE、API_SPEC、TOOLS_SPEC
