"""LLM Gateway FastAPI 路由。"""

from __future__ import annotations

from collections.abc import AsyncIterator
from inspect import isawaitable
from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from .exceptions import GatewayError, normalize_exception
from .gateway import LLMGateway
from .models import ChatCompletionEnvelope, ChatCompletionRequest, ErrorResponse, HealthResponse

router = APIRouter(prefix="/api/v1/llm", tags=["llm-gateway"])

_gateway = LLMGateway()


def get_gateway() -> LLMGateway:
    return _gateway


@router.get("/health", response_model=HealthResponse)
async def health_check(
    gateway: Annotated[LLMGateway, Depends(get_gateway)],
) -> HealthResponse:
    return await gateway.health_check()


@router.post("/chat/completions", response_model=ChatCompletionEnvelope)
async def chat_completion(
    request: ChatCompletionRequest,
    gateway: Annotated[LLMGateway, Depends(get_gateway)],
) -> ChatCompletionEnvelope:
    result = await gateway.chat_completion(request)
    return ChatCompletionEnvelope(result=result)


@router.post("/chat/completions/stream")
async def chat_completion_stream(
    request: ChatCompletionRequest,
    gateway: Annotated[LLMGateway, Depends(get_gateway)],
) -> StreamingResponse:
    async def generate() -> AsyncIterator[str]:
        try:
            stream_or_awaitable = gateway.chat_completion_stream(request)
            if isawaitable(stream_or_awaitable):
                stream = await stream_or_awaitable
            else:
                stream = stream_or_awaitable

            async for chunk in stream:
                yield chunk.model_dump_json() + "\n"
        except GatewayError as exc:
            yield exc.to_response().model_dump_json() + "\n"
        except Exception as exc:  # noqa: BLE001
            payload = ErrorResponse.model_validate(normalize_exception(exc).to_response())
            yield payload.model_dump_json() + "\n"

    return StreamingResponse(generate(), media_type="application/x-ndjson")
