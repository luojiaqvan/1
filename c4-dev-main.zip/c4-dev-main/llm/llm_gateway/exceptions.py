"""LLM Gateway 统一错误定义。"""

from __future__ import annotations

from typing import Any

from .models import ErrorResponse


class GatewayError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        details: Any | None = None,
        status_code: int = 500,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details
        self.status_code = status_code

    def to_response(self) -> ErrorResponse:
        return ErrorResponse(
            code=self.code,
            message=self.message,
            details=self.details,
        )


def normalize_exception(exc: Exception) -> GatewayError:
    if isinstance(exc, GatewayError):
        return exc

    if isinstance(exc, TimeoutError):
        return GatewayError(
            "upstream_timeout",
            "大模型调用超时",
            details={
                "error_type": exc.__class__.__name__,
                "reason": str(exc),
            },
            status_code=504,
        )

    return GatewayError(
        "upstream_llm_error",
        "大模型调用失败",
        details={
            "error_type": exc.__class__.__name__,
            "reason": str(exc),
        },
        status_code=502,
    )
