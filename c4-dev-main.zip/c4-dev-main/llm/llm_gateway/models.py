"""LLM Gateway 请求/响应 Schema。"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ErrorResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    details: Any | None = None


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    status: Literal["ok"] = "ok"
    service: str = "llm_gateway"
    default_model: str
    provider_configured: bool


class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="forbid")

    role: Literal["system", "user", "assistant", "tool"]
    content: str | None = None
    name: str | None = None
    tool_call_id: str | None = None


class GatewayModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    model: str = Field(min_length=1)
    api_base: str | None = None
    api_key: str | None = None
    timeout_seconds: float | None = Field(default=None, gt=0)
    extra_headers: dict[str, str] | None = None


class ChatCompletionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    runtime_model_config: GatewayModelConfig = Field(alias="model_config")
    messages: list[ChatMessage] = Field(min_length=1)
    tools: list[dict[str, Any]] | None = None
    response_format: dict[str, Any] | None = None
    user_id: str | None = None
    temperature: float | None = None
    max_tokens: int | None = Field(default=None, gt=0)
    timeout_seconds: float | None = Field(default=None, gt=0)


class ChatCompletionEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")

    result: dict[str, Any]


class StreamChunk(BaseModel):
    model_config = ConfigDict(extra="forbid")

    delta: str
    done: bool
    index: int
