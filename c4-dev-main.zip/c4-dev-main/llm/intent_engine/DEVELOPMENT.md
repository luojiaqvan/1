# 意图引擎开发文档

## 1. 文档说明

### 1.1 目的与范围

本文档是 `llm/intent_engine` 模块的阶段一开发文档，用于约束该模块在单模型 agentic 模式下的最小职责、目录结构与实现边界。

**本文档目标读者：**
- 负责实现 `llm/intent_engine` 的后端开发者
- 需要对接意图卡片、授权卡片、执行门控的协作模块开发者
- 后续维护阶段一结构化收口链路的开发者

**本文档范围：**
- 明确模块在阶段一的存在必要性与职责边界
- 说明本模块仅保留的两项核心功能
- 给出目录结构骨架与推荐文件拆分
- 规定与前端展示、工具层、MCP、设备管理程序之间的对接边界

**本文档不包含：**
- 主模型提示词工程细节（见 `docs/TOOLS_SPEC.md`）
- 大模型网关实现细节（见 `llm/llm_gateway/DEVELOPMENT.md`）
- 设备连接与命令执行实现细节（见 `docs/API_SPEC.md §3.3`）

### 1.2 与权威文档的关系

| 文档 | 权威内容 | 本模块如何引用 |
|------|----------|----------------|
| `docs/ROADMAP.md` | 阶段一主路径、模块职责边界 | 作为模块定位与验收边界依据 |
| `docs/ARCHITECTURE.md` | 组件协作、核心数据流、系统分层 | 作为依赖方向与流程边界依据 |
| `docs/API_SPEC.md §3.2` | IE1 / IE3 接口契约、SSE 事件来源 | 作为输入输出结构依据 |
| `docs/TOOLS_SPEC.md` | `parse_intent` / `generate_commands` 工具约束 | 作为上游模型输出约束依据 |
| `AGENTS.md` | 协作规则与文档风格 | 作为开发过程约束 |

---

## 2. 模块存在的必要性

阶段一虽然采用**单模型、单上下文、流式 agentic 调用**，由同一模型完成思考、工具选择、知识检索、候选命令生成与结果总结，但 `llm/intent_engine` 仍然有保留必要。

原因不是为了再做一层“第二个 agent”，而是为了提供系统侧的**结构化收口**：

1. **前端不能直接消费模型原始输出**
   - 意图卡片必须基于稳定、标准化的 `intent` 对象渲染
   - 授权卡片必须基于冻结后的候选命令 proposal 渲染

2. **执行层不能直接消费模型原始 tool_call**
   - 实际执行前，必须确认候选命令已完成结构校验、来源校验、风险校验与 proposal 冻结
   - `execute_command` / `DM7` 只能消费已通过门控的 proposal

3. **系统需要可审计的边界对象**
   - 从“模型说了什么”切换到“系统认可了什么”必须有一个明确收口点
   - 否则前端展示、用户确认和最终执行之间无法保证一致性

因此，阶段一的 `llm/intent_engine` 应定位为：

> **主模型输出的系统侧收口模块，而不是独立的多轮规划器或执行编排器。**

---

## 3. 阶段一保留的核心功能

阶段一只保留以下两项核心功能。

### 3.1 功能 1：意图标准化

将主模型通过 `parse_intent` 或等价 tool_call 返回的原始意图对象，转换为系统内统一的标准化意图。

**输入来源：**
- 用户消息上下文
- 主模型原始意图结果
- 用户可用设备列表 / 已指定设备上下文

**输出目标：**
- 生成稳定的 `intent` 对象
- 供前端渲染 `intent_card`
- 供后续候选命令 proposal 校验时复用

**最小输出字段：**
- `operation_type`
- `target_type`
- `target_devices`
- `scope`
- `risk_level`
- `description`
- `constraints`
- `pre_checks`
- `expected_result`
- `rollback_plan`

**阶段一边界：**
- 负责把模型结果标准化
- 不负责重新推理用户意图
- 不负责替代模型做知识检索或命令生成

### 3.2 功能 3：候选命令组装与校验

将 `generate_commands` 的原始输出收口为系统认可的冻结 proposal，并执行进入前端授权和后端执行前的基础校验。

**输入来源：**
- IE1 输出的标准化意图
- `generate_commands` 原始 tool_call 参数
- `knowledge_refs`
- 设备上下文

**输出目标：**
- 生成可审计、可展示、可执行门控的 `proposal`
- 供前端渲染 `command_card`
- 供执行层在用户确认后调用

**阶段一至少要做的校验：**
- 参数结构校验
- 目标设备存在性校验
- `generation_basis` 可追溯性校验
- 模式校验（`knowledge_grounded_model / template_fallback`）
- 基础风险汇总

**冻结要求：**
- 前端展示必须基于冻结后的 proposal
- 用户确认必须绑定 `proposal_id`
- 实际执行必须消费同一个 proposal，而不是重新解释模型输出

---

## 4. 阶段一不负责的事项

以下职责不属于阶段一 `llm/intent_engine`：

- 不负责知识检索主流程编排
- 不负责候选命令生成本身
- 不负责执行编排、结果回收、失败处理
- 不直接持有设备连接
- 不直接调用 SSH / Telnet / netmiko
- 不替代 `backend/device_manager` 的权威执行契约

换言之，阶段一的它只处理：

> **“模型输出怎么收口为系统对象”**

而不处理：

> **“命令如何真正执行”**

---

## 5. 对外接口建议

阶段一推荐只暴露两个核心入口：

### 5.1 `parse_intent(...)`

职责：
- 标准化原始意图
- 返回前端与后续 proposal 校验可直接复用的 `intent`

### 5.2 `assemble_and_validate_candidates(...)`

职责：
- 收口 `generate_commands` 输出
- 生成冻结 proposal
- 返回校验结果与风险摘要

建议不要在阶段一暴露额外的“执行命令”接口给本模块，避免再次把执行职责拉回 `llm/intent_engine`。

---

## 6. 目录结构骨架

推荐目录结构如下：

```text
llm/intent_engine/
├── __init__.py
├── DEVELOPMENT.md                  # 本文档
├── core/
│   ├── __init__.py
│   ├── models.py                   # intent / proposal / validation 数据模型
│   ├── exceptions.py               # 模块异常定义
│   └── service.py                  # 模块门面，导出 parse_intent / assemble_and_validate_candidates
├── parsers/
│   ├── __init__.py
│   └── intent_parser.py            # 原始意图 -> 标准化 intent
├── proposals/
│   ├── __init__.py
│   ├── assembler.py                # 原始 generate_commands -> proposal 组装
│   ├── freezer.py                  # proposal 冻结与 proposal_id 生成
│   └── validator.py                # proposal 基础校验与风险汇总
├── adapters/
│   ├── __init__.py
│   └── frontend_mapper.py          # intent/proposal -> 前端卡片对象映射
├── prompts/
│   └── system_prompt.txt           # 预留；阶段一不把业务逻辑放在这里
└── vendor/
    └── ...                         # 厂商相关辅助能力（按需扩展）
```

---

## 7. 与其他模块的边界

### 7.1 与前端

- 前端的 `intent_card` 必须基于 IE1 输出渲染
- 前端的授权卡片必须基于冻结 proposal 渲染
- 前端不得直接解析模型原始 `generate_commands` tool_call 来生成最终授权对象

### 7.2 与工具层 / MCP

- `generate_commands` 只负责提交候选命令，不具备执行权
- `execute_command` 在网络设备场景下必须消费已冻结且已确认的 proposal
- MCP 只能封装连接发现与执行路由，不得跳过本模块直接执行模型原始输出

### 7.3 与设备管理程序

- `backend/device_manager` 仍是权威执行实现
- 本模块只负责把候选命令收口为可执行门控对象
- 不负责连接池、凭据、超时、重试、命令执行细节

---

## 8. 阶段一实现顺序建议

1. 先完成 `intent` 数据模型与 `parse_intent`
2. 再完成 `proposal` 数据模型与 `assemble_and_validate_candidates`
3. 然后打通前端 `intent_parsed` / `approval_required` 的消费对象
4. 最后在执行层接入“只接受已确认 proposal”的门控约束

验收时至少确认：

- 前端不再直接消费模型原始意图对象
- 前端不再直接消费原始 `generate_commands` tool_call
- 用户确认绑定 `proposal_id`
- 实际执行前明确使用冻结 proposal
