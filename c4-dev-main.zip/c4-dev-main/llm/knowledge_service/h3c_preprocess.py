from __future__ import annotations

import json
import html
from html.parser import HTMLParser
import re
import shutil
import subprocess
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from openpyxl import load_workbook
from pypdf import PdfReader


REPO_ROOT = Path(__file__).resolve().parents[2]
H3C_DOCS_ROOT = REPO_ROOT / "参考项目" / "h3c_docs"
RAW_ROOT = H3C_DOCS_ROOT / "raw"
PROCESSED_ROOT = H3C_DOCS_ROOT / "processed"

INVENTORY_DIR = PROCESSED_ROOT / "inventory"
EXTRACTED_DIR = PROCESSED_ROOT / "extracted"
CLEANED_DIR = PROCESSED_ROOT / "cleaned"
CHUNKS_DIR = PROCESSED_ROOT / "chunks"
READY_DIR = PROCESSED_ROOT / "ready"
UNPACKED_DIR = PROCESSED_ROOT / "unpacked"
LOGS_DIR = PROCESSED_ROOT / "logs"
PACKAGES_DIR = PROCESSED_ROOT / "packages"

INVENTORY_PATH = INVENTORY_DIR / "h3c_raw_inventory.jsonl"
PROCESSING_CANDIDATES_PATH = INVENTORY_DIR / "h3c_processing_candidates.json"
FIRST_BATCH_SELECTION_PATH = INVENTORY_DIR / "h3c_first_batch_selection.json"
READY_JSONL_PATH = READY_DIR / "h3c_first_batch_ready.jsonl"
READY_SUMMARY_PATH = READY_DIR / "h3c_first_batch_ready.summary.json"
UNPACKED_SUMMARY_PATH = INVENTORY_DIR / "h3c_unpacked_archives.summary.json"
LOG_MEMBER_SUMMARY_PATH = INVENTORY_DIR / "h3c_log_members.summary.json"
LOG_READY_JSONL_PATH = READY_DIR / "h3c_log_ready.jsonl"
LOG_READY_SUMMARY_PATH = READY_DIR / "h3c_log_ready.summary.json"
PACKAGE_MEMBER_SUMMARY_PATH = INVENTORY_DIR / "h3c_package_members.summary.json"
PACKAGE_READY_JSONL_PATH = READY_DIR / "h3c_package_ready.jsonl"
PACKAGE_READY_SUMMARY_PATH = READY_DIR / "h3c_package_ready.summary.json"
ALL_PDF_SELECTION_PATH = INVENTORY_DIR / "h3c_all_pdf_selection.json"
ALL_PDF_READY_JSONL_PATH = READY_DIR / "h3c_all_pdf_ready.jsonl"
ALL_PDF_READY_SUMMARY_PATH = READY_DIR / "h3c_all_pdf_ready.summary.json"


COMMAND_SUBTYPE_KEYWORDS = (
    "命令参考",
)
CONFIG_SUBTYPE_KEYWORDS = (
    "配置指导",
)
TROUBLESHOOTING_SUBTYPE_KEYWORDS = (
    "故障处理",
)

PREFERRED_FIRST_BATCH = {
    "command": {
        "product_category": "switches",
        "product_family": "s5135s-ei",
        "doc_subtype_contains": "基础配置命令参考",
    },
    "config": {
        "product_category": "routers",
        "product_family": "msr-1000s",
        "doc_subtype_contains": "IP路由配置指导",
    },
    "troubleshooting": {
        "product_category": "security",
        "product_family": "secpath-f1000",
        "doc_type": "故障处理手册",
    },
}

FRONT_MATTER_KEYWORDS = (
    "前 言",
    "前  言",
    "读者对象",
    "本书约定",
    "资料意见反馈",
    "更多资料内容",
    "图形界面格式约定",
    "命令行格式约定",
    "各类标志",
    "图标约定",
    "示例约定",
)


@dataclass(slots=True)
class InventoryRecord:
    artifact_id: str
    source_manifest_path: str
    vendor: str
    product_category: str
    product_family: str
    release: str
    collection_available: bool
    doc_group: str
    doc_type: str
    doc_subtype: str
    title: str
    source_page_url: str
    catalog_page_url: str
    download_url: str
    download_id: int | None
    original_file_name: str
    stored_file_name: str
    stored_relative_path: str
    absolute_path: str
    file_size_bytes: int | None
    fetched_method: str
    fetched_at: str
    exists: bool
    extension: str
    processing_priority: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_id": self.artifact_id,
            "source_manifest_path": self.source_manifest_path,
            "vendor": self.vendor,
            "product_category": self.product_category,
            "product_family": self.product_family,
            "release": self.release,
            "collection_available": self.collection_available,
            "doc_group": self.doc_group,
            "doc_type": self.doc_type,
            "doc_subtype": self.doc_subtype,
            "title": self.title,
            "source_page_url": self.source_page_url,
            "catalog_page_url": self.catalog_page_url,
            "download_url": self.download_url,
            "download_id": self.download_id,
            "original_file_name": self.original_file_name,
            "stored_file_name": self.stored_file_name,
            "stored_relative_path": self.stored_relative_path,
            "absolute_path": self.absolute_path,
            "file_size_bytes": self.file_size_bytes,
            "fetched_method": self.fetched_method,
            "fetched_at": self.fetched_at,
            "exists": self.exists,
            "extension": self.extension,
            "processing_priority": self.processing_priority,
        }


def ensure_output_directories() -> None:
    for directory in (INVENTORY_DIR, EXTRACTED_DIR, CLEANED_DIR, CHUNKS_DIR, READY_DIR, UNPACKED_DIR, LOGS_DIR, PACKAGES_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def iter_manifest_paths(raw_root: Path = RAW_ROOT) -> list[Path]:
    return sorted(raw_root.rglob("manifest.json"))


def classify_processing_priority(doc_group: str, doc_type: str, extension: str) -> str:
    if extension != ".pdf":
        return "deferred"
    if doc_type == "命令参考":
        return "highest"
    if doc_type == "配置指导" or doc_group == "troubleshooting":
        return "high"
    if doc_group == "log":
        return "medium"
    if doc_group == "package":
        return "low"
    return "medium"


def build_inventory(raw_root: Path = RAW_ROOT) -> list[InventoryRecord]:
    records: list[InventoryRecord] = []
    for manifest_path in iter_manifest_paths(raw_root):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for artifact in manifest.get("artifacts", []):
            relative_path = artifact["stored_relative_path"]
            absolute_path = H3C_DOCS_ROOT / relative_path
            extension = absolute_path.suffix.lower()
            priority = classify_processing_priority(
                doc_group=artifact.get("doc_group", ""),
                doc_type=artifact.get("doc_type", ""),
                extension=extension,
            )
            download_id = artifact.get("download_id")
            artifact_id = f"{manifest['product_category']}-{manifest['product_family']}-{manifest['release']}-{download_id or artifact['stored_file_name']}"
            records.append(
                InventoryRecord(
                    artifact_id=artifact_id,
                    source_manifest_path=str(manifest_path.relative_to(H3C_DOCS_ROOT)).replace("\\", "/"),
                    vendor=manifest["vendor"],
                    product_category=manifest["product_category"],
                    product_family=manifest["product_family"],
                    release=manifest["release"],
                    collection_available=bool(manifest.get("collection_available", False)),
                    doc_group=artifact.get("doc_group", ""),
                    doc_type=artifact.get("doc_type", ""),
                    doc_subtype=artifact.get("doc_subtype", ""),
                    title=artifact.get("title", ""),
                    source_page_url=artifact.get("source_page_url", ""),
                    catalog_page_url=artifact.get("catalog_page_url", ""),
                    download_url=artifact.get("download_url", ""),
                    download_id=download_id,
                    original_file_name=artifact.get("original_file_name", ""),
                    stored_file_name=artifact.get("stored_file_name", ""),
                    stored_relative_path=relative_path,
                    absolute_path=str(absolute_path),
                    file_size_bytes=artifact.get("file_size_bytes"),
                    fetched_method=artifact.get("fetched_method", ""),
                    fetched_at=artifact.get("fetched_at", ""),
                    exists=absolute_path.exists(),
                    extension=extension,
                    processing_priority=priority,
                )
            )
    return records


def write_inventory(records: list[InventoryRecord]) -> None:
    ensure_output_directories()
    INVENTORY_PATH.write_text(
        "\n".join(json.dumps(record.to_dict(), ensure_ascii=False) for record in records) + "\n",
        encoding="utf-8",
    )
    priority_counter = Counter(record.processing_priority for record in records)
    candidates = {
        "total_artifacts": len(records),
        "by_priority": dict(priority_counter),
        "pdf_candidates": [record.to_dict() for record in records if record.extension == ".pdf"],
    }
    PROCESSING_CANDIDATES_PATH.write_text(json.dumps(candidates, ensure_ascii=False, indent=2), encoding="utf-8")


def find_archive_tool() -> str | None:
    seven_zip = shutil.which("7z")
    if seven_zip:
        return seven_zip
    common_path = Path("C:/Program Files/7-Zip/7z.EXE")
    if common_path.exists():
        return str(common_path)
    return None


def classify_unpacked_member(path_text: str, is_dir: bool) -> str:
    if is_dir:
        return "directory"
    suffix = Path(path_text).suffix.lower()
    if suffix == ".pdf":
        return "pdf"
    if suffix in {".xls", ".xlsx", ".csv"}:
        return "excel"
    if suffix == ".chm":
        return "chm"
    if suffix in {".doc", ".docx", ".txt", ".md", ".html", ".htm", ".xml", ".json"}:
        return "document"
    return "other"


def parse_7z_slt_output(output: str) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    current: dict[str, str] = {}
    started = False
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line == "----------":
            started = True
            current = {}
            continue
        if not started or not line or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        current[key] = value
        if key == "NT Security":
            path_text = current.get("Path", "")
            is_dir = current.get("Folder", "-") == "+"
            if path_text:
                entries.append(
                    {
                        "path": path_text,
                        "is_dir": is_dir,
                        "size": int(current.get("Size", "0") or 0),
                        "packed_size": int(current.get("Packed Size", "0") or 0),
                        "modified": current.get("Modified", ""),
                        "routing_stream": classify_unpacked_member(path_text, is_dir),
                    }
                )
            current = {}
    return entries


def list_archive_members(archive_tool: str, archive_path: Path) -> list[dict[str, Any]]:
    result = subprocess.run(
        [archive_tool, "l", "-slt", str(archive_path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    return parse_7z_slt_output(result.stdout)


def unpack_output_dir(record: InventoryRecord) -> Path:
    directory = UNPACKED_DIR / record.product_category / record.product_family / record.release / output_stem(record)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def collect_unpacked_members(files_dir: Path) -> list[dict[str, Any]]:
    members: list[dict[str, Any]] = []
    if not files_dir.exists():
        return members
    for path in sorted(files_dir.rglob("*")):
        relative_path = str(path.relative_to(files_dir)).replace("\\", "/")
        is_dir = path.is_dir()
        size = 0 if is_dir else path.stat().st_size
        modified = path.stat().st_mtime
        members.append(
            {
                "path": relative_path,
                "is_dir": is_dir,
                "size": size,
                "modified_timestamp": modified,
                "routing_stream": classify_unpacked_member(relative_path, is_dir),
            }
        )
    return members


def sanitize_sheet_title(title: str) -> str:
    sanitized = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff_-]+", "_", title).strip("_")
    return sanitized or "sheet"


def normalize_excel_cell(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, str):
        return value.strip()
    return value


class TextExtractingHTMLParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.block_tags = {
            "p", "div", "br", "li", "ul", "ol", "table", "tr", "td", "th",
            "h1", "h2", "h3", "h4", "h5", "h6",
        }

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.block_tags:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.block_tags:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        text = data.strip()
        if text:
            self.parts.append(text)

    def get_text(self) -> str:
        raw = " ".join(self.parts)
        raw = html.unescape(raw)
        raw = re.sub(r"\n\s*\n+", "\n\n", raw)
        raw = re.sub(r"[ \t]+", " ", raw)
        return raw.strip()


def decode_html_file(path: Path) -> str:
    data = path.read_bytes()
    for encoding in ("gb18030", "utf-8", "utf-16"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def html_to_text(content: str) -> str:
    stripped = re.sub(r"<script.*?</script>", " ", content, flags=re.S | re.I)
    stripped = re.sub(r"<style.*?</style>", " ", stripped, flags=re.S | re.I)
    parser = TextExtractingHTMLParser()
    parser.feed(stripped)
    return parser.get_text()


def html_title_from_text(text: str, fallback: str) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if lines:
        return lines[0][:120]
    return fallback


def is_low_value_package_page(title: str, relative_path: str, text: str) -> bool:
    normalized_title = title.strip()
    normalized_path = relative_path.strip()
    compact_text = re.sub(r"\s+", " ", text).strip()

    if not compact_text:
        return True
    if "扉页.docx" in normalized_title or "扉页.docx" in normalized_path:
        return True
    if normalized_title.startswith("F:\\Split\\Temp\\"):
        return True
    if "产品文档集" in normalized_title and len(compact_text) < 250:
        return True
    if "导读" in normalized_title:
        return True
    if "导读" in compact_text and "内容简介" in compact_text and "手册名称" in compact_text:
        return True
    if "相关内容说明" in compact_text and len(compact_text) < 500:
        return True
    if "相关链接" in compact_text and "父主题：" in compact_text and len(compact_text) < 1200:
        return True
    nav_keywords = ("快速安装指南", "安装升级", "命令参考", "配置指导")
    if all(keyword in compact_text for keyword in nav_keywords) and len(compact_text) < 300:
        return True
    return False


def build_log_excel_ready_records(record: InventoryRecord, excel_summary: dict[str, Any], workbook_rows: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    ready_rows: list[dict[str, Any]] = []
    for sheet_title, rows in workbook_rows.items():
        for index, row in enumerate(rows, start=1):
            module = str(row.get("模块名称") or row.get("column_1") or "").strip()
            mnemonic = str(row.get("助记符") or row.get("column_3") or "").strip()
            composite = str(row.get("模块名称/等级/助记符") or "").strip()
            title = composite or mnemonic or module or f"{sheet_title}-{index}"
            content_parts = [
                f"模块名称: {module}" if module else "",
                f"等级: {row.get('等级')}" if row.get("等级") not in (None, "") else "",
                f"助记符: {mnemonic}" if mnemonic else "",
                f"日志内容: {row.get('日志内容')}" if row.get("日志内容") else "",
                f"日志含义: {row.get('日志含义')}" if row.get("日志含义") else "",
                f"系统影响: {row.get('系统影响')}" if row.get("系统影响") else "",
                f"日志产生原因: {row.get('日志产生原因')}" if row.get("日志产生原因") else "",
                f"日志参数: {row.get('日志参数')}" if row.get("日志参数") else "",
                f"处理建议: {row.get('处理建议')}" if row.get("处理建议") else "",
                f"举例: {row.get('举例')}" if row.get("举例") else "",
            ]
            content = "\n".join(part for part in content_parts if part).strip()
            if not content:
                continue
            ready = {
                "doc_id": f"h3c-{record.product_category}-{record.product_family}-{record.release}-log-excel-{len(ready_rows)+1:05d}",
                "vendor": record.vendor,
                "product_category": record.product_category,
                "product_family": record.product_family,
                "release": record.release,
                "doc_group": record.doc_group,
                "doc_type": record.doc_type,
                "doc_subtype": record.doc_subtype,
                "content_type": "log_entry",
                "title": title,
                "section_path": [sheet_title],
                "source_file": Path(excel_summary["member_path"]).name,
                "source_relative_path": excel_summary["member_path"],
                "source_page_url": record.source_page_url,
                "download_url": record.download_url,
                "language": "zh-CN",
                "content": content,
                "extra": {
                    "sheet": sheet_title,
                    "row_number": row.get("__row_number__"),
                    "module_name": module,
                    "level": row.get("等级"),
                    "mnemonic": mnemonic,
                    "log_pattern": row.get("日志内容"),
                    "meaning": row.get("日志含义"),
                    "recommended_action": row.get("处理建议"),
                    "example": row.get("举例"),
                },
            }
            validate_ready_record(ready)
            ready_rows.append(ready)
    return ready_rows


def build_log_html_ready_records(record: InventoryRecord, chm_summary: dict[str, Any], extracted_dir: Path) -> list[dict[str, Any]]:
    ready_rows: list[dict[str, Any]] = []
    html_files = sorted(list(extracted_dir.rglob("*.htm")) + list(extracted_dir.rglob("*.html")))
    for index, html_file in enumerate(html_files, start=1):
        text = html_to_text(decode_html_file(html_file))
        if len(text) < 20:
            continue
        relative_path = str(html_file.relative_to(extracted_dir)).replace("\\", "/")
        title = html_title_from_text(text, html_file.stem)
        ready = {
            "doc_id": f"h3c-{record.product_category}-{record.product_family}-{record.release}-log-html-{len(ready_rows)+1:05d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "log_doc",
            "title": title,
            "section_path": [relative_path],
            "source_file": Path(chm_summary["member_path"]).name,
            "source_relative_path": f"{chm_summary['member_path']}::{relative_path}",
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "zh-CN",
            "content": text,
            "extra": {
                "html_relative_path": relative_path,
                "member_type": "chm",
                "source_archive": record.stored_relative_path,
            },
        }
        validate_ready_record(ready)
        ready_rows.append(ready)
    return ready_rows


def build_package_html_ready_records(record: InventoryRecord, chm_summary: dict[str, Any], extracted_dir: Path) -> list[dict[str, Any]]:
    ready_rows: list[dict[str, Any]] = []
    html_files = sorted(list(extracted_dir.rglob("*.htm")) + list(extracted_dir.rglob("*.html")))
    for html_file in html_files:
        text = html_to_text(decode_html_file(html_file))
        if len(text) < 40:
            continue
        relative_path = str(html_file.relative_to(extracted_dir)).replace("\\", "/")
        title = html_title_from_text(text, html_file.stem)
        if is_low_value_package_page(title, relative_path, text):
            continue
        ready = {
            "doc_id": f"h3c-{record.product_category}-{record.product_family}-{record.release}-package-html-{len(ready_rows)+1:05d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "package_doc",
            "title": title,
            "section_path": [relative_path],
            "source_file": Path(chm_summary["member_path"]).name,
            "source_relative_path": f"{chm_summary['member_path']}::{relative_path}",
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "zh-CN",
            "content": text,
            "extra": {
                "html_relative_path": relative_path,
                "member_type": "package_chm",
                "source_archive": record.stored_relative_path,
            },
        }
        validate_ready_record(ready)
        ready_rows.append(ready)
    return ready_rows


def extract_excel_workbook(workbook_path: Path) -> dict[str, Any]:
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        sheets: list[dict[str, Any]] = []
        rows_by_sheet: dict[str, list[dict[str, Any]]] = {}
        for worksheet in workbook.worksheets:
            values_iter = worksheet.iter_rows(values_only=True)
            rows = [[normalize_excel_cell(cell) for cell in row] for row in values_iter]
            if not rows:
                sheets.append(
                    {
                        "title": worksheet.title,
                        "headers": [],
                        "row_count": 0,
                        "max_column": worksheet.max_column,
                    }
                )
                rows_by_sheet[worksheet.title] = []
                continue
            headers = [str(cell).strip() if cell is not None else "" for cell in rows[0]]
            data_rows = rows[1:]
            normalized_rows: list[dict[str, Any]] = []
            for row_index, row in enumerate(data_rows, start=2):
                if not any(cell not in (None, "") for cell in row):
                    continue
                record: dict[str, Any] = {"__row_number__": row_index}
                for column_index, header in enumerate(headers):
                    key = header or f"column_{column_index + 1}"
                    record[key] = row[column_index] if column_index < len(row) else None
                normalized_rows.append(record)
            sheets.append(
                {
                    "title": worksheet.title,
                    "headers": headers,
                    "row_count": len(normalized_rows),
                    "max_column": worksheet.max_column,
                    "sample_rows": normalized_rows[:5],
                }
            )
            rows_by_sheet[worksheet.title] = normalized_rows
        return {"sheets": sheets, "rows_by_sheet": rows_by_sheet}
    finally:
        workbook.close()


def log_output_dir(record: InventoryRecord, member_path: str) -> Path:
    stem = Path(member_path).stem
    directory = LOGS_DIR / record.product_category / record.product_family / record.release / output_stem(record) / stem
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def package_output_dir(record: InventoryRecord, member_path: str) -> Path:
    stem = Path(member_path).stem
    directory = PACKAGES_DIR / record.product_category / record.product_family / record.release / output_stem(record) / stem
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def write_excel_log_outputs(record: InventoryRecord, files_dir: Path, member: dict[str, Any]) -> dict[str, Any]:
    member_path = files_dir / Path(member["path"])
    workbook_data = extract_excel_workbook(member_path)
    out_dir = log_output_dir(record, member["path"])
    summary = {
        "artifact_id": record.artifact_id,
        "source_archive": record.stored_relative_path,
        "member_path": member["path"],
        "member_type": "excel",
        "sheet_count": len(workbook_data["sheets"]),
        "sheets": workbook_data["sheets"],
        "ready_rows": 0,
    }
    write_json(out_dir / "excel_summary.json", summary)
    for sheet_title, rows in workbook_data["rows_by_sheet"].items():
        sheet_name = sanitize_sheet_title(sheet_title)
        write_jsonl(out_dir / f"{sheet_name}.rows.jsonl", rows)
    summary["workbook_rows"] = workbook_data["rows_by_sheet"]
    return summary


def extract_chm_member(archive_tool: str, record: InventoryRecord, files_dir: Path, member: dict[str, Any]) -> dict[str, Any]:
    member_path = files_dir / Path(member["path"])
    out_dir = log_output_dir(record, member["path"]) / "chm_extracted"
    out_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [archive_tool, "x", "-y", f"-o{out_dir}", str(member_path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    members = collect_unpacked_members(out_dir)
    counts = Counter(item["routing_stream"] for item in members)
    summary = {
        "artifact_id": record.artifact_id,
        "source_archive": record.stored_relative_path,
        "member_path": member["path"],
        "member_type": "chm",
        "extracted_to": str(out_dir.relative_to(H3C_DOCS_ROOT)).replace("\\", "/"),
        "member_count": len(members),
        "member_counts_by_stream": dict(counts),
        "members": members[:200],
        "ready_rows": 0,
    }
    write_json(log_output_dir(record, member["path"]) / "chm_summary.json", summary)
    return summary


def extract_package_chm_member(archive_tool: str, record: InventoryRecord, files_dir: Path, member: dict[str, Any]) -> dict[str, Any]:
    member_path = files_dir / Path(member["path"])
    out_dir = package_output_dir(record, member["path"]) / "chm_extracted"
    out_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [archive_tool, "x", "-y", f"-o{out_dir}", str(member_path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    members = collect_unpacked_members(out_dir)
    counts = Counter(item["routing_stream"] for item in members)
    summary = {
        "artifact_id": record.artifact_id,
        "source_archive": record.stored_relative_path,
        "member_path": member["path"],
        "member_type": "package_chm",
        "extracted_to": str(out_dir.relative_to(H3C_DOCS_ROOT)).replace("\\", "/"),
        "member_count": len(members),
        "member_counts_by_stream": dict(counts),
        "members": members[:200],
        "ready_rows": 0,
    }
    write_json(package_output_dir(record, member["path"]) / "chm_summary.json", summary)
    return summary


def process_log_archive_members(records: list[InventoryRecord]) -> dict[str, Any]:
    if not UNPACKED_SUMMARY_PATH.exists():
        summary = {"status": "skipped", "reason": "未找到已解包归档摘要", "archives": []}
        write_json(LOG_MEMBER_SUMMARY_PATH, summary)
        return summary

    unpacked_summary = json.loads(UNPACKED_SUMMARY_PATH.read_text(encoding="utf-8"))
    archive_tool = unpacked_summary.get("archive_tool")
    record_map = {record.artifact_id: record for record in records}
    archives_output: list[dict[str, Any]] = []
    aggregate = Counter()
    log_ready_rows: list[dict[str, Any]] = []

    for archive in unpacked_summary.get("archives", []):
        artifact_id = archive["artifact_id"]
        record = record_map.get(artifact_id)
        if record is None or record.doc_group != "log":
            continue
        archive_base = H3C_DOCS_ROOT / archive["unpacked_to"]
        files_dir = archive_base / "files"
        archive_result = {
            "artifact_id": artifact_id,
            "source_archive": archive["source_archive"],
            "processed_members": [],
        }
        for member in archive.get("members", []):
            stream = member["routing_stream"]
            if stream == "excel":
                excel_summary = write_excel_log_outputs(record, files_dir, member)
                workbook_rows = excel_summary.pop("workbook_rows")
                excel_ready_rows = build_log_excel_ready_records(record, excel_summary, workbook_rows)
                excel_summary["ready_rows"] = len(excel_ready_rows)
                write_json(log_output_dir(record, member["path"]) / "excel_summary.json", excel_summary)
                archive_result["processed_members"].append(excel_summary)
                aggregate["excel_workbooks"] += 1
                aggregate["excel_ready_rows"] += len(excel_ready_rows)
                log_ready_rows.extend(excel_ready_rows)
            elif stream == "chm" and archive_tool:
                chm_summary = extract_chm_member(archive_tool, record, files_dir, member)
                extracted_dir = H3C_DOCS_ROOT / chm_summary["extracted_to"]
                html_ready_rows = build_log_html_ready_records(record, chm_summary, extracted_dir)
                chm_summary["ready_rows"] = len(html_ready_rows)
                write_json(log_output_dir(record, member["path"]) / "chm_summary.json", chm_summary)
                archive_result["processed_members"].append(chm_summary)
                aggregate["chm_files"] += 1
                aggregate["html_ready_rows"] += len(html_ready_rows)
                log_ready_rows.extend(html_ready_rows)
            elif stream == "pdf":
                archive_result["processed_members"].append(
                    {
                        "member_type": "pdf",
                        "member_path": member["path"],
                        "status": "kept_for_pdf_pipeline",
                    }
                )
                aggregate["pdf_members"] += 1
        archives_output.append(archive_result)

    summary = {
        "status": "completed",
        "archive_count": len(archives_output),
        "aggregate": dict(aggregate),
        "archives": archives_output,
    }
    write_json(LOG_MEMBER_SUMMARY_PATH, summary)
    write_jsonl(LOG_READY_JSONL_PATH, log_ready_rows)
    log_ready_summary = {
        "total_ready_rows": len(log_ready_rows),
        "by_content_type": dict(Counter(row["content_type"] for row in log_ready_rows)),
    }
    write_json(LOG_READY_SUMMARY_PATH, log_ready_summary)
    return summary


def process_package_archive_members(records: list[InventoryRecord]) -> dict[str, Any]:
    if not UNPACKED_SUMMARY_PATH.exists():
        summary = {"status": "skipped", "reason": "未找到已解包归档摘要", "archives": []}
        write_json(PACKAGE_MEMBER_SUMMARY_PATH, summary)
        return summary

    unpacked_summary = json.loads(UNPACKED_SUMMARY_PATH.read_text(encoding="utf-8"))
    archive_tool = unpacked_summary.get("archive_tool")
    record_map = {record.artifact_id: record for record in records}
    archives_output: list[dict[str, Any]] = []
    aggregate = Counter()
    package_ready_rows: list[dict[str, Any]] = []

    for archive in unpacked_summary.get("archives", []):
        artifact_id = archive["artifact_id"]
        record = record_map.get(artifact_id)
        if record is None or record.doc_group != "package":
            continue
        archive_base = H3C_DOCS_ROOT / archive["unpacked_to"]
        files_dir = archive_base / "files"
        archive_result = {
            "artifact_id": artifact_id,
            "source_archive": archive["source_archive"],
            "processed_members": [],
        }
        for member in archive.get("members", []):
            if member["routing_stream"] != "chm" or not archive_tool:
                continue
            chm_summary = extract_package_chm_member(archive_tool, record, files_dir, member)
            extracted_dir = H3C_DOCS_ROOT / chm_summary["extracted_to"]
            html_ready_rows = build_package_html_ready_records(record, chm_summary, extracted_dir)
            chm_summary["ready_rows"] = len(html_ready_rows)
            write_json(package_output_dir(record, member["path"]) / "chm_summary.json", chm_summary)
            archive_result["processed_members"].append(chm_summary)
            aggregate["package_chm_files"] += 1
            aggregate["package_html_ready_rows"] += len(html_ready_rows)
            package_ready_rows.extend(html_ready_rows)
        archives_output.append(archive_result)

    summary = {
        "status": "completed",
        "archive_count": len(archives_output),
        "aggregate": dict(aggregate),
        "archives": archives_output,
    }
    write_json(PACKAGE_MEMBER_SUMMARY_PATH, summary)
    write_jsonl(PACKAGE_READY_JSONL_PATH, package_ready_rows)
    package_ready_summary = {
        "total_ready_rows": len(package_ready_rows),
        "by_content_type": dict(Counter(row["content_type"] for row in package_ready_rows)),
    }
    write_json(PACKAGE_READY_SUMMARY_PATH, package_ready_summary)
    return summary


def unpack_rar_record(record: InventoryRecord, archive_tool: str) -> dict[str, Any]:
    archive_path = Path(record.absolute_path)
    listed_members = list_archive_members(archive_tool, archive_path)
    destination = unpack_output_dir(record)
    files_dir = destination / "files"
    files_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        [archive_tool, "x", "-y", f"-o{files_dir}", str(archive_path)],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=True,
    )
    members = collect_unpacked_members(files_dir)
    counts = Counter(member["routing_stream"] for member in members)
    summary = {
        "artifact_id": record.artifact_id,
        "doc_group": record.doc_group,
        "doc_type": record.doc_type,
        "doc_subtype": record.doc_subtype,
        "source_archive": record.stored_relative_path,
        "archive_tool": archive_tool,
        "unpacked_to": str(destination.relative_to(H3C_DOCS_ROOT)).replace("\\", "/"),
        "listed_member_count": len(listed_members),
        "member_count": len(members),
        "member_counts_by_stream": dict(counts),
        "members": members,
    }
    write_json(destination / "unpacked_summary.json", summary)
    return summary


def unpack_rar_archives(records: list[InventoryRecord]) -> dict[str, Any]:
    rar_records = [record for record in records if record.exists and record.extension == ".rar"]
    archive_tool = find_archive_tool()
    if archive_tool is None:
        summary = {
            "archive_tool": None,
            "processed_archive_count": 0,
            "status": "skipped",
            "reason": "未找到可用的 RAR 解包工具（7z）",
            "archives": [],
        }
        write_json(UNPACKED_SUMMARY_PATH, summary)
        return summary

    archive_summaries = [unpack_rar_record(record, archive_tool) for record in rar_records]
    aggregate_counts = Counter()
    for archive_summary in archive_summaries:
        aggregate_counts.update(archive_summary["member_counts_by_stream"])
    summary = {
        "archive_tool": archive_tool,
        "processed_archive_count": len(archive_summaries),
        "status": "completed",
        "member_counts_by_stream": dict(aggregate_counts),
        "archives": archive_summaries,
    }
    write_json(UNPACKED_SUMMARY_PATH, summary)
    return summary


def detect_processing_kind(record: InventoryRecord) -> str | None:
    if record.doc_type == "命令参考":
        return "command"
    if record.doc_type == "配置指导":
        return "config"
    if record.doc_group == "troubleshooting" or any(keyword in record.doc_type for keyword in TROUBLESHOOTING_SUBTYPE_KEYWORDS):
        return "troubleshooting"
    return None


def select_first_batch(records: list[InventoryRecord]) -> dict[str, InventoryRecord]:
    candidates = [record for record in records if record.exists and record.extension == ".pdf"]
    selection: dict[str, InventoryRecord] = {}
    for kind in ("command", "config", "troubleshooting"):
        kind_candidates = [record for record in candidates if detect_processing_kind(record) == kind]
        if not kind_candidates:
            raise RuntimeError(f"未找到 {kind} 类型的 H3C 样本文档")
        preferred = PREFERRED_FIRST_BATCH[kind]
        preferred_candidates = [
            record
            for record in kind_candidates
            if record.product_category == preferred.get("product_category", record.product_category)
            and record.product_family == preferred.get("product_family", record.product_family)
            and (
                preferred.get("doc_type") is None
                or record.doc_type == preferred["doc_type"]
            )
            and (
                preferred.get("doc_subtype_contains") is None
                or preferred["doc_subtype_contains"] in record.doc_subtype
            )
        ]
        target_pool = preferred_candidates or kind_candidates
        selection[kind] = sorted(
            target_pool,
            key=lambda item: (item.product_category, item.product_family, item.release, item.stored_file_name),
        )[0]
    return selection


def write_selection(records: list[InventoryRecord], selection: dict[str, InventoryRecord]) -> None:
    selected_ids = {record.artifact_id for record in selection.values()}
    payload = {
        "selected": {
            kind: {
                **record.to_dict(),
                "processing_kind": kind,
                "selection_reason": {
                    "command": "首批命令参考样本，用于验证单命令切块。",
                    "config": "首批配置指导样本，用于验证任务型切块。",
                    "troubleshooting": "首批故障手册样本，用于验证故障条目切块。",
                }[kind],
            }
            for kind, record in selection.items()
        },
        "excluded_for_now": [record.to_dict() for record in records if record.artifact_id not in selected_ids],
    }
    FIRST_BATCH_SELECTION_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


_PROCESSING_PRIORITY_ORDER = {"highest": 0, "high": 1, "medium": 2, "low": 3, "deferred": 4}


def select_processable_pdfs(records: list[InventoryRecord]) -> list[tuple[InventoryRecord, str]]:
    """Return all PDF records with a detectable processing kind, sorted by priority then artifact_id."""
    candidates: list[tuple[InventoryRecord, str]] = []
    for record in records:
        if not record.exists or record.extension != ".pdf":
            continue
        kind = detect_processing_kind(record)
        if kind is not None:
            candidates.append((record, kind))
    candidates.sort(
        key=lambda item: (_PROCESSING_PRIORITY_ORDER.get(item[0].processing_priority, 99), item[0].artifact_id),
    )
    return candidates


def pdf_record_output_paths(record: InventoryRecord) -> dict[str, Path]:
    """Return the expected per-document output file paths for a PDF record."""
    stem = output_stem(record)
    return {
        "extracted": output_dir(EXTRACTED_DIR, record) / f"{stem}.extracted.json",
        "cleaned": output_dir(CLEANED_DIR, record) / f"{stem}.cleaned.md",
        "chunks": output_dir(CHUNKS_DIR, record) / f"{stem}.chunks.jsonl",
    }


def pdf_outputs_exist(record: InventoryRecord) -> bool:
    """Check whether all per-document outputs (extracted, cleaned, chunks) already exist on disk."""
    paths = pdf_record_output_paths(record)
    return all(p.exists() for p in paths.values())


def load_existing_chunks(record: InventoryRecord) -> list[dict[str, Any]]:
    """Load ready-row chunks from an existing chunks JSONL file."""
    paths = pdf_record_output_paths(record)
    chunks_path = paths["chunks"]
    if not chunks_path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in chunks_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if stripped:
            rows.append(json.loads(stripped))
    return rows


def process_pdf_record_safe(record: InventoryRecord, *, force_reprocess: bool = False) -> tuple[list[dict[str, Any]], bool]:
    """Process a single PDF record, skipping if outputs already exist.

    Returns (ready_rows, was_skipped).
    """
    if not force_reprocess and pdf_outputs_exist(record):
        return load_existing_chunks(record), True
    chunks = process_selected_record(record)
    return chunks, False


def run_all_pdfs(records: list[InventoryRecord] | None = None, *, force_reprocess: bool = False) -> dict[str, Any]:
    """Run the generalized PDF processing pipeline over all processable PDFs.

    Builds inventory if *records* is not supplied.  Skips any document whose
    per-document outputs (extracted / cleaned / chunks) already exist on disk,
    making the function safe to re-run.

    Log/package processing and the first-batch outputs are **not** touched.
    """
    ensure_output_directories()
    if records is None:
        records = build_inventory()
        write_inventory(records)

    processable = select_processable_pdfs(records)

    selection_payload = {
        "mode": "all",
        "total_processable": len(processable),
        "selected": [
            {**record.to_dict(), "processing_kind": kind}
            for record, kind in processable
        ],
    }
    ALL_PDF_SELECTION_PATH.write_text(json.dumps(selection_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    ready_rows: list[dict[str, Any]] = []
    skipped_count = 0
    processed_count = 0
    failed_records: list[dict[str, str]] = []

    for record, _kind in processable:
        try:
            rows, was_skipped = process_pdf_record_safe(record, force_reprocess=force_reprocess)
            ready_rows.extend(rows)
            if was_skipped:
                skipped_count += 1
            else:
                processed_count += 1
        except Exception as exc:
            failed_records.append({"artifact_id": record.artifact_id, "error": str(exc)})

    write_jsonl(ALL_PDF_READY_JSONL_PATH, ready_rows)

    by_type = Counter(row["content_type"] for row in ready_rows)
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    oversize_count = sum(1 for row in ready_rows if len(row["content"]) > 8000)

    all_pdf_summary = {
        "mode": "all",
        "force_reprocess": force_reprocess,
        "total_artifacts_inventoried": len(records),
        "total_processable_pdfs": len(processable),
        "processed_in_this_run": processed_count,
        "skipped_already_exist": skipped_count,
        "failed_count": len(failed_records),
        "failed_records": failed_records,
        "total_ready_records": len(ready_rows),
        "ready_records_by_type": dict(by_type),
        "empty_chunk_count": empty_count,
        "duplicate_chunk_count": duplicate_count,
        "oversize_chunk_count": oversize_count,
    }
    ALL_PDF_READY_SUMMARY_PATH.write_text(json.dumps(all_pdf_summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return all_pdf_summary


def normalize_line(line: str) -> str:
    line = line.replace("\u3000", " ").replace("\xa0", " ")
    line = re.sub(r"\s+", " ", line)
    return line.strip()


def normalize_page_text(text: str) -> str:
    normalized_lines = [normalize_line(line) for line in text.splitlines()]
    compacted: list[str] = []
    previous_blank = False
    for line in normalized_lines:
        if not line:
            if not previous_blank:
                compacted.append("")
            previous_blank = True
            continue
        compacted.append(line)
        previous_blank = False
    return "\n".join(compacted).strip()


def is_table_of_contents_page(text: str) -> bool:
    if "目 录" in text or "目  录" in text:
        return True
    lines = [line for line in text.splitlines() if line]
    toc_like_lines = sum(1 for line in lines if re.search(r"[·.]{5,}.*\d+(?:-\d+)?$", line))
    return toc_like_lines >= 4


def detect_body_start_page(extracted_pages: list[dict[str, Any]], kind: str) -> int:
    patterns = {
        "command": re.compile(r"^\d+\.\d+\.\d+\s+\S.+$", re.MULTILINE),
        "config": re.compile(r"^\d+\.\d+\s+\S.+$", re.MULTILINE),
        "troubleshooting": re.compile(r"^\d+\.\d+\s+\S.+$", re.MULTILINE),
    }
    pattern = patterns[kind]
    for page in extracted_pages:
        text = page["text"]
        if is_table_of_contents_page(text):
            continue
        if pattern.search(text):
            return int(page["page_number"])
    return 1


def should_drop_line(line: str) -> bool:
    if not line:
        return False
    if re.fullmatch(r"[ivxlcdm]+", line.lower()):
        return True
    if re.fullmatch(r"\d+-\d+", line):
        return True
    if re.fullmatch(r"\d+", line):
        return True
    if line.startswith("Copyright ©"):
        return True
    if line == "http://www.h3c.com":
        return True
    return False


def clean_extracted_pages(extracted_pages: list[dict[str, Any]], kind: str) -> tuple[list[dict[str, Any]], list[str]]:
    body_start_page = detect_body_start_page(extracted_pages, kind)
    warnings: list[str] = []
    cleaned_pages: list[dict[str, Any]] = []
    for page in extracted_pages:
        page_number = int(page["page_number"])
        if page_number < body_start_page:
            continue
        text = normalize_page_text(page["text"])
        if not text:
            continue
        if is_table_of_contents_page(text):
            continue
        if any(keyword in text for keyword in FRONT_MATTER_KEYWORDS):
            continue
        lines = [line for line in text.splitlines() if not should_drop_line(line)]
        lines = [line for line in lines if line]
        if not lines:
            continue
        cleaned_pages.append({"page_number": page_number, "text": "\n".join(lines)})
    if not cleaned_pages:
        warnings.append("清洗后未保留任何正文页面")
    return cleaned_pages, warnings


def cleaned_pages_to_markdown(cleaned_pages: list[dict[str, Any]]) -> str:
    blocks: list[str] = []
    for page in cleaned_pages:
        blocks.append(f"<!-- page: {page['page_number']} -->\n{page['text']}")
    return "\n\n".join(blocks).strip() + "\n"


def extract_pdf(record: InventoryRecord) -> dict[str, Any]:
    pdf_path = Path(record.absolute_path)
    reader = PdfReader(str(pdf_path))
    pages: list[dict[str, Any]] = []
    for page_number, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        pages.append({"page_number": page_number, "text": text})
    metadata = reader.metadata or {}
    return {
        "artifact_id": record.artifact_id,
        "processing_kind": detect_processing_kind(record),
        "page_count": len(reader.pages),
        "pdf_metadata": {
            "title": getattr(metadata, "title", None),
            "author": getattr(metadata, "author", None),
            "producer": getattr(metadata, "producer", None),
            "creator": getattr(metadata, "creator", None),
        },
        "pages": pages,
        "warnings": [],
    }


def heading_regex_for_kind(kind: str) -> tuple[re.Pattern[str], int]:
    if kind == "command":
        return re.compile(r"^(\d+(?:\.\d+){2,})\s+(.+)$"), 3
    return re.compile(r"^(\d+\.\d+(?:\.\d+)*)\s+(.+)$"), 2


def extract_block_value(text: str, label: str) -> str | None:
    pattern = re.compile(rf"【{re.escape(label)}】\n(?P<value>.*?)(?:\n【|$)", re.S)
    match = pattern.search(text)
    if not match:
        return None
    return match.group("value").strip() or None


def chunk_cleaned_pages(record: InventoryRecord, cleaned_pages: list[dict[str, Any]], kind: str) -> list[dict[str, Any]]:
    page_map = {int(page["page_number"]): page["text"] for page in cleaned_pages}
    markdown = cleaned_pages_to_markdown(cleaned_pages)
    lines = markdown.splitlines()
    heading_pattern, split_depth = heading_regex_for_kind(kind)

    current_page: int | None = None
    section_stack: dict[int, str] = {}
    current_chunk: dict[str, Any] | None = None
    chunks: list[dict[str, Any]] = []

    def flush_chunk() -> None:
        nonlocal current_chunk
        if not current_chunk:
            return
        content = "\n".join(current_chunk["content_lines"]).strip()
        if not content:
            current_chunk = None
            return
        title = current_chunk["heading_title"]
        section_path = current_chunk["section_path"]
        chunk_index = len(chunks) + 1
        extra: dict[str, Any] = {}
        content_type = kind if kind != "config" else "task"
        if kind == "command":
            extra["command_name"] = title
            syntax = extract_block_value(content, "命令")
            if syntax:
                extra["syntax"] = syntax
            view = extract_block_value(content, "视图")
            if view:
                extra["view"] = view
        elif kind == "config":
            extra["task_name"] = title
        elif kind == "troubleshooting":
            extra["symptom"] = title
        chunk = {
            "doc_id": f"h3c-{output_stem(record)}-{kind}-{chunk_index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": content_type,
            "title": title,
            "section_path": section_path,
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_range": [current_chunk["start_page"], current_chunk["end_page"]],
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "zh-CN",
            "content": content,
            "extra": extra,
        }
        validate_ready_record(chunk)
        chunks.append(chunk)
        current_chunk = None

    for line in lines:
        page_match = re.match(r"<!-- page: (\d+) -->", line)
        if page_match:
            current_page = int(page_match.group(1))
            if current_chunk and current_page is not None:
                current_chunk["end_page"] = current_page
            continue
        match = heading_pattern.match(line)
        if match:
            number, title = match.groups()
            depth = number.count(".") + 1
            section_stack[depth] = f"{number} {title}"
            for stale_depth in list(section_stack):
                if stale_depth > depth:
                    section_stack.pop(stale_depth, None)
            if depth >= split_depth:
                flush_chunk()
                current_chunk = {
                    "heading_title": title.strip(),
                    "section_path": [section_stack[key] for key in sorted(section_stack)],
                    "start_page": current_page,
                    "end_page": current_page,
                    "content_lines": [line],
                }
                continue
        if current_chunk is not None:
            current_chunk["content_lines"].append(line)
            if current_page is not None:
                current_chunk["end_page"] = current_page

    flush_chunk()
    return chunks


def validate_ready_record(record: dict[str, Any]) -> None:
    required_fields = (
        "doc_id",
        "vendor",
        "product_category",
        "product_family",
        "release",
        "doc_type",
        "title",
        "source_file",
        "source_relative_path",
        "content_type",
        "content",
    )
    missing = [field for field in required_fields if not record.get(field)]
    if missing:
        raise ValueError(f"ready 记录缺少字段: {missing}")


def output_stem(record: InventoryRecord) -> str:
    file_name = Path(record.stored_file_name)
    return file_name.stem


def output_dir(base_dir: Path, record: InventoryRecord) -> Path:
    directory = base_dir / record.product_category / record.product_family / record.release
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")


def process_selected_record(record: InventoryRecord) -> list[dict[str, Any]]:
    kind = detect_processing_kind(record)
    if kind is None:
        raise RuntimeError(f"不支持处理的文档类型: {record.stored_file_name}")

    extracted = extract_pdf(record)
    cleaned_pages, cleaning_warnings = clean_extracted_pages(extracted["pages"], kind)
    extracted["warnings"].extend(cleaning_warnings)
    chunks = chunk_cleaned_pages(record, cleaned_pages, kind)

    extracted_path = output_dir(EXTRACTED_DIR, record) / f"{output_stem(record)}.extracted.json"
    cleaned_path = output_dir(CLEANED_DIR, record) / f"{output_stem(record)}.cleaned.md"
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"

    write_json(extracted_path, extracted)
    cleaned_path.write_text(cleaned_pages_to_markdown(cleaned_pages), encoding="utf-8")
    write_jsonl(chunks_path, chunks)
    return chunks


def build_summary(records: list[InventoryRecord], selection: dict[str, InventoryRecord], ready_rows: list[dict[str, Any]]) -> dict[str, Any]:
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    by_type = Counter(row["content_type"] for row in ready_rows)
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    oversize_count = sum(1 for row in ready_rows if len(row["content"]) > 8000)
    unpacked_summary: dict[str, Any] = {}
    if UNPACKED_SUMMARY_PATH.exists():
        unpacked_summary = json.loads(UNPACKED_SUMMARY_PATH.read_text(encoding="utf-8"))
    log_member_summary: dict[str, Any] = {}
    if LOG_MEMBER_SUMMARY_PATH.exists():
        log_member_summary = json.loads(LOG_MEMBER_SUMMARY_PATH.read_text(encoding="utf-8"))
    package_member_summary: dict[str, Any] = {}
    if PACKAGE_MEMBER_SUMMARY_PATH.exists():
        package_member_summary = json.loads(PACKAGE_MEMBER_SUMMARY_PATH.read_text(encoding="utf-8"))
    return {
        "total_artifacts_inventoried": len(records),
        "unpacked_archive_count": unpacked_summary.get("processed_archive_count", 0),
        "unpacked_member_counts_by_stream": unpacked_summary.get("member_counts_by_stream", {}),
        "log_member_processing": log_member_summary.get("aggregate", {}),
        "package_member_processing": package_member_summary.get("aggregate", {}),
        "processed_sample_documents": {
            kind: record.stored_relative_path for kind, record in selection.items()
        },
        "total_ready_records": len(ready_rows),
        "ready_records_by_type": dict(by_type),
        "empty_chunk_count": empty_count,
        "duplicate_chunk_count": duplicate_count,
        "oversize_chunk_count": oversize_count,
    }


def run() -> dict[str, Any]:
    ensure_output_directories()
    records = build_inventory()
    write_inventory(records)
    unpack_rar_archives(records)
    process_log_archive_members(records)
    process_package_archive_members(records)
    selection = select_first_batch(records)
    write_selection(records, selection)

    ready_rows: list[dict[str, Any]] = []
    for record in selection.values():
        ready_rows.extend(process_selected_record(record))

    write_jsonl(READY_JSONL_PATH, ready_rows)
    summary = build_summary(records, selection, ready_rows)
    READY_SUMMARY_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main() -> None:
    import sys

    mode = sys.argv[1] if len(sys.argv) > 1 else "first_batch"
    if mode == "all":
        force_reprocess = any(arg == "--force" for arg in sys.argv[2:])
        summary = run_all_pdfs(force_reprocess=force_reprocess)
    else:
        summary = run()
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
