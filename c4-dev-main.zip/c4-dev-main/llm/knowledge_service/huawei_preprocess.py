from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pypdf import PdfReader


REPO_ROOT = Path(__file__).resolve().parents[2]
HUAWEI_DOCS_ROOT = REPO_ROOT / "参考项目" / "huawei_docs"
RAW_ROOT = HUAWEI_DOCS_ROOT / "raw"
PROCESSED_ROOT = HUAWEI_DOCS_ROOT / "processed"

INVENTORY_DIR = PROCESSED_ROOT / "inventory"
CHUNKS_DIR = PROCESSED_ROOT / "chunks"
READY_DIR = PROCESSED_ROOT / "ready"

INVENTORY_PATH = INVENTORY_DIR / "huawei_raw_inventory.jsonl"
READY_JSONL_PATH = READY_DIR / "huawei_command_ready.jsonl"
READY_SUMMARY_PATH = READY_DIR / "huawei_command_ready.summary.json"
MANUAL_READY_JSONL_PATH = READY_DIR / "huawei_manual_ready.jsonl"
MANUAL_READY_SUMMARY_PATH = READY_DIR / "huawei_manual_ready.summary.json"
PDF_READY_JSONL_PATH = READY_DIR / "huawei_pdf_ready.jsonl"
PDF_READY_SUMMARY_PATH = READY_DIR / "huawei_pdf_ready.summary.json"
KNOWLEDGE_READY_JSONL_PATH = READY_DIR / "huawei_knowledge_ready.jsonl"
KNOWLEDGE_READY_SUMMARY_PATH = READY_DIR / "huawei_knowledge_ready.summary.json"
BULLETIN_READY_JSONL_PATH = READY_DIR / "huawei_bulletin_ready.jsonl"
BULLETIN_READY_SUMMARY_PATH = READY_DIR / "huawei_bulletin_ready.summary.json"
LINK_READY_JSONL_PATH = READY_DIR / "huawei_link_ready.jsonl"
LINK_READY_SUMMARY_PATH = READY_DIR / "huawei_link_ready.summary.json"
DOC_API_READY_JSONL_PATH = READY_DIR / "huawei_doc_api_ready.jsonl"
DOC_API_READY_SUMMARY_PATH = READY_DIR / "huawei_doc_api_ready.summary.json"


@dataclass(slots=True)
class InventoryRecord:
    artifact_id: str
    source_manifest_path: str
    vendor: str
    product_category: str
    product_family: str
    release: str
    collection_available: bool
    doc_group: str
    doc_type: str
    doc_subtype: str
    title: str
    source_page_url: str
    download_url: str
    doc_id: str
    stored_file_name: str
    stored_relative_path: str
    absolute_path: str
    file_size_bytes: int | None
    fetched_method: str
    fetched_at: str
    exists: bool
    extension: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "artifact_id": self.artifact_id,
            "source_manifest_path": self.source_manifest_path,
            "vendor": self.vendor,
            "product_category": self.product_category,
            "product_family": self.product_family,
            "release": self.release,
            "collection_available": self.collection_available,
            "doc_group": self.doc_group,
            "doc_type": self.doc_type,
            "doc_subtype": self.doc_subtype,
            "title": self.title,
            "source_page_url": self.source_page_url,
            "download_url": self.download_url,
            "doc_id": self.doc_id,
            "stored_file_name": self.stored_file_name,
            "stored_relative_path": self.stored_relative_path,
            "absolute_path": self.absolute_path,
            "file_size_bytes": self.file_size_bytes,
            "fetched_method": self.fetched_method,
            "fetched_at": self.fetched_at,
            "exists": self.exists,
            "extension": self.extension,
        }


def ensure_output_directories() -> None:
    for directory in (INVENTORY_DIR, CHUNKS_DIR, READY_DIR):
        directory.mkdir(parents=True, exist_ok=True)


def iter_manifest_paths(raw_root: Path = RAW_ROOT) -> list[Path]:
    return sorted(raw_root.rglob("manifest.json"))


def build_inventory(raw_root: Path = RAW_ROOT) -> list[InventoryRecord]:
    records: list[InventoryRecord] = []
    for manifest_path in iter_manifest_paths(raw_root):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for artifact in manifest.get("artifacts", []):
            relative_path = artifact["stored_relative_path"]
            absolute_path = HUAWEI_DOCS_ROOT / relative_path
            extension = absolute_path.suffix.lower()
            artifact_id = f"{manifest['product_category']}-{manifest['product_family']}-{manifest['release']}-{artifact['stored_file_name']}"
            records.append(
                InventoryRecord(
                    artifact_id=artifact_id,
                    source_manifest_path=str(manifest_path.relative_to(HUAWEI_DOCS_ROOT)).replace("\\", "/"),
                    vendor=manifest["vendor"],
                    product_category=manifest["product_category"],
                    product_family=manifest["product_family"],
                    release=manifest["release"],
                    collection_available=bool(manifest.get("collection_available", False)),
                    doc_group=artifact.get("doc_group", ""),
                    doc_type=artifact.get("doc_type", ""),
                    doc_subtype=artifact.get("doc_subtype", ""),
                    title=artifact.get("title", ""),
                    source_page_url=artifact.get("source_page_url", ""),
                    download_url=artifact.get("download_url", ""),
                    doc_id=artifact.get("doc_id", ""),
                    stored_file_name=artifact.get("stored_file_name", ""),
                    stored_relative_path=relative_path,
                    absolute_path=str(absolute_path),
                    file_size_bytes=artifact.get("file_size_bytes"),
                    fetched_method=artifact.get("fetched_method", ""),
                    fetched_at=artifact.get("fetched_at", ""),
                    exists=absolute_path.exists(),
                    extension=extension,
                )
            )
    return records


def write_inventory(records: list[InventoryRecord]) -> None:
    ensure_output_directories()
    INVENTORY_PATH.write_text(
        "\n".join(json.dumps(record.to_dict(), ensure_ascii=False) for record in records) + "\n",
        encoding="utf-8",
    )


def output_stem(record: InventoryRecord) -> str:
    return Path(record.stored_file_name).stem


def output_dir(base_dir: Path, record: InventoryRecord) -> Path:
    directory = base_dir / record.product_category / record.product_family / record.release
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text("\n".join(json.dumps(row, ensure_ascii=False) for row in rows) + "\n", encoding="utf-8")


def validate_ready_record(record: dict[str, Any]) -> None:
    required_fields = (
        "doc_id",
        "vendor",
        "product_category",
        "product_family",
        "release",
        "doc_type",
        "title",
        "source_file",
        "source_relative_path",
        "content_type",
        "content",
    )
    missing = [field for field in required_fields if not record.get(field)]
    if missing:
        raise ValueError(f"ready 记录缺少字段: {missing}")


def extract_snapshot_value(text: str, label: str) -> str | None:
    lines = text.splitlines()
    for index, line in enumerate(lines):
        if f'StaticText "{label}"' not in line:
            continue
        if index + 1 >= len(lines):
            return None
        value_match = re.search(r'value="([^"]+)"', lines[index + 1])
        if value_match:
            return value_match.group(1).strip()
    return None


def snapshot_has_command_results(text: str) -> bool:
    if "No data available" in text or "No results found" in text:
        return False
    return (
        'StaticText "Command"' in text
        and 'StaticText "Format"' in text
        and 'StaticText "Description"' in text
        and 'url="https://support.huawei.com/hedex/hdx.do?' in text
    )


def snapshot_has_manual_content(text: str) -> bool:
    if "uniportal.huawei.com/uniportal1" in text:
        return False
    if 'heading "' not in text:
        return False
    if text.count('StaticText "') < 20:
        return False
    return True


def select_processable_command_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    selected: list[InventoryRecord] = []
    for record in records:
        if record.doc_group != "command" or record.extension != ".txt" or not record.exists:
            continue
        text = Path(record.absolute_path).read_text(encoding="utf-8")
        if snapshot_has_command_results(text):
            selected.append(record)
    return selected


def select_processable_manual_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    selected: list[InventoryRecord] = []
    for record in records:
        if record.doc_group != "manual" or record.extension != ".txt" or not record.exists:
            continue
        text = Path(record.absolute_path).read_text(encoding="utf-8")
        if snapshot_has_manual_content(text) and parse_manual_snapshot(record)["content"]:
            selected.append(record)
    return selected


def select_processable_pdf_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    return [
        record
        for record in records
        if record.doc_group == "datasheet" and record.extension == ".pdf" and record.exists
    ]


def select_processable_knowledge_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    return [
        record
        for record in records
        if record.doc_group == "knowledge"
        and record.extension == ".json"
        and record.exists
        and record.stored_file_name.endswith("_kb_list_clean.json")
    ]


def select_processable_bulletin_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    return [
        record
        for record in records
        if record.doc_group == "bulletin"
        and record.extension == ".json"
        and record.exists
        and record.stored_file_name.endswith("_bulletins_list_clean.json")
    ]


def select_processable_link_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    return [
        record
        for record in records
        if record.extension == ".json"
        and record.exists
        and record.stored_file_name.endswith("_links_clean.json")
    ]


def select_processable_doc_api_records(records: list[InventoryRecord]) -> list[InventoryRecord]:
    return [
        record
        for record in records
        if record.extension == ".network-response"
        and record.exists
        and record.stored_file_name == "req84_doc_second_item_response.network-response"
    ]


def extract_static_text(line: str) -> str | None:
    match = re.search(r'StaticText "([^"]*)"', line)
    if match:
        return match.group(1).strip()
    return None


def extract_heading_text(line: str) -> tuple[int, str] | None:
    match = re.search(r'heading "([^"]+)" level="(\d+)"', line)
    if not match:
        return None
    return int(match.group(2)), match.group(1).strip()


def extract_link_text(line: str) -> str | None:
    match = re.search(r'link "([^"]+)"', line)
    if match:
        return match.group(1).strip()
    return None


def parse_command_snapshot(record: InventoryRecord) -> dict[str, Any]:
    text = Path(record.absolute_path).read_text(encoding="utf-8")
    version = extract_snapshot_value(text, " Version:")
    product_model = extract_snapshot_value(text, " Product Model:")
    if not snapshot_has_command_results(text):
        return {"version": version, "product_model": product_model, "entries": []}

    entries: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    in_results = False
    expecting_default_level = False
    expecting_views = False
    collecting_syntax = False

    def flush_current() -> None:
        nonlocal current
        if current is None:
            return
        content_lines = [current["command_name"], *current["syntax_lines"], *current["description_lines"]]
        if current.get("default_level"):
            content_lines.append(f"Default level: {current['default_level']}")
        if current.get("views"):
            content_lines.append(f"Views: {current['views']}")
        current["content"] = "\n".join(line for line in content_lines if line).strip()
        entries.append(current)
        current = None

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not in_results:
            if 'StaticText "Description"' in line:
                in_results = True
            continue

        if 'StaticText "Follow Us"' in line or "Copyright ©" in line:
            break

        link_match = re.search(r'link "([^"]+)" url="([^"]*hedex/hdx\.do\?[^"]*)"', line)
        if link_match:
            flush_current()
            current = {
                "command_name": link_match.group(1).strip(),
                "hedex_url": link_match.group(2).strip(),
                "syntax_lines": [],
                "description_lines": [],
                "default_level": None,
                "views": None,
            }
            collecting_syntax = True
            expecting_default_level = False
            expecting_views = False
            continue

        if current is None:
            continue

        if 'StaticText "Default level: "' in line:
            expecting_default_level = True
            collecting_syntax = False
            continue
        if 'StaticText "Views: "' in line:
            expecting_views = True
            collecting_syntax = False
            continue

        text_value = extract_static_text(line)
        if not text_value:
            continue
        if text_value in {current["command_name"], "Command", "Format", "Description", "|", "Accept Cookies", "Reject Cookies"}:
            continue
        if text_value in {"No data available", "No results found"} or text_value.startswith("Total:"):
            break

        if expecting_default_level:
            current["default_level"] = text_value.rstrip(",")
            expecting_default_level = False
            continue
        if expecting_views:
            current["views"] = text_value.rstrip(",")
            expecting_views = False
            continue

        if text_value.startswith(("The ", "By default,", "This command", "Only the ", "For details ")):
            collecting_syntax = False

        if collecting_syntax:
            current["syntax_lines"].append(text_value)
        else:
            current["description_lines"].append(text_value)

    flush_current()
    return {"version": version, "product_model": product_model, "entries": entries}


def parse_manual_snapshot(record: InventoryRecord) -> dict[str, Any]:
    text = Path(record.absolute_path).read_text(encoding="utf-8")
    if not snapshot_has_manual_content(text):
        return {"title": record.title, "section_path": [], "content": ""}

    lines = text.splitlines()
    canonical_title = record.title.split(" - ", 1)[0].strip()
    title = canonical_title or record.title
    section_path: list[str] = []
    content_lines: list[str] = []
    started = False

    for raw_line in lines:
        line = raw_line.strip()
        if 'heading "Related Documents"' in line or 'heading "Digital Signature File"' in line or 'contentinfo' in line:
            break
        heading = extract_heading_text(line)
        if heading is not None:
            level, heading_text = heading
            if level == 1 and heading_text in {record.title, canonical_title}:
                started = True
                title = heading_text
                continue
            if started and level <= 4:
                section_path.append(heading_text)
                content_lines.append(f"{'#' * min(level, 4)} {heading_text}")
                continue

        if not started:
            continue

        link_text = extract_link_text(line)
        if link_text and "#EN-US_" in line and link_text not in {title, *section_path}:
            section_path.append(link_text)
            continue

        text_value = extract_static_text(line)
        if not text_value:
            continue
        if text_value in {
            "Translation",
            "Favorite",
            "Download",
            "Learn more",
            "cookie settings",
            "Accept Cookies",
            "Reject Cookies",
            "OK, got it",
            "Please evaluate and leave your comments:",
            "0 / 500",
        }:
            continue
        if text_value.startswith("Copyright ©") or text_value == "Cookie Settings":
            break
        if text_value.startswith("Update Date"):
            continue
        if text_value == title:
            continue
        content_lines.append(text_value)

    deduped_lines: list[str] = []
    for line in content_lines:
        if deduped_lines and deduped_lines[-1] == line:
            continue
        deduped_lines.append(line)
    return {
        "title": title,
        "section_path": section_path,
        "content": "\n".join(deduped_lines).strip(),
    }


def extract_pdf(record: InventoryRecord) -> dict[str, Any]:
    pdf_path = Path(record.absolute_path)
    reader = PdfReader(str(pdf_path))
    pages: list[dict[str, Any]] = []
    for index, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        pages.append({"page_number": index, "text": text})
    return {"page_count": len(pages), "pages": pages}


def clean_pdf_page_text(text: str, title: str, page_number: int) -> str:
    cleaned_lines: list[str] = []
    title_pattern = re.compile(rf"^{re.escape(title)}\s+\d+$")
    generic_datasheet_pattern = re.compile(r"^.+Datasheet\s+\d+$")
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line == title:
            continue
        if title_pattern.match(line):
            continue
        if generic_datasheet_pattern.match(line):
            continue
        if line == str(page_number):
            continue
        if line.startswith("Copyright © Huawei Technologies Co., Ltd"):
            continue
        if line in {"Datasheet", "More Information", "Notice", "Trademarks and Permissions"}:
            continue
        cleaned_lines.append(line)
    compact = "\n".join(cleaned_lines).strip()
    compact = re.sub(r"\n{3,}", "\n\n", compact)
    return compact


def parse_datasheet_pages(record: InventoryRecord) -> list[dict[str, Any]]:
    extracted = extract_pdf(record)
    title = Path(record.stored_file_name).stem.replace("_", " ")
    rows: list[dict[str, Any]] = []
    for page in extracted["pages"]:
        page_number = int(page["page_number"])
        cleaned = clean_pdf_page_text(str(page["text"]), title, page_number)
        if len(cleaned) < 80:
            continue
        lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
        page_title = lines[0][:160] if lines else f"Page {page_number}"
        rows.append(
            {
                "page_number": page_number,
                "title": page_title,
                "content": cleaned,
            }
        )
    return rows


def load_clean_json_list(record: InventoryRecord) -> list[dict[str, Any]]:
    payload = json.loads(Path(record.absolute_path).read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        return []
    rows: list[dict[str, Any]] = []
    for item in payload:
        if isinstance(item, dict):
            rows.append(item)
    return rows


def load_network_response(record: InventoryRecord) -> dict[str, Any]:
    payload = json.loads(Path(record.absolute_path).read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        return payload
    return {}


def flatten_doc_api_entries(payload: dict[str, Any]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    for first_level in payload.get("data", []):
        if not isinstance(first_level, dict):
            continue
        for second_level in first_level.get("subAggs", []):
            if not isinstance(second_level, dict):
                continue
            for doc in second_level.get("docList", []):
                if isinstance(doc, dict):
                    entries.append(doc)
    return entries


def link_title(item: dict[str, Any], index: int) -> str:
    text = str(item.get("text") or "").strip()
    if text:
        return re.sub(r"\s+", " ", text)
    href = str(item.get("href") or "").strip()
    nid_match = re.search(r"[?&]nid=([A-Z0-9]+)", href)
    if nid_match:
        return nid_match.group(1)
    path_tail = href.rstrip("/").rsplit("/", 1)[-1]
    return path_tail or f"link-{index}"


def build_command_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    parsed = parse_command_snapshot(record)
    rows: list[dict[str, Any]] = []
    for index, entry in enumerate(parsed["entries"], start=1):
        ready = {
            "doc_id": f"huawei-{output_stem(record)}-command-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "command",
            "title": entry["command_name"],
            "section_path": [record.title, entry["command_name"]],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": entry["content"],
            "extra": {
                "command_name": entry["command_name"],
                "syntax": "\n".join(entry["syntax_lines"]).strip(),
                "views": entry.get("views"),
                "default_level": entry.get("default_level"),
                "product_model": parsed["product_model"],
                "version": parsed["version"],
                "hedex_url": entry["hedex_url"],
            },
        }
        validate_ready_record(ready)
        rows.append(ready)
    return rows


def process_command_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_command_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def build_manual_ready_record(record: InventoryRecord) -> dict[str, Any]:
    parsed = parse_manual_snapshot(record)
    ready = {
        "doc_id": f"huawei-{output_stem(record)}-manual-0001",
        "vendor": record.vendor,
        "product_category": record.product_category,
        "product_family": record.product_family,
        "release": record.release,
        "doc_group": record.doc_group,
        "doc_type": record.doc_type,
        "doc_subtype": record.doc_subtype,
        "content_type": "manual_doc",
        "title": parsed["title"],
        "section_path": parsed["section_path"] or [parsed["title"]],
        "source_file": record.stored_file_name,
        "source_relative_path": record.stored_relative_path,
        "source_page_url": record.source_page_url,
        "download_url": record.download_url,
        "language": "en-US",
        "content": parsed["content"],
        "extra": {
            "doc_id": record.doc_id,
            "manual_title": record.title,
        },
    }
    validate_ready_record(ready)
    return ready


def process_manual_record(record: InventoryRecord) -> list[dict[str, Any]]:
    row = build_manual_ready_record(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, [row])
    return [row]


def build_pdf_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    parsed_pages = parse_datasheet_pages(record)
    rows: list[dict[str, Any]] = []
    for index, page in enumerate(parsed_pages, start=1):
        row = {
            "doc_id": f"huawei-{output_stem(record)}-datasheet-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "datasheet_page",
            "title": page["title"],
            "section_path": [record.title, f"page-{page['page_number']}", page["title"]],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_range": [page["page_number"], page["page_number"]],
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": page["content"],
            "extra": {
                "page_number": page["page_number"],
                "pdf_title": record.title,
            },
        }
        validate_ready_record(row)
        rows.append(row)
    return rows


def process_pdf_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_pdf_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def build_knowledge_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    items = load_clean_json_list(record)
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        title = str(item.get("name") or f"knowledge-{index}").strip()
        content_lines = [
            title,
            f"Knowledge ID: {item.get('contentId')}" if item.get("contentId") else "",
            f"Publish time: {item.get('publishTime')}" if item.get("publishTime") else "",
            f"Average score: {item.get('avgScore')}" if item.get("avgScore") not in (None, "") else "",
            f"Read count: {item.get('readCount')}" if item.get("readCount") not in (None, "") else "",
            f"Classic case: {item.get('isClassicCase')}" if item.get("isClassicCase") is not None else "",
            f"View status: {item.get('viewStatus')}" if item.get("viewStatus") else "",
        ]
        row = {
            "doc_id": f"huawei-{output_stem(record)}-knowledge-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "knowledge_item",
            "title": title,
            "section_path": [record.title, title],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": "\n".join(line for line in content_lines if line).strip(),
            "extra": {
                "content_id": item.get("contentId"),
                "publish_time": item.get("publishTime"),
                "avg_score": item.get("avgScore"),
                "read_count": item.get("readCount"),
                "is_classic_case": item.get("isClassicCase"),
                "view_status": item.get("viewStatus"),
            },
        }
        validate_ready_record(row)
        rows.append(row)
    return rows


def build_bulletin_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    items = load_clean_json_list(record)
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        title = str(item.get("name") or f"bulletin-{index}").strip()
        content_lines = [
            title,
            f"Bulletin ID: {item.get('nid')}" if item.get("nid") else "",
            f"Publish time: {item.get('publishTime')}" if item.get("publishTime") else "",
            f"View count: {item.get('viewCount')}" if item.get("viewCount") not in (None, "") else "",
            f"Operation type: {item.get('operationType')}" if item.get("operationType") else "",
            f"Category: {item.get('mid')}" if item.get("mid") else "",
            f"Security: {item.get('security')}" if item.get("security") else "",
            f"PCN change type: {item.get('pcnChangeType')}" if item.get("pcnChangeType") else "",
        ]
        row = {
            "doc_id": f"huawei-{output_stem(record)}-bulletin-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "bulletin_item",
            "title": title,
            "section_path": [record.title, title],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": "\n".join(line for line in content_lines if line).strip(),
            "extra": {
                "nid": item.get("nid"),
                "publish_time": item.get("publishTime"),
                "view_count": item.get("viewCount"),
                "operation_type": item.get("operationType"),
                "category": item.get("mid"),
                "security": item.get("security"),
                "new_flag": item.get("newFlag"),
                "set_top": item.get("setTop"),
            },
        }
        validate_ready_record(row)
        rows.append(row)
    return rows


def process_knowledge_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_knowledge_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def process_bulletin_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_bulletin_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def build_link_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    items = load_clean_json_list(record)
    rows: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        href = str(item.get("href") or "").strip()
        if not href:
            continue
        title = link_title(item, index)
        text = str(item.get("text") or "").strip()
        content_lines = [
            f"Label: {text}" if text else "",
            f"URL: {href}",
        ]
        nid_match = re.search(r"[?&]nid=([A-Z0-9]+)", href)
        if nid_match:
            content_lines.append(f"Document ID: {nid_match.group(1)}")
        row = {
            "doc_id": f"huawei-{output_stem(record)}-link-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "link_item",
            "title": title,
            "section_path": [record.title, title],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": "\n".join(line for line in content_lines if line).strip(),
            "extra": {
                "label": text or None,
                "href": href,
                "linked_doc_id": nid_match.group(1) if nid_match else None,
            },
        }
        validate_ready_record(row)
        rows.append(row)
    return rows


def process_link_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_link_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def build_doc_api_ready_records(record: InventoryRecord) -> list[dict[str, Any]]:
    payload = load_network_response(record)
    docs = flatten_doc_api_entries(payload)
    rows: list[dict[str, Any]] = []
    for index, doc in enumerate(docs, start=1):
        title = str(doc.get("name") or f"doc-api-{index}").strip()
        field_values = doc.get("fieldValues") if isinstance(doc.get("fieldValues"), dict) else {}
        related_submodels = field_values.get("relatedSubModel") if isinstance(field_values, dict) else None
        content_lines = [
            title,
            f"Document ID: {doc.get('nid')}" if doc.get("nid") else "",
            f"Version: {doc.get('versionName')}" if doc.get("versionName") else "",
            f"Publish time: {doc.get('publishTime')}" if doc.get("publishTime") else "",
            f"Operation: {doc.get('operation')}" if doc.get("operation") else "",
            f"Security: {doc.get('security')}" if doc.get("security") else "",
            f"File type: {field_values.get('fileType')}" if isinstance(field_values, dict) and field_values.get("fileType") else "",
            f"Part number: {field_values.get('partNo')}" if isinstance(field_values, dict) and field_values.get("partNo") else "",
            f"Related submodels: {related_submodels}" if related_submodels else "",
        ]
        row = {
            "doc_id": f"huawei-{output_stem(record)}-docapi-{index:04d}",
            "vendor": record.vendor,
            "product_category": record.product_category,
            "product_family": record.product_family,
            "release": record.release,
            "doc_group": record.doc_group,
            "doc_type": record.doc_type,
            "doc_subtype": record.doc_subtype,
            "content_type": "doc_catalog_item",
            "title": title,
            "section_path": [record.title, title],
            "source_file": record.stored_file_name,
            "source_relative_path": record.stored_relative_path,
            "source_page_url": record.source_page_url,
            "download_url": record.download_url,
            "language": "en-US",
            "content": "\n".join(line for line in content_lines if line).strip(),
            "extra": {
                "nid": doc.get("nid"),
                "mid": doc.get("mid"),
                "version_name": doc.get("versionName"),
                "publish_time": doc.get("publishTime"),
                "operation": doc.get("operation"),
                "security": doc.get("security"),
                "file_type": field_values.get("fileType") if isinstance(field_values, dict) else None,
                "part_no": field_values.get("partNo") if isinstance(field_values, dict) else None,
                "related_submodels": related_submodels,
            },
        }
        validate_ready_record(row)
        rows.append(row)
    return rows


def process_doc_api_record(record: InventoryRecord) -> list[dict[str, Any]]:
    rows = build_doc_api_ready_records(record)
    chunks_path = output_dir(CHUNKS_DIR, record) / f"{output_stem(record)}.chunks.jsonl"
    write_jsonl(chunks_path, rows)
    return rows


def build_summary(records: list[InventoryRecord], selected: list[InventoryRecord], ready_rows: list[dict[str, Any]]) -> dict[str, Any]:
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    by_product_family = Counter(row["product_family"] for row in ready_rows)
    by_source_file = Counter(row["source_file"] for row in ready_rows)
    return {
        "total_artifacts_inventoried": len(records),
        "selected_command_sources": len(selected),
        "selected_source_files": [record.stored_file_name for record in selected],
        "total_ready_records": len(ready_rows),
        "content_type_counts": dict(Counter(row["content_type"] for row in ready_rows)),
        "by_product_family": dict(by_product_family),
        "by_source_file": dict(by_source_file),
        "duplicate_chunk_count": duplicate_count,
        "empty_chunk_count": empty_count,
    }


def build_manual_summary(records: list[InventoryRecord], selected: list[InventoryRecord], ready_rows: list[dict[str, Any]]) -> dict[str, Any]:
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    by_product_family = Counter(row["product_family"] for row in ready_rows)
    return {
        "total_artifacts_inventoried": len(records),
        "selected_manual_sources": len(selected),
        "selected_source_files": [record.stored_file_name for record in selected],
        "total_ready_records": len(ready_rows),
        "content_type_counts": dict(Counter(row["content_type"] for row in ready_rows)),
        "by_product_family": dict(by_product_family),
        "duplicate_chunk_count": duplicate_count,
        "empty_chunk_count": empty_count,
    }


def build_pdf_summary(records: list[InventoryRecord], selected: list[InventoryRecord], ready_rows: list[dict[str, Any]]) -> dict[str, Any]:
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    return {
        "total_artifacts_inventoried": len(records),
        "selected_pdf_sources": len(selected),
        "selected_source_files": [record.stored_file_name for record in selected],
        "total_ready_records": len(ready_rows),
        "content_type_counts": dict(Counter(row["content_type"] for row in ready_rows)),
        "by_product_family": dict(Counter(row["product_family"] for row in ready_rows)),
        "duplicate_chunk_count": duplicate_count,
        "empty_chunk_count": empty_count,
    }


def build_generic_summary(records: list[InventoryRecord], selected: list[InventoryRecord], ready_rows: list[dict[str, Any]], source_label: str) -> dict[str, Any]:
    duplicate_count = len(ready_rows) - len({row["doc_id"] for row in ready_rows})
    empty_count = sum(1 for row in ready_rows if not row["content"].strip())
    return {
        "total_artifacts_inventoried": len(records),
        source_label: len(selected),
        "selected_source_files": [record.stored_file_name for record in selected],
        "total_ready_records": len(ready_rows),
        "content_type_counts": dict(Counter(row["content_type"] for row in ready_rows)),
        "by_product_family": dict(Counter(row["product_family"] for row in ready_rows)),
        "duplicate_chunk_count": duplicate_count,
        "empty_chunk_count": empty_count,
    }


def run_commands(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_command_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_command_record(record))
    write_jsonl(READY_JSONL_PATH, ready_rows)
    summary = build_summary(records, selected, ready_rows)
    write_json(READY_SUMMARY_PATH, summary)
    return summary


def run_manuals(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_manual_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_manual_record(record))
    write_jsonl(MANUAL_READY_JSONL_PATH, ready_rows)
    summary = build_manual_summary(records, selected, ready_rows)
    write_json(MANUAL_READY_SUMMARY_PATH, summary)
    return summary


def run_pdfs(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_pdf_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_pdf_record(record))
    write_jsonl(PDF_READY_JSONL_PATH, ready_rows)
    summary = build_pdf_summary(records, selected, ready_rows)
    write_json(PDF_READY_SUMMARY_PATH, summary)
    return summary


def run_knowledge(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_knowledge_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_knowledge_record(record))
    write_jsonl(KNOWLEDGE_READY_JSONL_PATH, ready_rows)
    summary = build_generic_summary(records, selected, ready_rows, "selected_knowledge_sources")
    write_json(KNOWLEDGE_READY_SUMMARY_PATH, summary)
    return summary


def run_bulletins(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_bulletin_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_bulletin_record(record))
    write_jsonl(BULLETIN_READY_JSONL_PATH, ready_rows)
    summary = build_generic_summary(records, selected, ready_rows, "selected_bulletin_sources")
    write_json(BULLETIN_READY_SUMMARY_PATH, summary)
    return summary


def run_links(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_link_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_link_record(record))
    write_jsonl(LINK_READY_JSONL_PATH, ready_rows)
    summary = build_generic_summary(records, selected, ready_rows, "selected_link_sources")
    write_json(LINK_READY_SUMMARY_PATH, summary)
    return summary


def run_doc_api(records: list[InventoryRecord] | None = None) -> dict[str, Any]:
    ensure_output_directories()
    records = records or build_inventory()
    write_inventory(records)
    selected = select_processable_doc_api_records(records)
    ready_rows: list[dict[str, Any]] = []
    for record in selected:
        ready_rows.extend(process_doc_api_record(record))
    write_jsonl(DOC_API_READY_JSONL_PATH, ready_rows)
    summary = build_generic_summary(records, selected, ready_rows, "selected_doc_api_sources")
    write_json(DOC_API_READY_SUMMARY_PATH, summary)
    return summary


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Huawei 文档预处理脚本")
    parser.add_argument("command", choices=("inventory", "commands", "manuals", "pdfs", "knowledge", "bulletins", "links", "doc-api", "all"))
    return parser


def main() -> None:
    args = build_parser().parse_args()
    records = build_inventory()
    if args.command == "inventory":
        write_inventory(records)
        print(json.dumps({"inventory_path": str(INVENTORY_PATH), "total_artifacts": len(records)}, ensure_ascii=False, indent=2))
        return
    if args.command == "commands":
        summary = run_commands(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "manuals":
        summary = run_manuals(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "pdfs":
        summary = run_pdfs(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "knowledge":
        summary = run_knowledge(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "bulletins":
        summary = run_bulletins(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "links":
        summary = run_links(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    if args.command == "doc-api":
        summary = run_doc_api(records)
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return
    command_summary = run_commands(records)
    manual_summary = run_manuals(records)
    pdf_summary = run_pdfs(records)
    knowledge_summary = run_knowledge(records)
    bulletin_summary = run_bulletins(records)
    link_summary = run_links(records)
    doc_api_summary = run_doc_api(records)
    summary = {
        "commands": command_summary,
        "manuals": manual_summary,
        "pdfs": pdf_summary,
        "knowledge": knowledge_summary,
        "bulletins": bulletin_summary,
        "links": link_summary,
        "doc_api": doc_api_summary,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
