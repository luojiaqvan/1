# c4-dev 知识库知识点清单与推荐来源

## 1. 文档目的

本文档用于沉淀 `D:\c4-dev` 当前知识库建设阶段的知识点清单，并为每类知识点提供建议的获取网站、适用说明、可信度判断、是否应优先从内部系统获取，以及在**双模型架构**下主要服务于哪个模型的建议。

本文依据以下信息整理：

- `docs/KNOWLEDGE_SERVICE_SPEC.md` 中当前明确的知识分类：`commands / docs / sop`
- `docs/ROADMAP.md §5.5` 中建议分层接入的知识源：
  1. 厂商官方文档
  2. 内部操作手册 / SOP
  3. CMDB / 设备清单 / 拓扑
  4. 设备当前状态与配置快照
  5. 历史工单、历史变更、故障案例

## 2. 使用原则

1. **优先官方来源**：命令语法、协议规则、产品行为优先采用厂商官方文档、标准组织和官方开源项目文档。
2. **区分知识与运行数据**：公开网站适合补“通用知识”，内部系统更适合提供“你们自己的设备、状态、案例、工单”。
3. **公开来源用于建模，内部来源用于落地**：像 CMDB、实时状态、配置快照、故障历史，通常不能靠公开互联网补齐。
4. **可追溯**：后续入库时应把来源站点写进知识条目的 `evidence_source` 或文档元数据中。

### 2.1 面向双模型的分配原则

结合 `docs/TOOLS_SPEC.md` 与 `docs/ROADMAP.md` 中对双模型的职责定义，知识分配建议如下：

1. **主模型（意图模型）**主要消费：操作类型、目标对象、澄清规则、风险判断、前置检查、流程策略、SOP 方法论、术语定义。
2. **生成模型（命令模型）**主要消费：厂商命令参考、CLI 视图模式、参数约束、版本适用性、命令样例、预期输出模式、生成依据。
3. **共享知识**只保留两边都要一致的最小语义接口：统一术语、对象分类、风险分级、约束表达。
4. **动态知识**不应主要作为静态语料喂给任一模型，而应通过工具或内部系统实时/按需检索：设备清单、拓扑、实时状态、配置快照、历史工单、历史变更、故障案例等。
5. **厂商命令事实库以检索为主，不以模型记忆为主**：命令模型应基于知识库与设备上下文保守生成候选命令，而不是脱离知识库自由发挥。

## 3. 完整清单

| 知识点 | 建议采集内容 | 推荐网站 | 推荐理由 | 可信度 | 是否优先内部获取 | 主要服务模型 | 消费方式 |
|---|---|---|---|---|---|---|---|
| 华为 VRP 命令知识 | 接口、VLAN、路由、ACL、系统类命令；视图模式；参数约束；版本差异 | 华为云社区 `https://bbs.huaweicloud.com` | 当前可公开检索到的高相关来源，适合先收集 VRP 基础命令知识与经验总结；后续应补充华为企业官方技术文档 | 官方社区 / 较高 | 否 | 命令模型 | 检索为主 |
| H3C Comware 命令知识 | Comware V7/V9 命令参考、配置手册、命令索引、CLI 说明 | H3C 文档中心 `https://www.h3c.com/cn/Service/Document_Software/Document_Center/` | 官方文档中心，结构化程度高，适合直接作为 `docs/` 和 `commands/` 的基础来源 | 官方 / 高 | 否 | 命令模型 | 检索为主 |
| 通用网络协议标准 | BGP、OSPF、SNMP、NETCONF、故障管理术语、协议概念定义 | RFC Editor `https://www.rfc-editor.org`；IETF `https://www.ietf.org` | 适合补协议标准、概念定义和术语边界，为知识条目提供正式依据 | 官方标准 / 最高 | 否 | 共享 | 检索为主 |
| 网络故障术语标准 | Event、Fault、Problem、Incident、Alarm 等标准定义 | RFC 9940 `https://www.rfc-editor.org/rfc/rfc9940.html` | 适合统一故障分类、SOP 术语和案例标签体系 | 官方标准 / 最高 | 否 | 意图模型 / 共享 | 检索为主 |
| 多厂商命令对照 | Cisco / Huawei / H3C 命令映射、常见场景对照 | CSDN 文章 `https://blog.csdn.net/weixin_41445009/article/details/145823993` | 适合辅助迁移和交叉理解，但不能替代厂商官方文档 | 社区 / 中 | 否 | 命令模型 / 共享 | 补充检索 |
| 网络故障排查方法论 | 排障步骤、诊断路径、根因分析思路 | Google SRE Book `https://sre.google/sre-book/`；Cisco Troubleshooting `https://www.cisco.com/en/US/docs/internetworking/troubleshooting/guide/tr1901.html`；Juniper Troubleshooting `https://www.juniper.net/documentation/us/en/software/junos/ospf/bgp/topics/topic-map/troubleshooting-network-issues.html` | 适合提炼 SOP 模板、排障流程和知识库中的“处理建议”部分 | 官方 / 高 | 否 | 意图模型 | 检索为主 |
| 事件响应流程 | Incident 管理、角色分工、交接、沟通、状态文档 | Google SRE Book - Managing Incidents `https://sre.google/sre-book/managing-incidents/` | 适合建设故障响应类 SOP 和事件处理模板 | 官方 / 高 | 否 | 意图模型 | 检索为主 |
| 事后复盘与案例模板 | Postmortem 模板、无责复盘、行动项跟踪 | Google SRE Book - Postmortem Culture `https://sre.google/sre-book/postmortem-culture/` | 适合构建故障案例库、复盘模板和经验沉淀规范 | 官方 / 高 | 部分，是 | 意图模型 | 检索 + 内部沉淀 |
| 变更管理最佳实践 | 变更窗口、审批、回滚、发布策略、风险控制 | ITIL `https://www.axelos.com/best-practice-solutions/itil`；Google SRE Release Engineering `https://sre.google/sre-book/release-engineering/` | 适合支撑“变更类 SOP”“风险等级”“回滚策略”等结构化知识 | 官方框架 / 高 | 部分，是 | 意图模型 / 共享 | 检索 + 内部沉淀 |
| 厂商排障与配置案例 | Cisco、Juniper 等厂商的官方故障处理和配置案例 | Cisco 官方文档、Juniper 官方文档 | 适合补充 `docs/` 和 `sop/` 中的案例说明，但需注意厂商差异 | 官方 / 高 | 否 | 意图模型 / 命令模型 | 检索为主 |
| CMDB / 设备清单建模 | 设备、机架、接口、IP、VLAN、连接关系、资产模型 | NetBox Docs `https://netboxlabs.com/docs/netbox/` | 适合学习网络资产建模与 Source of Truth 设计 | 官方文档 / 高 | 是 | 共享 | 建模参考 + 内部系统 |
| 网络监控与自动发现 | 自动发现机制、邻居关系、设备清单、拓扑关联 | LibreNMS Docs `https://docs.librenms.org/` | 适合补设备发现、监控模型、拓扑感知类知识 | 官方文档 / 高 | 是 | 共享 / 动态知识 | 方法参考 + 内部系统 |
| 拓扑自动发现方法 | LLDP / CDP 邻居发现、拓扑图生成 | `lldp2map` `https://github.com/buraglio/lldp2map` | 适合作为“如何发现拓扑”的方法知识，而不是最终拓扑数据来源 | 开源官方 / 高 | 是 | 共享 / 动态知识 | 方法参考 + 内部系统 |
| 集群或复杂网络拓扑工具 | 物理网络拓扑发现、拓扑 API | NVIDIA Topograph `https://github.com/NVIDIA/topograph` | 适合参考复杂网络拓扑发现与暴露方式 | 开源官方 / 高 | 是 | 共享 / 动态知识 | 方法参考 + 内部系统 |
| 配置快照与配置备份 | 设备配置抓取、版本追踪、差异比对、配置历史 | Oxidized `https://github.com/ytti/oxidized` | 适合作为配置快照和历史配置管理的建设参考 | 开源官方 / 高 | 是 | 动态知识 | 内部系统优先 |
| 自动化采集框架 | 设备 facts 采集、批量执行、Inventory 集成 | Nornir `https://nornir.readthedocs.io/` | 适合作为“如何批量获取状态/配置/上下文”的方法来源 | 官方文档 / 高 | 是 | 共享 / 动态知识 | 方法参考 + 内部系统 |
| 监控指标采集 | SNMP 指标、接口状态、CPU / 内存、协议监控 | Prometheus Exporters `https://prometheus.io/docs/instrumenting/exporters/`；SNMP Exporter `https://github.com/prometheus/snmp_exporter` | 适合作为状态类知识采集规范和指标模型参考 | 官方 / 高 | 是 | 动态知识 / 共享 | 方法参考 + 内部系统 |
| 可观测性与可视化 | 仪表板、告警、网络流量可视化、故障趋势分析 | Grafana Docs `https://grafana.com/docs/`；OpenTelemetry `https://opentelemetry.io/docs/zero-code/obi/` | 适合作为“状态知识”和“观测方法”层的参考材料 | 官方 / 高 | 是 | 动态知识 / 共享 | 方法参考 + 内部系统 |
| 运行手册 / SOP | 巡检手册、变更 SOP、故障排查 SOP、应急预案 | 内部 Wiki、Confluence、SharePoint、团队文档库 | 这类知识强依赖本组织环境、命名规范和设备实际情况 | 内部优先 / 最高 | 是 | 意图模型 | 内部沉淀 |
| 历史工单 | 故障处理记录、处理耗时、责任链路、解决方案 | ServiceNow、Jira、自建 ITSM | 历史工单是构建案例库和经验库的核心来源，通常无法从互联网获得 | 内部优先 / 最高 | 是 | 动态知识 / 意图模型 | 内部沉淀 |
| 历史变更记录 | 变更单、审批记录、回滚记录、影响范围 | 变更系统、Git 提交记录、发布平台 | 适合建设“变更知识”和“失败案例库” | 内部优先 / 最高 | 是 | 动态知识 | 内部沉淀 |
| 故障案例库 | 典型事件、根因、修复方式、经验教训 | 内部复盘库、故障档案库、监控平台历史事件 | 这类知识最能提升知识库实用性，但必须从内部积累 | 内部优先 / 最高 | 是 | 意图模型 / 动态知识 | 内部沉淀 |
| 实时设备状态 | 接口 up/down、错误计数、会话状态、系统资源占用 | 设备直连采集、SNMP、Telemetry、监控平台内部实例 | 实时状态属于运行时数据，公开互联网无法提供你们环境的真实值 | 内部优先 / 最高 | 是 | 动态知识 | 工具实时拉取 |
| 实时配置快照 | Running config、Startup config、当前配置差异 | 设备采集、配置备份仓库、自动化平台 | 这类知识只能来自你们自己的设备与仓库 | 内部优先 / 最高 | 是 | 动态知识 | 工具实时拉取 / 仓库检索 |
| 网络资产上下文 | 业务归属、区域、站点、机房、网络域、责任人 | CMDB、资产系统、组织架构系统 | 对后续意图解析和执行编排非常关键，但必须来自内部系统 | 内部优先 / 最高 | 是 | 动态知识 | 内部系统查询 |

## 4. 分类落库建议

### 4.1 对应 `commands/`

建议放入以下知识：

- 华为 VRP 命令知识
- H3C Comware 命令知识
- 通用网络协议标准中与命令解释直接相关的部分
- 多厂商命令对照（仅作为补充参考）

建议来源优先级：

1. 厂商官方文档
2. RFC / IETF 标准
3. 官方社区
4. 社区整理文章（仅补充）

### 4.2 对应 `docs/`

建议放入以下知识：

- 厂商官方文档
- RFC / IETF 标准
- 开源工具官方文档（NetBox、LibreNMS、Oxidized、Nornir、Prometheus、Grafana、OpenTelemetry）

### 4.3 对应 `sop/`

建议放入以下知识：

- 网络故障排查方法论
- 事件响应流程
- 事后复盘模板
- 变更管理流程
- 巡检、变更、应急预案等内部操作手册

其中公开来源适合作为模板和方法论，真正落地内容应优先来源于内部工单、内部 SOP 和内部复盘记录。

### 4.4 面向双模型的检索建议

建议在物理目录仍保持 `commands / docs / sop` 的前提下，增加面向模型的检索路由：

1. **主模型（意图模型）优先检索**：
   - `sop/` 中的流程方法、巡检手册、排障 SOP、变更 SOP
   - `docs/` 中的术语定义、协议标准、厂商排障案例
   - 内部系统中的历史工单、复盘案例、风险策略
2. **生成模型（命令模型）优先检索**：
   - `commands/` 中的厂商命令条目
   - `docs/` 中的厂商命令参考、版本说明、CLI 视图约定
   - KR2 类型的设备上下文（vendor、model、os_version、协议能力）
3. **共享层统一输出语义**：
   - 统一对象词表（接口、VLAN、路由、ACL、系统等）
   - 统一操作词表（query / inspect / change）
   - 统一风险等级、约束表达和 evidence_source 规则
4. **动态层不做静态大语料喂给模型**：
   - 设备清单、拓扑、实时状态、配置快照、历史工单、历史变更等统一按需检索

## 5. 判断标准

如果一个知识点回答的是下面的问题，可以这样判断来源：

- **“这个命令怎么写、语法是什么？”** → 优先厂商官方文档 / RFC
- **“这个协议概念是什么意思？”** → 优先 RFC / IETF
- **“我们现在有哪些设备、拓扑是什么？”** → 优先内部 CMDB / 拓扑系统
- **“设备当前状态怎样？”** → 优先内部监控 / 实时采集 / Telemetry
- **“以前类似故障怎么处理过？”** → 优先内部工单 / 复盘 / 案例库
- **“标准排障流程该怎么写？”** → 参考 Google SRE / ITIL / 厂商排障文档，再结合内部流程固化为 SOP

## 6. 当前建议

当前阶段建议你先按下面顺序开始建设：

1. **commands**：先沉淀华为 VRP、H3C Comware 的接口、VLAN、路由、ACL、系统类命令
2. **docs**：优先补齐 H3C 官方文档、RFC/IETF 标准文档、开源工具官方文档
3. **sop**：先建立巡检 SOP、变更 SOP、故障排查 SOP、事件响应 SOP 的模板
4. **后续扩展源**：逐步接入内部 CMDB、配置快照、工单系统、复盘案例库

## 7. 参考来源

- H3C 文档中心：`https://www.h3c.com/cn/Service/Document_Software/Document_Center/`
- 华为云社区：`https://bbs.huaweicloud.com`
- RFC Editor：`https://www.rfc-editor.org`
- IETF：`https://www.ietf.org`
- RFC 9940：`https://www.rfc-editor.org/rfc/rfc9940.html`
- Google SRE Book：`https://sre.google/sre-book/`
- Google SRE - Managing Incidents：`https://sre.google/sre-book/managing-incidents/`
- Google SRE - Postmortem Culture：`https://sre.google/sre-book/postmortem-culture/`
- Google SRE - Release Engineering：`https://sre.google/sre-book/release-engineering/`
- Cisco Troubleshooting Overview：`https://www.cisco.com/en/US/docs/internetworking/troubleshooting/guide/tr1901.html`
- Juniper Troubleshooting Network Issues：`https://www.juniper.net/documentation/us/en/software/junos/ospf/bgp/topics/topic-map/troubleshooting-network-issues.html`
- NetBox Docs：`https://netboxlabs.com/docs/netbox/`
- LibreNMS Docs：`https://docs.librenms.org/`
- lldp2map：`https://github.com/buraglio/lldp2map`
- NVIDIA Topograph：`https://github.com/NVIDIA/topograph`
- Oxidized：`https://github.com/ytti/oxidized`
- Nornir：`https://nornir.readthedocs.io/`
- Prometheus Exporters：`https://prometheus.io/docs/instrumenting/exporters/`
- SNMP Exporter：`https://github.com/prometheus/snmp_exporter`
- Grafana Docs：`https://grafana.com/docs/`
- OpenTelemetry OBI：`https://opentelemetry.io/docs/zero-code/obi/`
- CSDN 多厂商命令对照：`https://blog.csdn.net/weixin_41445009/article/details/145823993`
