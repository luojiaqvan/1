"""后端 API 最小应用入口。"""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from llm.llm_gateway.exceptions import GatewayError
from llm.llm_gateway.models import ErrorResponse
from llm.llm_gateway.router import router as llm_gateway_router


def create_app() -> FastAPI:
    app = FastAPI(title="c4-dev backend api")
    app.include_router(llm_gateway_router)

    @app.exception_handler(GatewayError)
    async def handle_gateway_error(_: Request, exc: GatewayError) -> JSONResponse:
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.to_response().model_dump(),
        )

    @app.exception_handler(RequestValidationError)
    async def handle_validation_error(_: Request, exc: RequestValidationError) -> JSONResponse:
        payload = ErrorResponse(
            code="validation_error",
            message="请求体验证失败",
            details=exc.errors(),
        )
        return JSONResponse(status_code=422, content=payload.model_dump())

    @app.exception_handler(Exception)
    async def handle_unexpected_error(_: Request, exc: Exception) -> JSONResponse:
        payload = ErrorResponse(
            code="internal_error",
            message="服务器内部错误",
            details={"error_type": exc.__class__.__name__},
        )
        return JSONResponse(status_code=500, content=payload.model_dump())

    return app


app = create_app()
